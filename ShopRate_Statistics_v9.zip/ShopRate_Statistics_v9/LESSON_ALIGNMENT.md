# Alignment with the supplied AdvStat Lessons.pdf

PDF page numbers refer to the 185-page file uploaded for this review.

| Website method | Lesson pages | Implementation |
|---|---|---|
| Arithmetic mean | 45–46 | Sum divided by count. Sample solution uses x̄ and n; Population uses μ and N. |
| Median | 48 | Sort observations; take the middle, or average the two middle values. |
| Minimum, maximum, range | 62 | Range = largest minus smallest. |
| Variance | 77 | Sample divides squared deviations by n−1; Population divides by N. |
| Standard deviation | 78 | Positive square root of the selected variance. |
| Pearson correlation | 153 | Same computational formula; alternative deviation formula used for verification. |
| Correlation strength | 154 | Same magnitude bands. The app assigns shared cutoff values to the stronger category. |
| Quartiles and IQR fences | 56, 72–73 | Use the medians-of-halves procedure and flag strictly outside Q1−1.5×IQR or Q3+1.5×IQR. |

## Formula selection
Sample is now the initial setting. The built-in simulated records illustrate a sample of possible shop transactions; they are not evidence about actual customers or proof of representativeness. Population remains available for a finite selected group of interest. Changing formula mode affects variance and SD, not mean, median, extremes, Pearson r or IQR fences.

## Quartile convention
The implementation uses page 56’s lower/upper-half medians and reproduces page 73’s worked house-price example: Q1 = 308750, Q3 = 649000, IQR = 340250, lower fence = −201625, upper fence = 1159375; only 5500000 is flagged. For odd n, exclude the overall median before splitting. The slides also show a positional quartile formula on page 55; the documented medians-of-halves convention is used consistently in JavaScript and Python. Different quartile conventions must not be mixed.

Potential outliers are flagged if the selected service quantity OR total paid is outside its own fences. Records on a fence are not flagged. When IQR is zero, a value different from that common quartile value can still be flagged. Flags are review prompts, not automatic errors: records remain in all main results. Sensitivity r without flagged points is secondary and shown only when it can be computed.

Neither included valid dataset has IQR flags. The previous two-SD ring on transaction 17 has therefore disappeared; the dataset and full-data r are unchanged.

## Verification stays independent
The Python statistics/NumPy/SciPy reference calculations, running mean/spread, raw-sums variance, deviation-form correlation, spreadsheet instructions and known-answer checks remain. They intentionally provide other routes to check the lesson-based main calculations. The displayed r² is an additional explanatory measure, not an inferential significance test.

The app follows the formulas rather than copying arithmetic errors in worked slides. In particular, page 84’s variance 6.234375 gives population SD 2.496873…, not the printed 2.123.
