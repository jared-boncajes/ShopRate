"""Independently recompute both supplied CSV datasets without executing ShopRate JS.
Requires NumPy and SciPy; exits nonzero on any mismatch with expected.json.
"""
import csv,json,math,statistics as st
from pathlib import Path
import numpy as np
from scipy.stats import pearsonr
root=Path(__file__).resolve().parent
reference=json.loads((root/'data/expected.json').read_text());checks=[]
def fences(values):
 ordered=sorted(values);middle=len(ordered)//2
 lower_half=ordered[:middle];upper_half=ordered[middle+len(ordered)%2:]
 q1=st.median(lower_half);q3=st.median(upper_half);iqr=q3-q1
 return {"q1":q1,"q3":q3,"iqr":iqr,"lower":q1-1.5*iqr,"upper":q3+1.5*iqr}

for dataset in ['dataset1','dataset2']:
 rows=list(csv.DictReader((root/f'data/{dataset}.csv').open()))
 columns={k:[float(r[k]) for r in rows] for k in ['print','scan','rent','total']}
 for field,v in columns.items():
  results={'mean':st.fmean(v),'median':st.median(v),'sampleVariance':st.variance(v),'populationVariance':st.pvariance(v),'sampleStd':st.stdev(v),'populationStd':st.pstdev(v),'min':min(v),'max':max(v)}
  for metric,actual in results.items():
   expected=reference[dataset]['variables'][field][metric]
   checks.append((math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-9),f'{dataset} {field} {metric}: Python={actual:.12g}; reference={expected:.12g}'))
 for field in ['print','scan','rent']:
  for tool,actual in [('SciPy',float(pearsonr(columns[field],columns['total']).statistic)),('NumPy',float(np.corrcoef(columns[field],columns['total'])[0,1]))]:
   expected=reference[dataset]['pearson'][field]['r'];checks.append((math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-9),f'{dataset} {field} Pearson: {tool}={actual:.12g}; reference={expected:.12g}'))
 # Independently recompute the lesson's quartiles/fences and outlier decisions from CSV.
 all_bounds={field:fences(values) for field,values in columns.items()}
 for field,bounds in all_bounds.items():
  recorded=(reference[dataset]['unusual']['print']['yBounds'] if field=='total'
            else reference[dataset]['unusual'][field]['xBounds'])
  for metric,actual in bounds.items():
   checks.append((math.isclose(actual,recorded[metric],rel_tol=1e-9,abs_tol=1e-9),
                  f'{dataset} {field} IQR {metric}: Python={actual:.12g}; reference={recorded[metric]:.12g}'))
 for field in ['print','scan','rent']:
  xb=all_bounds[field];yb=all_bounds['total']
  flags=[i for i,(x,y) in enumerate(zip(columns[field],columns['total']))
         if x<xb['lower'] or x>xb['upper'] or y<yb['lower'] or y>yb['upper']]
  recorded=reference[dataset]['unusual'][field]
  checks.append(([i+1 for i in flags]==recorded['flagged'],f'{dataset} {field} IQR flagged transactions: {[i+1 for i in flags]}'))
  keep=[i for i in range(len(rows)) if i not in flags];result=None
  if flags and len(keep)>=3 and len({columns[field][i] for i in keep})>1 and len({columns['total'][i] for i in keep})>1:
   result=float(pearsonr([columns[field][i] for i in keep],[columns['total'][i] for i in keep]).statistic)
  expected=recorded['rWithout']
  ok=(result is None and expected is None) or (result is not None and expected is not None and math.isclose(result,expected,rel_tol=1e-9,abs_tol=1e-9))
  checks.append((ok,f'{dataset} {field} sensitivity r: Python={result}; reference={expected}'))
text='\n'.join(('PASS ' if ok else 'FAIL ')+desc for ok,desc in checks)+f'\n{sum(ok for ok,_ in checks)}/{len(checks)} fresh independent reference checks passed.\n'
(root/'results/independent-python-results.txt').write_text(text);print(text)
raise SystemExit(any(not ok for ok,_ in checks))
