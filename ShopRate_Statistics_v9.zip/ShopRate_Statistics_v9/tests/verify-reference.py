"""Independently recompute both supplied CSV datasets without executing ShopRate JS.
Requires NumPy and SciPy; exits nonzero on any mismatch with expected.json.
"""
import csv,json,math,statistics as st
from pathlib import Path
import numpy as np
from scipy.stats import pearsonr
root=Path(__file__).resolve().parent
reference=json.loads((root/'data/expected.json').read_text());checks=[]
for dataset in ['dataset1','dataset2']:
 rows=list(csv.DictReader((root/f'data/{dataset}.csv').open()))
 columns={k:[float(r[k]) for r in rows] for k in ['print','scan','rent','total']}
 for field,v in columns.items():
  results={'mean':st.fmean(v),'median':st.median(v),'sampleVariance':st.variance(v),'populationVariance':st.pvariance(v),'sampleStd':st.stdev(v),'populationStd':st.pstdev(v),'min':min(v),'max':max(v)}
  for metric,actual in results.items():
   expected=reference[dataset]['variables'][field][metric]
   checks.append((math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-9),f'{dataset} {field} {metric}: Python={actual:.12g}; reference={expected:.12g}'))
 for field in ['print','scan','rent']:
  for tool,actual in [('SciPy',float(pearsonr(columns[field],columns['total']).statistic)),('NumPy',float(np.corrcoef(columns[field],columns['total'])[0,1]))]:
   expected=reference[dataset]['pearson'][field]['r'];checks.append((math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-9),f'{dataset} {field} Pearson: {tool}={actual:.12g}; reference={expected:.12g}'))
text='\n'.join(('PASS ' if ok else 'FAIL ')+desc for ok,desc in checks)+f'\n{sum(ok for ok,_ in checks)}/{len(checks)} fresh independent reference checks passed.\n'
(root/'results/independent-python-results.txt').write_text(text);print(text)
raise SystemExit(any(not ok for ok,_ in checks))
