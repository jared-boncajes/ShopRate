"""Current v9 browser regression checks. Run: python3 tests/ui-tests.py.
Requires Playwright and Chromium. Uses an ephemeral loopback HTTP server.
Set SHOPRATE_CHROMIUM to use an installed browser; otherwise Playwright's browser is used.
"""
import csv, functools, http.server, json, os, threading
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
ref=json.loads((root/'tests/data/expected.json').read_text())
log=[]
def check(name,condition):
 log.append(('PASS' if condition else 'FAIL')+' '+name)
def near(actual,value):
 return abs(float(actual.replace('₱','').replace(',',''))-value)<=0.0051
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root)))
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
  executable=os.environ.get('SHOPRATE_CHROMIUM')
  browser=p.chromium.launch(**({'executable_path':executable} if executable else {}))
  page=browser.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(f'http://127.0.0.1:{server.server_port}/Statistics.html')
  check('initial formula defaults to sample',page.input_value('#formulaMode')=='sample')
  check('initial sample variance',near(page.locator('#varianceValue').text_content(),ref['dataset1']['variables']['total']['sampleVariance']))
  check('initial sample SD',near(page.locator('#stdValue').text_content(),ref['dataset1']['variables']['total']['sampleStd']))
  def text(s):return page.locator(s).text_content()
  def sample(key):
   page.click('#loadSampleBtn');page.click(f'[data-sample="{key}"]')
  def verify(label):
   page.click('#viewVerificationBtn')
   check(label+' verification visible',page.locator('#verificationSolution').is_visible())
   check(label+' four verification steps',page.locator('#verificationSteps .step').count()==4)
   check(label+' verification no failures',page.locator('#verificationSteps .status_fail').count()==0)
   return text('#verificationSteps')
  for key,dataset in [('valid','dataset1'),('second','dataset2')]:
   sample(key);r=ref[dataset]
   check(dataset+' analyzed',text('#statusMessage')==f'{r["n"]} valid transactions analyzed.')
   check(dataset+' printing default scatter',page.input_value('#scatterVariable')=='print')
   check(dataset+' printing default bars',page.input_value('#chartVariable')=='print')
   check(dataset+' all-four option absent',page.locator('#chartVariable option[value=all]').count()==0)
   for field in ['total','print','scan','rent']:
    page.select_option('#summaryVariable',field)
    for mode in ['sample','population']:
     page.select_option('#formulaMode',mode);v=r['variables'][field]
     for selector,k in [('meanValue','mean'),('medianValue','median'),('minValue','min'),('maxValue','max'),('varianceValue',mode+'Variance'),('stdValue',mode+'Std')]:
      check(f'{dataset} {field} {mode} {k}',near(text('#'+selector),v[k]))
    check(field+' currency unit not repeated',(text('#meanUnit')=='pesos' and '₱' not in text('#meanValue') and page.locator('#meanUnit').is_visible()) if field=='total' else page.locator('#meanUnit').is_visible())
   page.select_option('#summaryVariable','total');page.select_option('#formulaMode','sample')
   check('variance tile has squared currency unit', '₱' not in text('#varianceValue') and text('#varianceUnit') == 'pesos²' and page.locator('#varianceUnit').is_visible())
   check('business relevance visible','owner' in text('#meanText'))
   check('spread has business implication','For the shop' in text('#stdText'))
   for field in ['print','scan','rent']:
    page.select_option('#scatterVariable',field)
    check(dataset+field+' coefficient',abs(float(text('#tile'+field.capitalize()+' .tile_value'))-r['pearson'][field]['r'])<0.000051)
    check(dataset+field+' points retained',page.locator('#scatterChart .dot').count()==r['n'])
    check(dataset+field+' unusual rings',page.locator('#scatterChart .unusual-ring').count()==len(r['unusual'][field]['flagged']))
    check(dataset+field+' axes', 'Total paid (₱)' in text('#scatterChart'))
    page.select_option('#chartVariable',field)
   check('causation caveat visible','does not prove causation' in text('#pearsonResults'))
   for field in ['total','print','scan','rent']:
    page.select_option('#summaryVariable',field)
    for mode in ['sample','population']:
     page.select_option('#formulaMode',mode);page.click('#viewDescriptiveBtn')
     check(dataset+field+mode+' six solution steps',page.locator('#descriptiveSteps .step').count()==6)
     expected_mean = 'x̄ = Σx / n' if mode=='sample' else 'μ = Σx / N'
     check(dataset+field+mode+' mean symbols match selection',expected_mean in text('#descriptiveSteps'))
     check(dataset+field+mode+' matches cross-check',page.locator('#descriptiveSteps .check_row.failed').count()==0 and 'Matches' in text('#descriptiveSteps'))
     check(dataset+field+mode+' simple interpretation','For the shop.' in text('#descriptiveSteps'))
     check(dataset+field+mode+' squared-unit explanation','calculation uses squared units' in text('#descriptiveSteps'))
     final=page.locator('#descriptiveSteps .final_answers strong').all_text_contents()
     check(dataset+field+mode+' final variance correct',near(final[2],r['variables'][field][mode+'Variance']))
     check(dataset+field+mode+' final variance has correct squared unit',page.locator('#descriptiveSteps .final_answers small').nth(2).text_content()=={'total':'pesos²','print':'pages²','scan':'pages²','rent':'hours²'}[field])
     page.click('#backFromDescriptive')
   for field in ['print','scan','rent']:
    page.select_option('#xVariable',field);page.click('#viewPearsonBtn')
    check(dataset+field+' five Pearson solution steps',page.locator('#pearsonSteps .step').count()==5)
    check(dataset+field+' final Pearson correct',abs(float(page.locator('#pearsonSteps .final_answers strong').first.text_content())-r['pearson'][field]['r'])<0.000051)
    check(dataset+field+' Pearson cross-check',page.locator('#pearsonSteps .check_row.failed').count()==0 and 'Matches' in text('#pearsonSteps'))
    check(dataset+field+' Pearson business meaning','What it means for the shop' in text('#pearsonSteps'))
    check(dataset+field+' IQR fences in solution',page.locator('#pearsonSteps .iqr_table tbody tr').count()==2 and 'Q1 − 1.5 × IQR' in text('#pearsonSteps'))
    page.click('#backFromPearson')
   for button,section,back in [('viewDescriptiveBtn','descriptiveSolution','backFromDescriptive'),('viewPearsonBtn','pearsonSolution','backFromPearson')]:
    page.click('#'+button);check(section+' opens',page.locator('#'+section).is_visible());page.click('#'+back)
   t=verify(dataset);check(dataset+' Python recognized',('TABLE NOW HOLDS '+dataset.replace('dataset','DATASET ')) in t.upper());check('spreadsheet row count',f'D2:D{r["n"]+1}' in t);page.click('#backFromVerification')
  page.locator('#csvInput').set_input_files(str(root/'tests/data/dataset2.csv'));page.select_option('#dataType','simulated');page.click('#analyze')
  check('CSV second dataset analyzed','30 valid' in text('#statusMessage'))
  check('source stays read-only',page.locator('#sourceDescription').get_attribute('readonly') is not None)
  sample('invalid');page.click('#analyze');check('insufficient rejected','At least 20' in text('#statusMessage'));check('stale results hidden',not page.locator('#descriptiveResults').is_visible())
  t=verify('invalid');check('no dataset correctly reported','No analyzed dataset yet' in t);page.click('#backFromVerification')
  for value,expected in [('', 'missing'),('abc','valid non-negative'),('-1','non-negative'),('2.5','whole-number')]:
   content=(root/'tests/data/dataset1.csv').read_text().splitlines();cells=content[1].split(',');cells[0]=value;content[1]=','.join(cells)
   page.locator('#csvInput').set_input_files({'name':'invalid.csv','mimeType':'text/csv','buffer':'\n'.join(content).encode()});page.select_option('#dataType','simulated');page.click('#analyze')
   check('reject bad cell '+repr(value),expected in text('#statusMessage'));check('bad cell hides results',not page.locator('#descriptiveResults').is_visible())
  content='print,scan,rent,total\n'+'\n'.join(f'{i},0,1,{i*5+10}' for i in range(1,21))
  page.locator('#csvInput').set_input_files({'name':'constant.csv','mimeType':'text/csv','buffer':content.encode()});page.select_option('#dataType','simulated');page.click('#analyze');check('constant correlation undefined','Undefined' in text('#tileScan'))
  sample('valid');page.select_option('#scatterVariable','rent');check('low correlation business value','business value' in text('#pearsonResults'))
  content='print,scan,rent,total\n'+'\n'.join(f'{i},1,1,{200 if i==20 else 2*i}' for i in range(1,21))
  page.locator('#csvInput').set_input_files({'name':'iqr-check.csv','mimeType':'text/csv','buffer':content.encode()});page.select_option('#dataType','simulated');page.click('#analyze')
  check('IQR graph retains all 20 dots',page.locator('#scatterChart .dot').count()==20)
  check('IQR graph circles the extreme',page.locator('#scatterChart .unusual-ring').count()==1 and 'transaction 20' in text('#scatterText'))
  check('IQR graph uses lesson rule','1.5 × IQR' in text('#scatterText') and '2-standard-deviation' not in text('#scatterText'))
  page.select_option('#xVariable','print')
  check('IQR extreme survives changing the selected service',page.locator('#scatterChart .unusual-ring').count()==1 and 'transaction 20' in text('#scatterText'))
  check('main Pearson still includes all points',abs(float(text('#tilePrint .tile_value'))-0.6078306738548308)<0.000051)
  page.click('#viewPearsonBtn')
  check('IQR solution has explicit fences and retained-record explanation',page.locator('#pearsonSteps .iqr_table').count()==1 and 'keep every transaction' in text('#pearsonSteps'))
  actual_fences=[float(value.replace(',','')) for value in page.locator('#pearsonSteps .iqr_table tbody tr').nth(1).locator('td').all_text_contents()[1:]]
  check('IQR solution displays known synthetic fences',actual_fences==[11,31,20,-19,61])
  page.click('#backFromPearson')
  for selected in ['sample','population']:
   page.select_option('#formulaMode',selected)
   check(selected+' IQR annotations independent of formula mode',page.locator('#scatterChart .unusual-ring').count()==1)
  sample('valid')
  page.select_option('#formulaMode','sample')
  for width in [1440,1024,768,390]:
   page.set_viewport_size({'width':width,'height':900});check(f'no document overflow {width}',page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'))
   page.click('#viewPearsonBtn');check(f'IQR solution no document overflow {width}',page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'));page.click('#backFromPearson')
  page.set_viewport_size({'width':1440,'height':1000});page.screenshot(path=str(root/'tests/results/statistics-updated.png'),full_page=True)
  for mode in ['sample','population']:
   page.select_option('#formulaMode',mode);page.click('#viewDescriptiveBtn')
   page.screenshot(path=str(root/f'tests/results/{mode}-solution.png'),full_page=True);page.click('#backFromDescriptive')
  page.select_option('#formulaMode','sample');page.click('#viewPearsonBtn')
  page.screenshot(path=str(root/'tests/results/pearson-iqr-solution.png'),full_page=True);page.click('#backFromPearson')
  for filename in ['Overview.html','RateAnalyzer.html','BillCalculator.html']:
   page.goto(f'http://127.0.0.1:{server.server_port}/{filename}');check(filename+' loads',page.locator('body').is_visible())
  check('no JavaScript runtime errors',not errors)
  browser.close()
except Exception as e:
 log.append('FAIL browser execution: '+str(e))
finally:
 server.shutdown()
 failures=sum(line.startswith('FAIL') for line in log)
 summary=f'{len(log)-failures} of {len(log)} browser checks passed, {failures} failed.'
 (root/'tests/results').mkdir(exist_ok=True)
 (root/'tests/results/ui-test-results.txt').write_text('\n'.join(log)+'\n'+summary+'\n')
 print('\n'.join(log));print(summary)
 raise SystemExit(bool(failures))
