"""
Independent reference values for the ShopRate statistics tests.

Uses Python's standard `statistics` module, NumPy and SciPy — NOT the ShopRate
JavaScript — so the website's own algorithms can be checked against another tool.

Run:  python3 tests/make_reference.py
Writes: tests/data/dataset1.csv, dataset2.csv, expected.json
"""
import csv, json, random, statistics as st
from pathlib import Path
import numpy as np
from scipy import stats as sps

here = Path(__file__).parent / "data"
here.mkdir(exist_ok=True)

# Dataset 1 = the built-in simulated dataset. List prices 5 / 3 / 10, then three kinds of adjustment,
# chosen once with a seeded random generator (the resulting totals are stored in js/statistics.js):
#   volume price: printed pages beyond 20 cost 4 each; student discount: 10 percent off, rounded to the
#   nearest peso; add-on fee: +5 (lamination, rush, ...).
import math
base = [
    (10,2,1),(5,5,2),(20,0,1),(4,2,3),(8,3,1),(2,1,0),
    (16,0,2),(12,6,1),(0,7,4),(22,4,2),(7,2,3),(18,3,0),
    (3,1,2),(14,5,1),(6,0,3),(9,8,0),(25,2,1),(11,3,4),
    (1,4,2),(13,1,0),(15,6,2),(5,2,3),(19,7,1),(8,5,2)]
_rng = random.Random(11)
_student = set(_rng.sample(range(24), 5))
_fee = set(_rng.sample(range(24), 4))
def _total(i, p, s, r):
    printing = 5 * p if p <= 20 else 5 * 20 + 4 * (p - 20)
    subtotal = printing + 3 * s + 10 * r
    if i in _student: subtotal = math.floor(subtotal * 0.9 + 0.5)
    if i in _fee: subtotal += 5
    return subtotal
d1 = [(p, s, r, _total(i, p, s, r)) for i, (p, s, r) in enumerate(base)]

# Dataset 2 = a DIFFERENT simulated dataset: 30 rows, seeded random quantities,
# prices 4.50 / 2.75 / 12.50 per unit plus a small random "extra" in centavos
# so the totals are not an exact linear function and contain decimals.
rng = random.Random(2026)
d2 = []
for _ in range(30):
    p, s, r = rng.randint(0, 40), rng.randint(0, 15), rng.randint(0, 6)
    extra = rng.randint(0, 900) / 100          # 0.00 – 9.00 pesos
    d2.append((p, s, r, round(4.5*p + 2.75*s + 12.5*r + extra, 2)))

def write(name, rows):
    with open(here / name, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["print", "scan", "rent", "total"])
        for row in rows:
            w.writerow([f"{v:.2f}" if isinstance(v, float) and i == 3 else v for i, v in enumerate(row)])

write("dataset1.csv", d1)
write("dataset2.csv", d2)

def reference(rows):
    cols = {k: [r[i] for r in rows] for i, k in enumerate(["print", "scan", "rent", "total"])}
    out = {"n": len(rows), "variables": {}, "pearson": {}}
    for k, v in cols.items():
        out["variables"][k] = {
            "mean": st.fmean(v), "median": st.median(v),
            "sampleVariance": st.variance(v), "populationVariance": st.pvariance(v),
            "sampleStd": st.stdev(v), "populationStd": st.pstdev(v),
            "min": min(v), "max": max(v)}
    out["unusual"] = {}
    for k in ["print", "scan", "rent"]:
        r, _ = sps.pearsonr(cols[k], cols["total"])
        out["pearson"][k] = {"r": float(r), "numpy": float(np.corrcoef(cols[k], cols["total"])[0, 1])}
        # Unusual observations: |z| >= 2 for x or for total, z = (value - mean) / sample SD. Kept in the data.
        mx, sx = st.fmean(cols[k]), st.stdev(cols[k])
        my, sy = st.fmean(cols["total"]), st.stdev(cols["total"])
        flagged = [i for i in range(len(rows))
                   if (sx > 0 and abs((cols[k][i] - mx) / sx) >= 2) or (sy > 0 and abs((cols["total"][i] - my) / sy) >= 2)]
        keep = [i for i in range(len(rows)) if i not in flagged]
        r_without = float(sps.pearsonr([cols[k][i] for i in keep], [cols["total"][i] for i in keep])[0]) if flagged and len(keep) >= 3 else None
        out["unusual"][k] = {"flagged": [i + 1 for i in flagged], "rWithout": r_without}
    return out

expected = {"dataset1": reference(d1), "dataset2": reference(d2)}
(here / "expected.json").write_text(json.dumps(expected, indent=2))
print("dataset1 total mean/median/sVar:", expected["dataset1"]["variables"]["total"]["mean"],
      expected["dataset1"]["variables"]["total"]["median"], expected["dataset1"]["variables"]["total"]["sampleVariance"])
print("dataset2 total mean/median/sVar:", expected["dataset2"]["variables"]["total"]["mean"],
      expected["dataset2"]["variables"]["total"]["median"], expected["dataset2"]["variables"]["total"]["sampleVariance"])
print("dataset1 r:", {k: round(v["r"], 6) for k, v in expected["dataset1"]["pearson"].items()})
print("dataset2 r:", {k: round(v["r"], 6) for k, v in expected["dataset2"]["pearson"].items()})

# ---- Linear Algebra regression reference (NumPy) -------------------------
# Same five demonstration systems as js/test.js. NumPy classifies each by rank:
#   rank(A) = rank([A|b]) = 3 -> unique;  rank(A) = rank([A|b]) < 3 -> dependent;
#   rank(A) < rank([A|b])     -> inconsistent.
la_cases = {
    "unique1":      [(10,2,1,66), (5,5,2,60), (20,0,1,110)],
    "unique2":      [(10,2,1,59), (5,5,2,60), (20,0,1,95)],
    "inconsistent": [(10,2,1,66), (20,4,2,140), (5,5,2,60)],
    "dependent":    [(10,2,1,66), (20,4,2,132), (30,6,3,198)],
    "rowswap":      [(0,2,1,38), (1,1,1,39), (1,3,2,80)],
}
la = {}
for name, rows in la_cases.items():
    A = np.array([r[:3] for r in rows], float); b = np.array([r[3] for r in rows], float)
    rA, rAb = np.linalg.matrix_rank(A), np.linalg.matrix_rank(np.column_stack([A, b]))
    kind = "unique" if rA == 3 else ("dependent" if rA == rAb else "inconsistent")
    la[name] = {"rows": rows, "classification": kind,
                "solution": np.linalg.solve(A, b).tolist() if kind == "unique" else None}
(here / "la_expected.json").write_text(json.dumps(la, indent=2))
print("LA reference:", {k: (v["classification"], v["solution"]) for k, v in la.items()})
