'use strict';

/**
 * ShopRate statistics tests (Node.js, no extra packages).
 *
 *   node tests/test-stats.js
 *
 * Expected values come from tests/data/expected.json, which is produced by
 * tests/make_reference.py using Python's `statistics`, NumPy and SciPy — an
 * independent tool, not the ShopRate JavaScript being tested.
 */
const fs = require('fs');
const path = require('path');
const stats = require('../js/stats-math.js');
const ShopRateMath = require('../js/math.js');

const dataFolder = path.join(__dirname, 'data');
const expected = JSON.parse(fs.readFileSync(path.join(dataFolder, 'expected.json'), 'utf8'));
const laExpected = JSON.parse(fs.readFileSync(path.join(dataFolder, 'la_expected.json'), 'utf8'));

const log = [];
let failures = 0;

function Record(id, description, expectedText, observedText, passed) {
  if (!passed) failures++;
  log.push({ id, description, expected: expectedText, observed: observedText, status: passed ? 'PASS' : 'FAIL' });
}

function CheckNumber(id, description, expectedValue, observedValue, tolerance = 1e-9) {
  const passed = Number.isFinite(observedValue) &&
    Math.abs(expectedValue - observedValue) <= tolerance * Math.max(1, Math.abs(expectedValue));
  Record(id, description, String(expectedValue), String(observedValue), passed);
}

function CheckTrue(id, description, expectedText, observedText, passed) {
  Record(id, description, expectedText, observedText, passed);
}

function CheckThrows(id, description, rows, pattern, expectedRow) {
  let message = 'no error';
  let rowIndex;
  try {
    stats.ValidateTransactions(rows, 20);
  } catch (error) {
    message = error.message;
    rowIndex = error.rowIndex;
  }
  const rowOk = expectedRow === undefined || rowIndex === expectedRow;
  Record(id, description, `error matching ${pattern}` + (expectedRow === undefined ? '' : ` at row index ${expectedRow}`),
    message + (rowIndex === undefined ? '' : ` (row index ${rowIndex})`), pattern.test(message) && rowOk);
}

function ReadCsv(fileName) {
  const lines = fs.readFileSync(path.join(dataFolder, fileName), 'utf8').trim().split(/\r?\n/);
  lines.shift();
  return lines.map(line => {
    const [print, scan, rent, total] = line.split(',');
    return { print, scan, rent, total };
  });
}

// TEST 1 AND 2 — full comparison against the independent Python reference
function CompareDataset(testId, label, fileName, key) {
  const rows = stats.ValidateTransactions(ReadCsv(fileName), 20);
  const reference = expected[key];
  CheckNumber(`${testId}-n`, `${label}: number of valid observations`, reference.n, rows.length);

  for (const field of stats.variableKeys) {
    const values = stats.GetValues(rows, field);
    const sample = stats.Describe(values, 'sample');
    const population = stats.Describe(values, 'population');
    const ref = reference.variables[field];
    const prefix = `${testId}-${field}`;
    CheckNumber(`${prefix}-mean`, `${label} ${field}: mean`, ref.mean, sample.mean);
    CheckNumber(`${prefix}-median`, `${label} ${field}: median`, ref.median, sample.median);
    CheckNumber(`${prefix}-min`, `${label} ${field}: minimum`, ref.min, sample.min);
    CheckNumber(`${prefix}-max`, `${label} ${field}: maximum`, ref.max, sample.max);
    CheckNumber(`${prefix}-svar`, `${label} ${field}: sample variance (n−1)`, ref.sampleVariance, sample.variance);
    CheckNumber(`${prefix}-pvar`, `${label} ${field}: population variance (N)`, ref.populationVariance, population.variance);
    CheckNumber(`${prefix}-ssd`, `${label} ${field}: sample standard deviation`, ref.sampleStd, sample.standardDeviation);
    CheckNumber(`${prefix}-psd`, `${label} ${field}: population standard deviation`, ref.populationStd, population.standardDeviation);
    CheckNumber(`${prefix}-rawsums`, `${label} ${field}: built-in variance cross-check (raw sums)`, ref.sampleVariance, stats.VarianceByRawSums(values, 'sample'));
    CheckTrue(`${prefix}-modes`, `${label} ${field}: mode switch leaves mean/median/min/max unchanged`,
      'identical', 'identical',
      sample.mean === population.mean && sample.median === population.median &&
      sample.min === population.min && sample.max === population.max);
  }

  const totals = stats.GetValues(rows, 'total');
  for (const field of stats.serviceKeys) {
    const xValues = stats.GetValues(rows, field);
    const result = stats.PearsonCorrelation(xValues, totals);
    const check = stats.PearsonByDeviations(xValues, totals);
    CheckNumber(`${testId}-r-${field}`, `${label}: Pearson r, ${field} vs total (SciPy)`, reference.pearson[field].r, result.r);
    CheckNumber(`${testId}-rnp-${field}`, `${label}: Pearson r, ${field} vs total (NumPy)`, reference.pearson[field].numpy, result.r);
    CheckNumber(`${testId}-rdev-${field}`, `${label}: deviation-form cross-check, ${field}`, reference.pearson[field].r, check.r);
  }

  // Unusual observations (|z| >= 2 for x or total): same transactions and same r-without as Python.
  for (const field of stats.serviceKeys) {
    const result = stats.FlagUnusualObservations(stats.GetValues(rows, field), totals, 2);
    const flaggedList = result.flagged.map(item => item.index + 1);
    const ref = reference.unusual[field];
    CheckTrue(`${testId}-unusual-${field}`, `${label}: unusual transactions for ${field} (Python statistics)`,
      JSON.stringify(ref.flagged), JSON.stringify(flaggedList), JSON.stringify(ref.flagged) === JSON.stringify(flaggedList));
    if (ref.rWithout === null) {
      CheckTrue(`${testId}-unusualr-${field}`, `${label}: r without unusual points, ${field}`, 'null', String(result.rWithout), result.rWithout === null);
    } else {
      CheckNumber(`${testId}-unusualr-${field}`, `${label}: r without unusual points, ${field} (SciPy)`, ref.rWithout, result.rWithout);
    }
  }

  // Graph data: each normalized series spans exactly 0..100 and has one point per transaction.
  for (const field of stats.variableKeys) {
    const normalized = stats.NormalizeSeries(stats.GetValues(rows, field));
    CheckTrue(`${testId}-graph-${field}`, `${label} ${field}: graph data has ${rows.length} points from 0 to 100`,
      `${rows.length} points, min 0, max 100`,
      `${normalized.length} points, min ${Math.min(...normalized)}, max ${Math.max(...normalized)}`,
      normalized.length === rows.length && Math.min(...normalized) === 0 && Math.max(...normalized) === 100);
  }

  // Interpretations adapt to the variable (units differ and wording is not copy-pasted).
  const texts = stats.variableKeys.map(field =>
    stats.InterpretStatistics(stats.Describe(stats.GetValues(rows, field), 'sample'), field));
  CheckTrue(`${testId}-units`, `${label}: variance wording uses ₱², pages², hours²`,
    '₱² / pages² / hours²', stats.variableKeys.map(f => stats.SquaredUnit(f)).join(' / '),
    texts[3].variance.caution.includes('₱²') && texts[0].variance.caution.includes('pages²') &&
    texts[2].variance.caution.includes('hours²'));
  const distinctMeans = new Set(texts.map(text => text.mean.relevance));
  CheckTrue(`${testId}-distinct`, `${label}: four variables get four different business explanations`,
    '4 distinct texts', `${distinctMeans.size} distinct texts`, distinctMeans.size === 4);
  const correlationText = stats.InterpretCorrelation(
    stats.PearsonCorrelation(stats.GetValues(rows, 'print'), totals), 'print', { simulated: true });
  CheckTrue(`${testId}-causation`, `${label}: correlation text warns about causation and other services`,
    'mentions causation and other services', 'checked',
    /causation/.test(correlationText.caution) && /scanning, and rental/.test(correlationText.caution));
  const cards = stats.InterpretCorrelationCards(stats.PearsonCorrelation(stats.GetValues(rows, 'print'), totals), 'print', { simulated: true },
    stats.FlagUnusualObservations(stats.GetValues(rows, 'print'), totals, 2));
  CheckTrue(`${testId}-cards`, `${label}: six interpretation cards, each with text`, '6 cards', `${Object.keys(cards).length} cards`,
    Object.keys(cards).length === 6 && Object.values(cards).every(card => card.title && card.text.length > 40));
  CheckTrue(`${testId}-cards-lesson`, `${label}: strength card quotes the lesson table row`, 'mentions "of the lesson"', cards.strength.text,
    /of the lesson's table/.test(cards.strength.text));
  CheckTrue(`${testId}-cards-business`, `${label}: business card mentions the shop and the Rate Analyzer for a strong r`, 'mentions Rate Analyzer', cards.business.text.slice(0, 60),
    /Rate Analyzer/.test(cards.business.text) || /Check the other/.test(cards.business.text) || /Bills barely/.test(cards.business.text));
  return rows;
}

// TEST 3 — invalid, missing, and insufficient data
function RunInvalidTests() {
  const valid = ReadCsv('dataset1.csv');
  const Copy = () => valid.map(row => ({ ...row }));
  const WithChange = (index, field, value) => { const rows = Copy(); rows[index][field] = value; return rows; };

  CheckThrows('T3-a', 'fewer than 20 observations (19 rows)', Copy().slice(0, 19), /At least 20/);
  CheckThrows('T3-b', 'empty dataset', [], /At least 20/);
  CheckThrows('T3-c', 'missing (empty) printing value in row 3', WithChange(2, 'print', ''), /missing/, 2);
  CheckThrows('T3-d', 'nonnumeric text in scanning value, row 5', WithChange(4, 'scan', 'abc'), /valid non-negative number/, 4);
  CheckThrows('T3-e', 'negative rental hours, row 7', WithChange(6, 'rent', '-1'), /valid non-negative number|non-negative/, 6);
  CheckThrows('T3-f', 'fractional printing quantity (2.5 pages), row 2', WithChange(1, 'print', '2.5'), /whole-number/, 1);
  CheckThrows('T3-g', 'total with more than two decimals (10.005), row 9', WithChange(8, 'total', '10.005'), /two decimal/, 8);
  CheckThrows('T3-h', 'negative total, row 10', WithChange(9, 'total', -5), /non-negative/, 9);
  CheckThrows('T3-i', 'scientific notation text is rejected, row 4', WithChange(3, 'rent', '1e3'), /valid non-negative number/, 3);
  CheckThrows('T3-j', 'null value, row 1', WithChange(0, 'total', null), /missing/, 0);
  CheckThrows('T3-k', 'NaN value, row 6', WithChange(5, 'print', NaN), /non-negative/, 5);
  CheckThrows('T3-l', 'Infinity value, row 8', WithChange(7, 'scan', Infinity), /non-negative/, 7);
  CheckThrows('T3-m', 'a row that is not an object', [...Copy().slice(0, 19), 42], /four required fields/, 19);

  let message = 'no error';
  try { stats.ValidateTransactions('not a list', 20); } catch (error) { message = error.message; }
  CheckTrue('T3-n', 'dataset that is not a list', 'error', message, /list of transactions/.test(message));

  const accepted = stats.ValidateTransactions(WithChange(0, 'total', '66.50'), 20);
  CheckNumber('T3-o', 'valid peso amount with centavos (66.50) is accepted', 66.5, accepted[0].total);
  const zeros = stats.ValidateTransactions(WithChange(0, 'print', '0'), 20);
  CheckNumber('T3-p', 'zero quantity is accepted (service not used)', 0, zeros[0].print);
}

// EDGE CASES — constant values, zero variance, tiny samples
function RunEdgeCases() {
  const constant = Array.from({ length: 20 }, () => 7);
  const varied = Array.from({ length: 20 }, (_, index) => index + 1);
  const sampleStats = stats.Describe(constant, 'sample');
  CheckNumber('E-1', 'identical values: sample variance is 0', 0, sampleStats.variance);
  CheckNumber('E-2', 'identical values: population standard deviation is 0', 0, stats.Describe(constant, 'population').standardDeviation);
  const constantX = stats.PearsonCorrelation(constant, varied);
  CheckTrue('E-3', 'constant x → Pearson r is undefined (null), not 0', 'r = null', `r = ${constantX.r}`, constantX.r === null);
  const constantY = stats.PearsonCorrelation(varied, constant);
  CheckTrue('E-4', 'constant y → Pearson r is undefined (null), not 0', 'r = null', `r = ${constantY.r}`, constantY.r === null);
  CheckTrue('E-5', 'constant series check in deviation form is also undefined', 'r = null',
    `r = ${stats.PearsonByDeviations(constant, varied).r}`, stats.PearsonByDeviations(constant, varied).r === null);
  const undefinedText = stats.InterpretCorrelation(constantX, 'scan', {});
  CheckTrue('E-6', 'undefined correlation gets a plain explanation, not a coefficient', 'says "undefined"', undefinedText.headline,
    /undefined/i.test(undefinedText.headline));
  const flat = stats.NormalizeSeries(constant);
  CheckTrue('E-7', 'constant series normalizes to 50 without dividing by zero', 'all 50', `all ${flat[0]}`, flat.every(value => value === 50));
  const perfect = stats.PearsonCorrelation(varied, varied.map(value => 3 * value + 5));
  CheckNumber('E-8', 'perfect positive line → r = 1', 1, perfect.r);
  const reversed = stats.PearsonCorrelation(varied, varied.map(value => 100 - 2 * value));
  CheckNumber('E-9', 'perfect negative line → r = −1', -1, reversed.r);

  let message = 'no error';
  try { stats.Variance([5], 'sample'); } catch (error) { message = error.message; }
  CheckTrue('E-10', 'sample variance with one observation is refused', 'error', message, /not enough observations/.test(message));
  CheckNumber('E-11', 'population variance with one observation is 0', 0, stats.Variance([5], 'population'));
  message = 'no error';
  try { stats.Describe(varied, 'median'); } catch (error) { message = error.message; }
  CheckTrue('E-12', 'unknown formula mode is refused', 'error', message, /sample or population/.test(message));
  CheckNumber('E-13', 'median of an even count averages the two middle values', 2.5, stats.Median([4, 1, 3, 2]));
  CheckNumber('E-14', 'median of an odd count is the middle value', 3, stats.Median([5, 1, 3]));

  // A service nobody used: zero variance for that variable, usage count 0.
  const rows = varied.map(value => ({ print: value, scan: 0, rent: 1, total: 5 * value + 10 }));
  const usage = stats.CountServiceUsage(rows);
  CheckTrue('E-15', 'usage counts: printing 20, rental 20, scanning 0', 'print 20, rent 20, scan 0',
    usage.map(item => `${item.field} ${item.count}`).join(', '),
    usage.find(item => item.field === 'scan').count === 0 && usage[0].count === 20);
  CheckTrue('E-16', 'all-zero scanning column gives undefined r for scanning', 'r = null',
    `r = ${stats.PearsonCorrelation(stats.GetValues(rows, 'scan'), stats.GetValues(rows, 'total')).r}`,
    stats.PearsonCorrelation(stats.GetValues(rows, 'scan'), stats.GetValues(rows, 'total')).r === null);
  const text = stats.InterpretStatistics(stats.Describe(stats.GetValues(rows, 'scan'), 'sample'), 'scan');
  CheckTrue('E-17', 'all-zero scanning interpretation mentions that no transaction used the service', 'mentions 20 of 20',
    text.mean.finding, /20 of 20/.test(text.mean.finding));
  const chartText = stats.InterpretChart(rows, 'all');
  CheckTrue('E-18', 'all-four chart text explains flat series drawn at 50', 'mentions 50', 'checked', /drawn flat at 50/.test(chartText));
}

// STRENGTH TABLE FROM THE LESSON (Module 7) AND THE LESSON'S OWN EXAMPLES
function RunLessonTests() {
  const table = [
    [0.95, 'very high positive'], [0.90, 'very high positive'], [0.85, 'high positive'], [0.70, 'high positive'],
    [0.60, 'moderate positive'], [0.50, 'moderate positive'], [0.40, 'low positive'], [0.30, 'low positive'],
    [0.29, 'negligible'], [0.0, 'negligible'], [-0.29, 'negligible'], [-0.35, 'low negative'],
    [-0.55, 'moderate negative'], [-0.75, 'high negative'], [-0.95, 'very high negative']
  ];
  for (const [r, label] of table) {
    const observed = stats.ClassifyCorrelation(r).label;
    CheckTrue(`L-class-${r}`, `strength of r = ${r} follows the lesson table`, label, observed, observed === label);
  }
  const examples = {
    'Teacher Roi (late count vs. grade)': [[5, 10, 4, 0, 7], [78, 70, 89, 94, 76], -0.9501192922374602],
    'Sample #1 (hours vs. exam score)': [[2, 3, 4, 5, 6, 7, 8, 9, 10, 11], [65, 75, 82, 88, 92, 98, 105, 112, 118, 122], 0.996976663981028],
    'Sample #2 (car age vs. price)': [[1, 2, 2, 3, 4, 5], [29, 25, 21, 18, 15, 15], -0.9261883899547664]
  };
  for (const [name, [x, y, reference]] of Object.entries(examples)) {
    CheckNumber(`L-${name}`, `lesson example ${name}: r (SciPy)`, reference, stats.PearsonCorrelation(x, y).r);
  }
  const low = stats.InterpretCorrelation(stats.PearsonCorrelation(
    [1, 2, 3, 4, 5, 6, 7, 8], [3, 9, 2, 8, 4, 7, 1, 10]), 'scan', {});
  CheckTrue('L-negligible-text', 'a negligible r is not described as "tend to have higher bills"', 'no "tend to"', low.meaning.slice(0, 60),
    !/tend to have (higher|lower)/.test(low.meaning));
}

// DATA CHECK AND DATA TYPE WORDING
function RunDataTests() {
  const clean = stats.ValidateTransactions(ReadCsv('dataset1.csv'), 20);
  const cleanChecks = stats.CheckDataQuality(clean);
  CheckTrue('D-clean', 'data check passes everything for the valid dataset', '0 warnings', `${cleanChecks.filter(item => item.status === 'warn').length} warnings`,
    cleanChecks.every(item => item.status === 'pass'));
  const odd = clean.map(row => ({ ...row }));
  odd[0] = { print: 0, scan: 0, rent: 0, total: 25 };      // total paid, nothing used
  odd[1] = { print: 3, scan: 1, rent: 1, total: 0 };       // services used, nothing paid
  odd[3] = { ...odd[2] };                                  // exact duplicate of transaction 3
  const oddText = stats.CheckDataQuality(odd).filter(item => item.status === 'warn').map(item => item.text).join(' | ');
  CheckTrue('D-nosvc', 'warns about a total paid with no service used (transaction 1)', 'mentions Transaction 1', oddText.slice(0, 80), /Transaction 1: a total was paid but no service/.test(oddText));
  CheckTrue('D-free', 'warns about services used with a ₱0 total (transaction 2)', 'mentions Transaction 2', oddText.slice(80, 200), /Transaction 2: services were used but the total is ₱0/.test(oddText));
  CheckTrue('D-dup', 'warns about an exact duplicate row (transaction 4)', 'mentions (4)', oddText.slice(200, 320), /repeats? an earlier row exactly \(4\)/.test(oddText));
  const flat = clean.map(row => ({ ...row, scan: 2 }));
  CheckTrue('D-flat', 'warns when a variable never changes', 'mentions scanning pages', 'checked', stats.CheckDataQuality(flat).some(item => item.status === 'warn' && /scanning pages never changes/.test(item.text)));
  const single = Array.from({ length: 20 }, (_, index) => ({ print: index < 6 ? index + 1 : 0, scan: index >= 6 ? 1 : 0, rent: 0, total: index < 6 ? (index + 1) * (index % 2 === 0 ? 5 : 12) : 3 }));
  CheckTrue('D-price', 'warns when single-service price per unit varies widely', 'mentions per unit', 'checked', stats.CheckDataQuality(single).some(item => /per unit/.test(item.text)));
  const types = ['simulated', 'actual', 'public'].map(dataType => stats.OriginSentence({ dataType }));
  CheckTrue('D-origin', 'each data type gets its own origin wording', '3 distinct sentences', `${new Set(types).size} distinct`, new Set(types).size === 3);
  CheckTrue('D-origin-builtin', 'only the built-in sample is described with the list-price rule', 'built-in mentions ₱5', 'checked',
    /₱5 print/.test(stats.OriginSentence({ dataType: 'simulated', builtIn: true })) && !/₱5 print/.test(stats.OriginSentence({ dataType: 'simulated' })));
  CheckTrue('D-origin-unset', 'an undeclared data type says so', 'not been declared', stats.OriginSentence({ dataType: '' }),
    /not been declared/.test(stats.OriginSentence({ dataType: '' })));
}

// LINEAR ALGEBRA REGRESSION — original math.js against NumPy
function RunLinearAlgebraRegression() {
  for (const [name, reference] of Object.entries(laExpected)) {
    const transactions = reference.rows.map(([print, scan, rent, total]) => ({ print, scan, rent, total }));
    const result = ShopRateMath.SolveRates(transactions);
    CheckTrue(`LA-${name}-class`, `math.js classification for "${name}"`, reference.classification, result.classification,
      result.classification === reference.classification);
    if (reference.solution) {
      ['print', 'scan', 'rent'].forEach((key, index) => {
        CheckNumber(`LA-${name}-${key}`, `math.js ${key} rate for "${name}" (NumPy solve)`, reference.solution[index], result.rates[key], 1e-9);
      });
    }
  }
  const unsuitable = ShopRateMath.SolveRates([
    { print: 1, scan: 1, rent: 0, total: 0 }, { print: 0, scan: 1, rent: 0, total: 1 }, { print: 0, scan: 0, rent: 1, total: 1 }]);
  CheckTrue('LA-unsuitable', 'negative printing rate is flagged as unsuitable', 'status = unsuitable', `status = ${unsuitable.status}`,
    unsuitable.status === 'unsuitable');
  const invalid = ShopRateMath.SolveRates([{ print: '10 5', scan: 2, rent: 1, total: 66 }, { print: 5, scan: 5, rent: 2, total: 60 }, { print: 20, scan: 0, rent: 1, total: 110 }]);
  CheckTrue('LA-invalid', 'invalid input is rejected', 'status = invalid', `status = ${invalid.status}`, invalid.status === 'invalid');
  const bill = ShopRateMath.CalculateBill({ print: 10, scan: 2, rent: 1 }, { print: 5, scan: 3, rent: 10 });
  CheckNumber('LA-bill', 'CalculateBill: 10×5 + 2×3 + 1×10 = 66', 66, bill.total);
}

CompareDataset('T1', 'Dataset 1 (built-in simulated, 24 rows)', 'dataset1.csv', 'dataset1');
CompareDataset('T2', 'Dataset 2 (second simulated set, 30 rows, centavo totals)', 'dataset2.csv', 'dataset2');
RunInvalidTests();
RunEdgeCases();
RunLessonTests();
RunDataTests();
RunLinearAlgebraRegression();

const lines = log.map(item => `${item.status}  ${item.id.padEnd(16)} ${item.description}\n      expected: ${item.expected}\n      observed: ${item.observed}`);
const summary = `\n${log.length - failures} of ${log.length} checks passed, ${failures} failed.`;
console.log(lines.join('\n') + summary);
fs.mkdirSync(path.join(__dirname, 'results'), { recursive: true });
fs.writeFileSync(path.join(__dirname, 'results', 'node-test-results.txt'), lines.join('\n') + summary + '\n');
process.exit(failures === 0 ? 0 : 1);
