# ShopRate v9: revision after lesson review

Based on the exact v9 ZIP uploaded with AdvStat Lessons.pdf on November 10, 2026.

- Sample (n−1) is the default; Population remains selectable.
- View Solution switches mean/count notation correctly between x̄/n and μ/N, including mean substitution and median positions.
- Scatter flags use the lesson’s 1.5×IQR fences with medians of halves; all points stay in main analysis.
- Pearson View Solution now shows Q1, Q3, IQR and both fences for the selected quantity and total paid.
- Graph explanations, limitations, tooltips and independent Python reference flags use the same rule.
- Independent verification methods and existing sample/population computations remain.
- Focused tests cover the actual lesson example, both tails, equality with fences, zero IQR, both modes, live graph annotation, formula symbols and all original workflows.
- Original CSV records, Linear Algebra source and pages are unchanged.

Use current screenshots and sample variance/SD in the statistical report. Old Population-default captures and the transaction-17 two-SD ring no longer describe the revised website.
