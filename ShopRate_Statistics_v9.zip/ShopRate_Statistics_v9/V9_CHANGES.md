# v9 review update

- Circled unusual scatter observations using the same two-SD rule as the interpretation; all dots retained, tooltips included.
- Printing restored for both plots on sample loading; removed all-four graph option from the interface.
- Restored the existing four-step verification builder as a separate view with a final-section button and return navigation.
- Removed redundant “pesos” captions on currency descriptive tiles; retained variance units and added a concrete explanation of why deviations are squared.
- Business interpretations retain practical uses and current findings while avoiding unsupported main-driver, forecasting, and residual-attribution claims.
- Identified SD-to-mean spread thresholds as app-specific guides and emphasized that low correlation does not remove service value.
- Corrected CSV/source and graph-selection hints without changing the read-only provenance field.
- Replaced obsolete browser selectors with current-layout regression tests; refreshed README, report outline, and test documentation.
- No original Linear Algebra source or dataset values changed.

## Plain-language follow-up
- Final review: restored squared-unit labels on variance tiles, summary tables and worked solutions; retained the short explanation in View Solution.
- Short technical definitions followed by practical implications, shared by analyzer and solution views.
- Checked every descriptive field/mode and Pearson field in both supplied datasets.
- Added reproducible fresh independent verification without regenerating dataset files.

Final caption adjustment: descriptive currency values are numeric only, with pesos underneath; variance uses pesos² underneath. Applied to analyzer tiles and solution final-answer cards. All 304 browser and 208 calculation checks rerun successfully.

Population (N) is now the default formula on initial load; Sample remains available. 307/307 browser checks passed.
