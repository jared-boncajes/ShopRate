# Current v9 review update — verification results

## Calculation suite
`node tests/test-stats.js`: **208/208 checks passed, 0 failed**. Tests compare both supplied datasets against stored independent Python references, all four variables, both formula modes, Pearson, unusual observations, invalid inputs, edge cases, lesson examples, and selected original Linear Algebra functionality.

## Current browser suite
`SHOPRATE_CHROMIUM=/usr/bin/chromium python3 tests/ui-tests.py`: **304/304 checks passed, 0 failed**. Chromium used the suite's temporary HTTP server. This is a newly executed current-layout suite, not the old 221-check historical result.

Covered: both datasets; displayed mean, median, variance, SD, minimum and maximum for every variable and both modes; currency caption visibility; variance explanation; business relevance; short business explanations; all three correlation coefficients; graph point/ring counts against independent reference flags; worked solutions; four verification steps; Python dataset recognition; spreadsheet row ranges; CSV import; insufficient, missing, nonnumeric, negative and fractional inputs; constant-variable undefined correlation; low-correlation explanation; printing defaults; all-four option removal; overflow at 1440/1024/768/390 px; original-page loading; no JavaScript runtime errors.

Logs: tests/results/node-test-results.txt and ui-test-results.txt. Full-page capture: tests/results/statistics-updated.png. A passing load check for original pages does not constitute exhaustive interaction testing of those pages. Responsive overflow checks do not establish every possible device/browser layout.

The current run additionally checks both View Solution pages: all four descriptive variables in sample and population modes, six descriptive steps, correct variance final answers, squared-unit explanation, all three Pearson coefficients, five Pearson steps, and successful cross-checks for both datasets.

Fresh independent verification: `python3 tests/verify-reference.py` passed **76/76** checks, recomputing all six descriptive statistics plus both variance/SD modes and Pearson values from the existing CSVs using Python statistics, NumPy and SciPy. See tests/results/independent-python-results.txt.

## In-app verification
The final section restores **View Verification** using the existing verification builder. It includes alternative calculation routes, independent Python recorded references, row-specific spreadsheet formulas, and live known-answer tests. Recognized supplied datasets receive live comparisons with recorded Python values. Edited/custom datasets are explicitly marked as not matching those references. With no analyzed data, known-answer tests remain available.

## Integrity and limitations
Original Linear Algebra source and supplied datasets are unchanged. Graph annotations retain unusual observations. No significance tests or validated forecasts are introduced. Simulated findings describe generated records and should not be presented as evidence about real customers. Full original Linear Algebra rubric compliance and individual defense remain outside automated verification.
