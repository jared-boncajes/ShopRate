# v9 lesson-alignment revision: executed checks

## Calculation suite
`node tests/test-stats.js`: **279/279 passed, 0 failed**. All existing descriptive, Pearson, validation and selected Linear Algebra checks remain. Added independent-reference checks for every IQR quartile/fence, the lesson p.73 house-price example, p.56 even-count quartiles, strict fence equality, both tails and zero-IQR cases.

## Independent Python
`python3 tests/verify-reference.py`: **128/128 passed**. Recomputes the unchanged CSV datasets using Python statistics, NumPy and SciPy without executing JavaScript. Covers both variance modes, Pearson, medians-of-halves fences, flagged transaction numbers and sensitivity r. The generator's reference update changes only outlier metadata; all descriptive/Pearson values and both CSV files are unchanged.

## Browser suite
`SHOPRATE_CHROMIUM=/usr/bin/chromium python3 tests/ui-tests.py`: **342/342 passed, 0 failed**. The current run is recorded in tests/results/ui-test-results.txt. It tests the sample default; displayed results for both datasets, all variables and formula modes; x̄/n versus μ/N in every descriptive solution; IQR fence tables; retained points and circles on a deliberately extreme dataset; known synthetic fence values; unchanged full-data Pearson; constant-variable handling; input error messages; CSV import; four verification steps; recognized Python references; and main/solution overflow checks at 1440, 1024, 768 and 390 pixels.

Browser execution uses a temporary loopback HTTP server and installed Chromium via SHOPRATE_CHROMIUM. It captures sample and population descriptive solutions, the Pearson/IQR solution and the analyzer. JavaScript runtime errors are recorded as failures.

## Website verification
View Verification still has four steps: independent formula routes, recorded Python comparisons, spreadsheet reproduction, and live known-answer tests. Both supplied valid datasets produce 62/62 matching checks. With no analyzed dataset, the 16 known-answer tests can still run; that does not approve invalid inputs. The optional r² explanation and independent verification algorithms remain.

## Lesson-specific outcomes
- Mean, median, both variances/SDs, Pearson and its class bands follow the supplied lessons.
- Potential outliers now use the lesson p.56 quartiles and pp.72–73 1.5×IQR fences, with no automatic removal.
- Neither included valid set has IQR flags. The older transaction-17 two-SD circle is no longer applicable.
- Both mean and count notation track the selected Sample/Population mode.

These checks do not establish statistical significance, customer representativeness, individual defense completion or full compliance with an unavailable separate Linear Algebra rubric. No additional application feature was introduced beyond the reviewed corrections.
