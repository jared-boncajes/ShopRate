# Data Dictionary — ShopRate Statistics Analyzer

One row = one customer transaction at a computer shop (an observation). Minimum 20 observations.

| Symbol | Variable (CSV column) | What it measures | Unit | Charged at (Rate Analyzer) | Allowed values |
|---|---|---|---|---|---|
| P | Printing pages (`print`) | Pages printed in the transaction | pages | ₱ per page | whole number, 0 or more |
| S | Scanning pages (`scan`) | Pages scanned in the transaction | pages | ₱ per page | whole number, 0 or more |
| R | Rental hours (`rent`) | Hours of computer rental in the transaction | hours | ₱ per hour | whole number, 0 or more |
| ₱ | Total paid (`total`) | Amount paid for the whole transaction | peso (₱) | sum of the three charges, plus any discount or fee | 0 or more, at most 2 decimals |

Transaction numbers are record order, not dates.

## Data types (declared by the user in the app)
* **Simulated**: artificially generated. Must be labeled as such.
* **Actual**: transactions recorded by the group or a shop. Source description required (who, where, when).
* **Publicly sourced**: taken from a public source. Source description required (publisher, title, link or date).

## Datasets included
| Test case | File | Rows | Type | Source |
|---|---|---|---|---|
| I. Valid dataset | `tests/data/dataset1.csv` (also built into the page) | 24 | Simulated | List prices ₱5 / ₱3 / ₱10; volume price (pages beyond 20 at ₱4), 10% student discount, ₱5 add-on fee on some transactions; generated with `tests/make_reference.py` (seed 11) |
| II. Second verified dataset | `tests/data/dataset2.csv` | 30 | Simulated | List prices ₱4.50 / ₱2.75 / ₱12.50 plus a random extra of ₱0 to ₱9; seed 2026 |
| III. Invalid / insufficient dataset | built into the page (Load Sample) | 15 | Simulated (deliberately invalid) | First 15 rows of test case I with a blank, a negative and a fractional value |

None of the included data are actual customer records. Replace them with the group's own collected data if available (choose "Actual" and describe the source).
