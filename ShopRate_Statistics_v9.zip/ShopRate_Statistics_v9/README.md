# ShopRate Statistics v9 — updated

Group 2 · BSCS 3A. One HTML/CSS/JavaScript application integrates the original Linear Algebra Rate Analyzer and Bill Calculator with an Advanced Statistics page.

## Run
Extract the archive and retain its folder structure. Open Overview.html or Statistics.html in a modern browser. If local-file navigation is restricted, run `python3 -m http.server 8000` in this folder and open the Statistics.html page through that server. No account, database, or application installation is required.

## Statistics workflow
1. Load a built-in sample, edit the table, or import CSV (`print,scan,rent,total`).
2. For replacement data, choose Simulated, Actual, or Publicly sourced. The source description remains automatic and read-only; document exact external provenance in the report.
3. Analyze at least 20 valid rows. Missing, nonnumeric, negative, fractional service quantities and totals with more than two decimal places are rejected.
4. Review six descriptive measures, the four-variable summary, sample/population selection, and worked solutions.
5. Review three service-versus-total Pearson coefficients and five interpretation cards for the selected service.
6. View two graphs: selectable service-versus-total scatter and single-variable transaction bars. Both initially show printing, and loading any sample restores printing. The all-four normalized graph option has been removed.
7. Read spending, usage, relationships, and limitations; open **View Verification** in the final section.

## Findings and interpretation
Interpretations combine current values with practical uses: a typical-bill reference, spread in service quantities and bills, resource usage, and service mix. Correlation describes association; it does not identify the main cause, isolate a service effect, or validate a forecast. Negligible correlation does not make a service unimportant. Interpretations use a short definition or finding followed by its practical business meaning.

Variance tiles, summary tables and worked results explicitly label squared units: pesos² for bills, pages² for printing/scanning, and hours² for rental. View Solution explains that its calculation unit is squared because deviations are squared; standard deviation returns spread to original units. Descriptive currency cards show numeric values with “pesos” underneath; variance cards use “pesos²”. This also applies to View Solution final-answer cards.

## Data and methods
See DATA_DICTIONARY.md and tests/data/dataset1.csv (24 simulated records) and dataset2.csv (30 simulated records). Test case III contains 15 deliberately invalid/incomplete records. Baseline primary rates are ₱5/₱3/₱10 with specified discounts and fees; see tests/make_reference.py for seeds and generation rules. All included records are simulated.

Sample variance uses n−1; population variance uses N. Pearson uses the class computational formula and is undefined if either variable is constant. Strength bands follow the project's lesson table, not significance testing. Unusual observations are at least two sample SDs from the x or total mean, circled in orange with tooltips, and retained. The sensitivity result without flagged observations is explanatory only.

## Verification
The restored verification view has four steps: live alternative-route recomputation, comparison with stored independent Python references when a supplied dataset is recognized, spreadsheet formulas for the actual row count, and live known-answer tests. Browser checks are internal cross-checks; Python is not executed in the browser. Unrecognized custom data are not claimed to have been independently verified by Python. The view can open with no analyzed data and still run known-answer tests.

## Tests
- `node tests/test-stats.js` — dependency-free calculation, validation, and selected Linear Algebra regression checks.
- `python3 tests/ui-tests.py` — current-layout browser regression suite; requires Playwright (`python3 -m pip install playwright`) and its Chromium (`python3 -m playwright install chromium`). Set `SHOPRATE_CHROMIUM=/path/to/chromium` to use an installed browser.
- `python3 tests/verify-reference.py` — fresh independent recalculation of the two existing CSV datasets using Python statistics, NumPy, and SciPy; does not regenerate datasets or execute ShopRate JavaScript.
- `python3 tests/make_reference.py` — optional regeneration using Python statistics, NumPy, and SciPy; writes reference CSV/JSON files.

Results: TEST_RESULTS.md and tests/results/. The browser suite starts its own ephemeral loopback server and preserves failure status. Original Linear Algebra source files have not been changed by this update. Full compliance with the separate original rubric still requires that rubric.

Population (N) is the initial formula selection, matching the report’s description of the complete simulated dataset. Sample (n−1) remains selectable.
