# Final ADVSTAT review

Reviewed against the supplied FINALS PROJECT – BSCS3A ADVANCED STATISTICS document.

## Application features
1. Dataset preparation: 24 primary and 30 secondary simulated observations, labeled variables/units, source and generation rules, replacement CSV/manual datasets.
2. Descriptive statistics: mean, median, variance, standard deviation, minimum, maximum; sample/population choices and worked formulas. Variance correctly uses squared units.
3. Analysis: Pearson coefficients, computations, selected-service interpretation. Checked against the supplied lesson PDF p.153; its strength table matches p.154.
4. Visualization: two titled graphs with axes and units; printing defaults; unusual points circled and retained.
5. Interpretation: descriptive findings, correlation results, practical business uses and limitations; no causal claims or significance-test claims.
6. Verification/input validation: recorded independent Python references, fresh Python verification, internal alternative routes, spreadsheet formulas and known-answer tests; missing/nonnumeric/insufficient values produce messages and prevent analysis.

## Executed final checks
- Node: 279/279 passed.
- Fresh independent Python: 128/128 passed.
- Current browser: 342/342 passed; coverage includes mode-specific mean symbols and IQR solution/graph behavior.

## Submission boundaries
The application is complete against the six ADVSTAT feature requirements based on these checks. No additional statistics feature is required. This is not a claim of guaranteed grade or completion of the separate Linear Algebra rubric.

This ZIP includes source, setup instructions, datasets, data dictionary and statistical test cases. REPORT_OUTLINE.md is an outline, not the completed short report required for submission. Submit the completed report separately with two figures, findings, interpretation, limitations and verification; add truthful names/contributions. The required demonstration (20 minutes) and individual Q&A (10 minutes) must still be completed. Original Linear Algebra requirements remain subject to their separate rubric, which was not supplied.

Sample is the default. IQR fences use the documented medians-of-halves convention from the lesson, and all flags remain in the full-data results. See LESSON_ALIGNMENT.md.
