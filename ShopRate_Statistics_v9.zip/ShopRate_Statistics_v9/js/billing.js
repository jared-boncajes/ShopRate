
'use strict';

document.addEventListener('DOMContentLoaded', () => {

    const printInput = document.getElementById('print-input');
    const scanInput = document.getElementById('scan-input');
    const rentInput = document.getElementById('rent-input');

    const printRate = document.getElementById('print-rate');
    const scanRate = document.getElementById('scan-rate');
    const rentRate = document.getElementById('rent-rate');

    const printSummary = document.getElementById('print-summary');
    const scanSummary = document.getElementById('scan-summary');
    const rentSummary = document.getElementById('rent-summary');

    const printSubtotal = document.getElementById('print-subtotal');
    const scanSubtotal = document.getElementById('scan-subtotal');
    const rentSubtotal = document.getElementById('rent-subtotal');

    const totalDisplay = document.getElementById('total-display');
    const ratesStatus = document.getElementById('rates-status');
    const billingMessage = document.getElementById('billing-message');
    const recalculateBtn = document.getElementById('recalculate-btn');

    const RATES_STORAGE_KEY = 'shoprate_solved_rates';

    let solvedRates = null;

    function formatCurrency(value) {
        return '₱' + ShopRateMath.FormatMoney(value);
    }

    let ratesError = '';

    function loadRates() {
        solvedRates = null;
        ratesError = '';

        try {
            const saved = localStorage.getItem(RATES_STORAGE_KEY);
            let rates;

            if (!saved) {
                // First visit: use the rates calculated from Sample 1.
                const sampleOne = [
                    { print: 10, scan: 2, rent: 1, total: 66 },
                    { print: 5, scan: 5, rent: 2, total: 60 },
                    { print: 20, scan: 0, rent: 1, total: 110 }
                ];
                const sampleResult = ShopRateMath.SolveRates(sampleOne);
                rates = sampleResult.status === 'success' ? sampleResult.rates : null;
                ratesStatus.textContent = 'SAMPLE 1 RATES';
            } else {
                const savedResult = JSON.parse(saved);

                if (savedResult.status !== 'success') {
                    ratesStatus.textContent = 'RATES UNAVAILABLE';
                    ratesError = savedResult.message ||
                        'The latest analysis did not produce valid service rates.';
                    return;
                }

                rates = savedResult.rates;
                ratesStatus.textContent = 'RATES SOLVED';
            }

            const keys = ['print', 'scan', 'rent'];
            const valid = keys.every(key =>
                typeof rates?.[key] === 'number' &&
                Number.isFinite(rates[key]) &&
                rates[key] >= 0
            );

            if (!valid) {
                ratesStatus.textContent = 'INVALID RATES';
                ratesError = 'The latest rates are unavailable or invalid.';
                return;
            }

            solvedRates = {
                print: rates.print,
                scan: rates.scan,
                rent: rates.rent
            };

        } catch (error) {
            ratesStatus.textContent = 'RATES UNAVAILABLE';
            ratesError = 'Unable to load service rates. Please recalculate in the Rate Analyzer.';
        }
    }

    function displayRates() {
        if (!solvedRates) {
            printRate.textContent = 'Rate unavailable';
            scanRate.textContent = 'Rate unavailable';
            rentRate.textContent = 'Rate unavailable';
            return;
        }

        printRate.textContent =
            formatCurrency(solvedRates.print) + ' / page';

        scanRate.textContent =
            formatCurrency(solvedRates.scan) + ' / page';

        rentRate.textContent =
            formatCurrency(solvedRates.rent) + ' / hour';
    }

    function clearBill(message) {
        printSubtotal.textContent = '--';
        scanSubtotal.textContent = '--';
        rentSubtotal.textContent = '--';
        totalDisplay.textContent = '--';
        billingMessage.textContent = message;
    }

    function calculateBill() {
        const quantities = {
            print: printInput.value,
            scan: scanInput.value,
            rent: rentInput.value
        };

        printSummary.textContent =
            'Printing - ' + quantities.print + ' pages';

        scanSummary.textContent =
            'Scanning - ' + quantities.scan + ' pages';

        rentSummary.textContent =
            'Rental - ' + quantities.rent + ' hours';

        const inputs = [printInput, scanInput, rentInput];

        const invalidInput = inputs.some(input =>
            input.value.trim() === '' ||
            !input.validity.valid ||
            !Number.isSafeInteger(Number(input.value))
        );

        if (invalidInput) {
            clearBill(
                'Enter a non-negative whole number for each service.'
            );
            return;
        }

        if (typeof ShopRateMath === 'undefined') {
            clearBill('The math module is not available.');
            return;
        }

        if (!solvedRates) {
            clearBill(
                ratesError || 'Calculate rates in the Rate Analyzer first.'
            );
            return;
        }

        const result = ShopRateMath.CalculateBill(
            quantities,
            solvedRates
        );

        if (result.status !== 'success') {
            clearBill(result.message);
            return;
        }

        printSubtotal.textContent =
            '₱' + result.formattedSubtotals.print;

        scanSubtotal.textContent =
            '₱' + result.formattedSubtotals.scan;

        rentSubtotal.textContent =
            '₱' + result.formattedSubtotals.rent;

        totalDisplay.textContent =
            '₱' + result.formattedTotal;

        billingMessage.textContent = '';
    }

    function refreshCalculator() {
        loadRates();
        displayRates();
        calculateBill();
    }

    printInput.addEventListener('input', calculateBill);
    scanInput.addEventListener('input', calculateBill);
    rentInput.addEventListener('input', calculateBill);

    recalculateBtn.addEventListener('click', () => {
        window.location.href = 'RateAnalyzer.html';
    });

    window.addEventListener('pageshow', refreshCalculator);

    window.addEventListener('storage', event => {
        if (event.key === RATES_STORAGE_KEY || event.key === null) {
            refreshCalculator();
        }
    });

    refreshCalculator();
});
