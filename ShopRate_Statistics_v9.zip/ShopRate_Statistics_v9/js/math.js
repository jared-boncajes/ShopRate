'use strict';

/**
 * Computer Shop Service Rate Analyzer
 * Standalone, browser-ready JavaScript. No dependencies.
 *
 * Input: [{ print, scan, rent, total }, ...] (exactly three transactions)
 * Output: ShopRateMath.SolveRates(transactions)
 * Billing: ShopRateMath.CalculateBill({ print, scan, rent }, rates)
 *
 * Naming: camelCase variables/properties; PascalCase functions.
 * Rates and arithmetic remain unrounded. Formatted values are strings.
 */
const ShopRateMath = (() => {
  const serviceKeys = Object.freeze(['print', 'scan', 'rent']);
  const transactionKeys = Object.freeze([...serviceKeys, 'total']);
  const symbols = Object.freeze(['P', 'S', 'R']);
  const units = Object.freeze({
    print: 'per printed page',
    scan: 'per scanned page',
    rent: 'per rental hour'
  });
  const relativeTolerance = 1e-10;

  function MakeError(code, message, field = null, transactionIndex = null) {
    return { code, message, field, transactionIndex };
  }

  function InvalidResult(errors) {
    return {
      status: 'invalid',
      classification: 'invalid',
      message: errors[0].message,
      errors,
      suitable: false,
      rates: null,
      formattedRates: null
    };
  }

  // Validate before converting: Number('') and Number('   ') would otherwise be 0.
  function ParseNumber(value, field, location, wholeNumber = false, allowFractionalRate = false) {
    if (typeof value !== 'number' && typeof value !== 'string') {
      throw MakeError('INVALID_TYPE', `${location}: ${field} must be a number.`, field);
    }

    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(trimmed)) {
        throw MakeError('INVALID_NUMBER', `${location}: ${field} must contain a valid non-negative number.`, field);
      }
      value = Number(trimmed);
    }

    if (!Number.isFinite(value) || value < 0) {
      throw MakeError('INVALID_NUMBER', `${location}: ${field} must be finite and non-negative.`, field);
    }
    if (wholeNumber && !Number.isSafeInteger(value)) {
      throw MakeError('INVALID_QUANTITY', `${location}: ${field} must be a non-negative whole number.`, field);
    }
    if (!wholeNumber && !allowFractionalRate) {
      // Historical transaction totals are currency values with at most two decimals.
      const cents = value * 100;
      if (!Number.isSafeInteger(Math.round(cents)) ||
          Math.abs(cents - Math.round(cents)) > 1e-7) {
        throw MakeError('INVALID_CURRENCY', `${location}: ${field} must have at most two decimal places.`, field);
      }
    }
    return value;
  }

  function ValidateObject(value, requiredKeys, location) {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
      throw MakeError('INVALID_OBJECT', `${location} must be an object.`);
    }
    const missingKeys = requiredKeys.filter(key => !Object.prototype.hasOwnProperty.call(value, key));
    if (missingKeys.length) {
      throw MakeError('MISSING_FIELDS', `${location} is missing: ${missingKeys.join(', ')}.`, missingKeys[0]);
    }
    const extraKeys = Object.keys(value).filter(key => !requiredKeys.includes(key));
    if (extraKeys.length) {
      throw MakeError('UNEXPECTED_FIELDS', `${location} has unexpected fields: ${extraKeys.join(', ')}.`, extraKeys[0]);
    }
  }

  function ValidateTransactions(transactions) {
    if (!Array.isArray(transactions) || transactions.length !== 3) {
      throw MakeError('TRANSACTION_COUNT', 'Exactly three transactions are required.');
    }
    return transactions.map((transaction, index) => {
      const location = `Transaction ${index + 1}`;
      try {
        ValidateObject(transaction, transactionKeys, location);
        const clean = {};
        for (const key of transactionKeys) {
          clean[key] = ParseNumber(transaction[key], key, location, key !== 'total');
        }
        return clean;
      } catch (error) {
        error.transactionIndex = index;
        throw error;
      }
    });
  }

  function Determinant3x3(matrix) {
    const [[a, b, c], [d, e, f], [g, h, i]] = matrix;
    return a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);
  }

  function DeterminantExpansion(matrix) {
    const [[a, b, c], [d, e, f], [g, h, i]] = matrix;
    const terms = [
      a * (e * i - f * h),
      -b * (d * i - f * g),
      c * (d * h - e * g)
    ];
    return {
      method: 'firstRowCofactorExpansion',
      terms,
      expression: `${a}(${e}×${i} − ${f}×${h}) − ${b}(${d}×${i} − ${f}×${g}) + ${c}(${d}×${h} − ${e}×${g})`,
      value: terms.reduce((sum, term) => sum + term, 0)
    };
  }

  function ReplaceColumn(matrix, vector, columnIndex) {
    return matrix.map((row, rowIndex) =>
      row.map((value, index) => index === columnIndex ? vector[rowIndex] : value)
    );
  }

  function CloneMatrix(matrix) {
    return matrix.map(row => [...row]);
  }

  function IsZero(value, scale = 1) {
    return Math.abs(value) <= relativeTolerance * Math.max(1, scale);
  }

  /**
   * Gauss-Jordan elimination with partial pivoting.
   * Classification uses coefficient rank vs augmented rank.
   * This is numerical floating-point arithmetic, not symbolic exact arithmetic.
   */
  function RowReduce(matrix, vector) {
    const reducedMatrix = matrix.map((row, index) => [...row, vector[index]]);
    const steps = [];
    const pivotColumns = [];
    const variableCount = matrix[0].length;
    const rowCount = reducedMatrix.length;
    const originalScale = Math.max(1, ...matrix.flat().map(Math.abs));
    const augmentedScale = Math.max(originalScale, ...vector.map(Math.abs));
    let pivotRow = 0;

    // Row-operation labels use the form  Ri → Ri - kRj  (k omitted when it is 1)
    function Coefficient(value) {
      const rounded = Number(Math.abs(value).toFixed(6));
      return rounded === 1 ? '' : String(rounded);
    }
    function RecordStep(operation) {
      steps.push({ operation, matrix: CloneMatrix(reducedMatrix) });
    }
    RecordStep('Initial augmented matrix');

    for (let column = 0; column < variableCount && pivotRow < rowCount; column++) {
      let bestRow = pivotRow;
      for (let row = pivotRow + 1; row < rowCount; row++) {
        if (Math.abs(reducedMatrix[row][column]) > Math.abs(reducedMatrix[bestRow][column])) {
          bestRow = row;
        }
      }
      if (IsZero(reducedMatrix[bestRow][column], originalScale)) continue;

      if (bestRow !== pivotRow) {
        [reducedMatrix[pivotRow], reducedMatrix[bestRow]] =
          [reducedMatrix[bestRow], reducedMatrix[pivotRow]];
        RecordStep(`R${pivotRow + 1} ↔ R${bestRow + 1}`);
      }

      const pivot = reducedMatrix[pivotRow][column];
      for (let index = 0; index <= variableCount; index++) {
        reducedMatrix[pivotRow][index] /= pivot;
      }
      const divisor = Number(pivot.toFixed(6));
      RecordStep(`R${pivotRow + 1} → R${pivotRow + 1} / ${divisor < 0 ? `(${divisor})` : divisor}`);

      for (let row = 0; row < rowCount; row++) {
        if (row === pivotRow) continue;
        const factor = reducedMatrix[row][column];
        if (IsZero(factor, originalScale)) continue;
        for (let index = 0; index <= variableCount; index++) {
          reducedMatrix[row][index] -= factor * reducedMatrix[pivotRow][index];
        }
        reducedMatrix[row][column] = 0;
        RecordStep(`R${row + 1} → R${row + 1} ${factor < 0 ? '+' : '-'} ${Coefficient(factor)}R${pivotRow + 1}`);
      }
      pivotColumns.push(column);
      pivotRow++;
    }

    const inconsistentRows = [];
    for (let row = 0; row < rowCount; row++) {
      const coefficientsAreZero = reducedMatrix[row]
        .slice(0, variableCount)
        .every(value => IsZero(value, originalScale));
      if (coefficientsAreZero && !IsZero(reducedMatrix[row][variableCount], augmentedScale)) {
        inconsistentRows.push(row);
      }
    }

    const freeColumns = Array.from({ length: variableCount }, (_, index) => index)
      .filter(index => !pivotColumns.includes(index));
    const classification = inconsistentRows.length
      ? 'inconsistent'
      : pivotColumns.length === variableCount ? 'unique' : 'dependent';

    // Each pivot variable is written as: constant + sum(coefficient × parameter).
    const parameters = freeColumns.map(column => ({
      variable: serviceKeys[column],
      symbol: symbols[column],
      column,
      parameter: symbols[column]
    }));
    const parameterizedSolution = classification !== 'dependent' ? null : {
      parameters,
      expressions: serviceKeys.map((variable, column) => {
        const free = parameters.find(item => item.column === column);
        if (free) {
          return { variable, symbol: symbols[column], free: true, constant: 0,
            terms: [{ parameter: free.parameter, coefficient: 1 }] };
        }
        const row = pivotColumns.indexOf(column);
        return {
          variable,
          symbol: symbols[column],
          free: false,
          constant: reducedMatrix[row][variableCount],
          terms: parameters.map(item => ({
            parameter: item.parameter,
            coefficient: -reducedMatrix[row][item.column]
          }))
        };
      })
    };

    return {
      classification,
      reducedMatrix,
      steps,
      pivotColumns,
      freeColumns,
      freeVariables: freeColumns.map(column => serviceKeys[column]),
      pivotVariables: pivotColumns.map(column => serviceKeys[column]),
      inconsistentRows,
      rankA: pivotColumns.length,
      rankAugmented: pivotColumns.length + (inconsistentRows.length ? 1 : 0),
      parameterizedSolution
    };
  }

  function VerifySolution(matrix, vector, rates) {
    const rateValues = serviceKeys.map(key => rates[key]);
    return matrix.map((row, index) => {
      const calculated = row.reduce((sum, coefficient, column) =>
        sum + coefficient * rateValues[column], 0);
      const expected = vector[index];
      const difference = calculated - expected;
      const scale = Math.max(1, Math.abs(calculated), Math.abs(expected));
      return {
        transaction: index + 1,
        expected,
        calculated,
        difference,
        passed: Math.abs(difference) <= relativeTolerance * scale
      };
    });
  }

  function FormatMoney(amount) {
    return typeof amount === 'number' && Number.isFinite(amount)
      ? amount.toFixed(2)
      : null;
  }

  function BuildInterpretation(classification, rates = null, freeVariables = []) {
    if (classification === 'unique' && rates) {
      return `One printed page costs ₱${FormatMoney(rates.print)}, ` +
        `one scanned page costs ₱${FormatMoney(rates.scan)}, and one hour of computer rent costs ₱${FormatMoney(rates.rent)}.`;
    }
    if (classification === 'dependent') {
      return `The transactions are consistent but do not determine unique service rates. ` +
        `Free variables: ${freeVariables.join(', ')}.`;
    }
    if (classification === 'inconsistent') {
      return 'The transactions contradict each other; no single set of service rates satisfies all totals.';
    }
    return 'The input or computed service rates cannot be used for billing.';
  }

  function SolveRates(transactions) {
    let cleanTransactions;
    try {
      cleanTransactions = ValidateTransactions(transactions);
    } catch (error) {
      return InvalidResult([error && error.code ? error : MakeError('INVALID_INPUT', 'Invalid transaction data.')]);
    }

    const matrix = cleanTransactions.map(item => [item.print, item.scan, item.rent]);
    const vector = cleanTransactions.map(item => item.total);
    const augmentedMatrix = matrix.map((row, index) => [...row, vector[index]]);
    const equations = cleanTransactions.map((item, index) => ({
      transaction: index + 1,
      coefficients: [item.print, item.scan, item.rent],
      total: item.total,
      expression: `${item.print}P + ${item.scan}S + ${item.rent}R = ${item.total}`
    }));
    const determinant = Determinant3x3(matrix);
    const determinantExpansion = DeterminantExpansion(matrix);
    const coefficientScale = Math.max(1, ...matrix.flat().map(Math.abs));
    const determinantIsZero = IsZero(determinant, coefficientScale ** 3);
    const base = {
      matrix,
      vector,
      augmentedMatrix,
      equations,
      determinant,
      determinantExpansion,
      variables: [...serviceKeys],
      symbols: [...symbols]
    };

    if (determinantIsZero) {
      const rowReduction = RowReduce(matrix, vector);
      return {
        ...base,
        status: rowReduction.classification,
        classification: rowReduction.classification,
        message: rowReduction.classification === 'dependent'
          ? ' Dependent System – Infinitely Many Solutions | No unique service rates!'
          : 'Inconsistent System – No Solution | No valid service rates!',
        interpretation: BuildInterpretation(rowReduction.classification, null, rowReduction.freeVariables),
        suitable: false,
        rates: null,
        formattedRates: null,
        replacementMatrices: null,
        determinants: null,
        verification: null,
        rowReduction,
        freeVariables: rowReduction.freeVariables,
        parameterizedSolution: rowReduction.parameterizedSolution
      };
    }

    const replacementMatrices = {};
    const determinants = {};
    const rates = {};
    for (let column = 0; column < serviceKeys.length; column++) {
      const key = serviceKeys[column];
      replacementMatrices[key] = ReplaceColumn(matrix, vector, column);
      determinants[key] = Determinant3x3(replacementMatrices[key]);
      rates[key] = determinants[key] / determinant;
    }

    const verification = VerifySolution(matrix, vector, rates);
    const nonNegative = serviceKeys.every(key =>
      Number.isFinite(rates[key]) && rates[key] >= 0
    );
    const verified = verification.every(item => item.passed);
    const suitable = nonNegative && verified;
    const formattedRates = Object.fromEntries(
      serviceKeys.map(key => [key, FormatMoney(rates[key])])
    );
    return {
      ...base,
      status: suitable ? 'success' : 'unsuitable',
      classification: 'unique',
      message: suitable ? '<<< UNIQUE SERVICE RATES FOUND AND VERIFIED >>>'
        : 'A unique mathematical solution exists, but the rates are unsuitable or verification failed.',
      interpretation: suitable ? BuildInterpretation('unique', rates)
        : 'The mathematical solution cannot be used as reliable non-negative computer shop rates.',
      suitable,
      rates,
      formattedRates,
      replacementMatrices,
      determinants,
      verification,
      rowReduction: null,
      freeVariables: [],
      parameterizedSolution: null
    };
  }

  /**
   * CalculateBill({ print, scan, rent }, { print, scan, rent })
   * Inputs may be numbers or numeric strings. Rates must be non-negative finite numbers; full precision is preserved.
   * Returns a result object; does not throw on ordinary invalid user input.
   */
  function CalculateBill(quantities, rates) {
    try {
      ValidateObject(quantities, serviceKeys, 'Bill quantities');
      ValidateObject(rates, serviceKeys, 'Service rates');
      const cleanQuantities = {};
      const cleanRates = {};
      for (const key of serviceKeys) {
        cleanQuantities[key] = ParseNumber(quantities[key], key, 'Bill quantities', true);
        // Keep full-precision solved rates; do not require them to have two decimals.
        const rateValue = rates[key];
        if (typeof rateValue !== 'number' && typeof rateValue !== 'string') {
          throw MakeError('INVALID_RATE', `Service rates: ${key} must be numeric.`, key);
        }
        if (typeof rateValue === 'string' && !/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(rateValue.trim())) {
          throw MakeError('INVALID_RATE', `Service rates: ${key} must be numeric.`, key);
        }
        cleanRates[key] = Number(rateValue);
        if (!Number.isFinite(cleanRates[key]) || cleanRates[key] < 0) {
          throw MakeError('INVALID_RATE', `Service rates: ${key} must be finite and non-negative.`, key);
        }
      }

      const subtotals = {};
      for (const key of serviceKeys) {
        subtotals[key] = cleanQuantities[key] * cleanRates[key];
      }
      const total = serviceKeys.reduce((sum, key) => sum + subtotals[key], 0);
      if (!Number.isFinite(total) || !Number.isSafeInteger(Math.round(total * 100))) {
        throw MakeError('BILL_OVERFLOW', 'The calculated bill is too large to represent safely.');
      }
      return {
        status: 'success',
        message: 'Bill calculated successfully.',
        quantities: cleanQuantities,
        rates: cleanRates,
        subtotals,
        formattedSubtotals: Object.fromEntries(
          serviceKeys.map(key => [key, FormatMoney(subtotals[key])])
        ),
        total,
        formattedTotal: FormatMoney(total)
      };
    } catch (error) {
      return {
        status: 'invalid',
        message: error && error.message ? error.message : 'Invalid billing input.',
        errors: [error && error.code ? error : MakeError('INVALID_INPUT', 'Invalid billing input.')],
        total: null,
        formattedTotal: null,
        subtotals: null,
        formattedSubtotals: null
      };
    }
  }

  return Object.freeze({
    SolveRates,
    CalculateBill,
    FormatMoney,
    Determinant3x3,
    RowReduce
  });
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ShopRateMath;
}
