'use strict';

/**
 * ShopRate Statistics Analyzer — reusable, dependency-free calculations.
 *
 * Input : transaction objects shaped like { print, scan, rent, total }.
 * Output: validated transactions, descriptive statistics, Pearson's r,
 *         independent cross-checks, service-usage counts, and plain-language
 *         interpretations for non-technical readers.
 *
 * Naming follows ShopRate's original math.js:
 *   PascalCase functions; camelCase variables and object properties.
 *
 * This file never touches the page (no document, no DOM). That keeps it easy to
 * test in Node and easy to explain: every function takes numbers and returns numbers or text.
 *
 * Important: "sample" vs "population" is a FORMULA choice (n - 1 vs N).
 * It says nothing about whether the records are simulated, imported, or real.
 */
const ShopRateStats = (() => {
  const variableKeys = Object.freeze(['print', 'scan', 'rent', 'total']);
  const serviceKeys = Object.freeze(['print', 'scan', 'rent']);
  const minimumTransactions = 20;

  // Lower-case names are used inside sentences; titles are used on labels.
  const variableNames = Object.freeze({
    print: 'printing pages',
    scan: 'scanning pages',
    rent: 'rental hours',
    total: 'total transaction cost'
  });
  const variableTitles = Object.freeze({
    print: 'Printing pages',
    scan: 'Scanning pages',
    rent: 'Rental hours',
    total: 'Total paid (₱)'
  });
  const variableUnits = Object.freeze({
    print: 'pages', scan: 'pages', rent: 'hours', total: 'pesos'
  });

  // Business wording that is specific to each variable, so the four variables
  // do not all receive the same generic explanation.
  const businessUse = Object.freeze({
    print: {
      meanUse: 'estimate how much paper and ink or toner an average visit uses',
      medianUse: 'describe a usual print job without being distorted by a few very large jobs',
      spreadUse: 'wide differences in print size make paper, toner, and printer time harder to plan',
      lowUse: 'the smallest print job recorded, including visits with no printing at all',
      highUse: 'the largest print job recorded, which matters for paper reserves and printer time'
    },
    scan: {
      meanUse: 'estimate how busy the scanner is during a typical visit',
      medianUse: 'describe a usual scanning request without being distorted by the occasional large document',
      spreadUse: 'widely varying scan sizes make scanner time harder to schedule',
      lowUse: 'the smallest scanning request recorded, including visits with no scanning',
      highUse: 'the largest scanning request recorded, which shows how long one customer can occupy the scanner'
    },
    rent: {
      meanUse: 'estimate how long a typical visit occupies a computer, which helps judge how many computers are needed',
      medianUse: 'describe a usual rental session without being distorted by a few very long sessions',
      spreadUse: 'a mix of short and long sessions makes computer availability harder to plan',
      lowUse: 'the shortest rental session recorded, including visits with no rental',
      highUse: 'the longest rental session recorded, which shows how long one computer can be tied up'
    },
    total: {
      meanUse: 'compare smaller and larger bills against a per-transaction sales reference in these records',
      medianUse: 'describe a usual bill that a few very large orders do not distort, which provides a starting point for reviewing package sizes alongside costs and actual demand',
      spreadUse: 'widely varying bills make daily sales harder to forecast from the average bill alone',
      lowUse: 'the smallest bill recorded, which helps when thinking about minimum charges and small change on hand',
      highUse: 'the largest bill recorded, which shows how big a single sale can be and how much change a cashier may need'
    }
  });

  // 1. INPUT VALIDATION ---------------------------------------------------

  // Errors carry rowIndex so the page can highlight the row that needs fixing.
  function MakeRowError(message, rowIndex) {
    const error = new Error(message);
    error.rowIndex = rowIndex;
    return error;
  }

  function ParseNumber(value, field, index) {
    const location = `Transaction ${index + 1}: ${variableTitles[field]}`;
    if (typeof value !== 'number' && typeof value !== 'string') {
      throw MakeRowError(`${location} is missing. Enter a non-negative number.`, index);
    }
    if (typeof value === 'string' && value.trim() === '') {
      throw MakeRowError(`${location} is missing. Enter a non-negative number.`, index);
    }
    if (typeof value === 'string' && !/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(value.trim())) {
      throw MakeRowError(`${location} must be a valid non-negative number.`, index);
    }
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed < 0) {
      throw MakeRowError(`${location} must be finite and non-negative.`, index);
    }
    if (field !== 'total' && !Number.isSafeInteger(parsed)) {
      throw MakeRowError(`${location} must be a whole-number quantity.`, index);
    }
    if (field === 'total') {
      // Money has at most two decimal places (centavos).
      const cents = parsed * 100;
      if (!Number.isSafeInteger(Math.round(cents)) ||
          Math.abs(cents - Math.round(cents)) > 1e-7) {
        throw MakeRowError(`${location} may have at most two decimal places.`, index);
      }
    }
    return parsed;
  }

  function ValidateTransactions(transactions, minimumRows = minimumTransactions) {
    if (!Array.isArray(transactions)) {
      throw new Error('The dataset must be a list of transactions.');
    }
    if (transactions.length < minimumRows) {
      throw new Error(`At least ${minimumRows} complete transactions are required. Currently: ${transactions.length}.`);
    }
    return transactions.map((transaction, index) => {
      if (!transaction || typeof transaction !== 'object' || Array.isArray(transaction)) {
        throw MakeRowError(`Transaction ${index + 1} must contain the four required fields.`, index);
      }
      const clean = {};
      for (const field of variableKeys) {
        clean[field] = ParseNumber(transaction[field], field, index);
      }
      return clean;
    });
  }

  function CheckFormulaMode(formulaMode) {
    if (formulaMode !== 'sample' && formulaMode !== 'population') {
      throw new Error('Choose either sample or population formulas.');
    }
  }

  function GetValues(transactions, field) {
    if (!variableKeys.includes(field)) throw new Error('Unknown transaction variable.');
    return transactions.map(transaction => transaction[field]);
  }

  // 2. DESCRIPTIVE STATISTICS --------------------------------------------
  function Sum(values) {
    return values.reduce((total, value) => total + value, 0);
  }

  function Mean(values) {
    return Sum(values) / values.length;
  }

  function Median(values) {
    const sorted = [...values].sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return sorted.length % 2 === 1
      ? sorted[middle]
      : (sorted[middle - 1] + sorted[middle]) / 2;
  }

  // Σ(x − mean)². Squaring keeps below-average and above-average
  // deviations from cancelling each other out.
  function SumSquaredDeviations(values, mean) {
    return Sum(values.map(value => (value - mean) ** 2));
  }

  // Sample divides by n − 1 (an estimate of a larger group's variability).
  // Population divides by N (the observations ARE the whole group of interest).
  function VarianceDivisor(count, formulaMode) {
    CheckFormulaMode(formulaMode);
    return formulaMode === 'sample' ? count - 1 : count;
  }

  function Variance(values, formulaMode = 'sample') {
    CheckFormulaMode(formulaMode);
    if (values.length < (formulaMode === 'sample' ? 2 : 1)) {
      throw new Error('There are not enough observations for the chosen variance formula.');
    }
    const divisor = VarianceDivisor(values.length, formulaMode);
    return SumSquaredDeviations(values, Mean(values)) / divisor;
  }

  function StandardDeviation(values, formulaMode = 'sample') {
    return Math.sqrt(Variance(values, formulaMode));
  }

  // Independent check of Variance(): the "computational" form uses raw sums
  // instead of deviations:  [Σx² − (Σx)²/n] / divisor.
  function VarianceByRawSums(values, formulaMode = 'sample') {
    const count = values.length;
    const sumX = Sum(values);
    const sumX2 = Sum(values.map(value => value ** 2));
    return (sumX2 - sumX ** 2 / count) / VarianceDivisor(count, formulaMode);
  }

  // One row per observation for the "show your work" variance table.
  function DeviationRows(values) {
    const mean = Mean(values);
    return values.map(value => ({
      value,
      deviation: value - mean,
      squared: (value - mean) ** 2
    }));
  }

  function Describe(values, formulaMode = 'sample') {
    CheckFormulaMode(formulaMode);
    if (!Array.isArray(values) || values.length < 2 ||
        values.some(value => typeof value !== 'number' || !Number.isFinite(value))) {
      throw new Error('Descriptive statistics require at least two finite numeric values.');
    }
    const mean = Mean(values);
    const minimum = Math.min(...values);
    const maximum = Math.max(...values);
    const variance = Variance(values, formulaMode);
    return {
      n: values.length,
      formulaMode,
      divisor: VarianceDivisor(values.length, formulaMode),
      sum: Sum(values),
      mean,
      median: Median(values),
      variance,
      standardDeviation: Math.sqrt(variance),
      min: minimum,
      max: maximum,
      range: maximum - minimum,
      zeroCount: values.filter(value => value === 0).length,
      sumSquaredDeviations: SumSquaredDeviations(values, mean)
    };
  }

  // 3. PEARSON CORRELATION -----------------------------------------------
  // Computational formula:
  //   r = [nΣxy − (Σx)(Σy)] / √{[nΣx² − (Σx)²][nΣy² − (Σy)²]}
  // r is undefined when x or y has no variation (a zero appears under the root).
  function PearsonCorrelation(xValues, yValues) {
    if (!Array.isArray(xValues) || !Array.isArray(yValues) ||
        xValues.length !== yValues.length || xValues.length < 2 ||
        [...xValues, ...yValues].some(value => !Number.isFinite(value))) {
      throw new Error('Pearson correlation requires two equally sized numeric series.');
    }
    const n = xValues.length;
    const sumX = Sum(xValues);
    const sumY = Sum(yValues);
    const sumX2 = Sum(xValues.map(value => value ** 2));
    const sumY2 = Sum(yValues.map(value => value ** 2));
    const sumXY = Sum(xValues.map((value, index) => value * yValues[index]));
    const numerator = n * sumXY - sumX * sumY;
    const spreadX = n * sumX2 - sumX ** 2;
    const spreadY = n * sumY2 - sumY ** 2;
    const denominator = Math.sqrt(Math.max(0, spreadX) * Math.max(0, spreadY));
    const nearZeroX = spreadX <= 1e-12 * Math.max(1, n * sumX2);
    const nearZeroY = spreadY <= 1e-12 * Math.max(1, n * sumY2);
    const defined = !nearZeroX && !nearZeroY && Number.isFinite(denominator) && denominator > 0;
    return {
      n, sumX, sumY, sumX2, sumY2, sumXY,
      numerator, spreadX, spreadY, denominator,
      r: defined ? Math.max(-1, Math.min(1, numerator / denominator)) : null,
      reason: defined ? null : 'Pearson correlation is undefined when either variable has no measurable variation.'
    };
  }

  // Independent check of PearsonCorrelation(): the definitional (deviation) form
  //   r = Σ(x − x̄)(y − ȳ) / √[Σ(x − x̄)² · Σ(y − ȳ)²]
  function PearsonByDeviations(xValues, yValues) {
    const meanX = Mean(xValues);
    const meanY = Mean(yValues);
    const sumProducts = Sum(xValues.map((value, index) => (value - meanX) * (yValues[index] - meanY)));
    const sumSquaresX = SumSquaredDeviations(xValues, meanX);
    const sumSquaresY = SumSquaredDeviations(yValues, meanY);
    const defined = sumSquaresX > 1e-12 && sumSquaresY > 1e-12;
    return {
      meanX, meanY, sumProducts, sumSquaresX, sumSquaresY,
      r: defined ? sumProducts / Math.sqrt(sumSquaresX * sumSquaresY) : null
    };
  }

  // Strength of relationship, using the table from the class lesson (Module 7):
  //   .90–1.00 very high · .70–.90 high · .50–.70 moderate · .30–.50 low · .00–.30 negligible
  // A value exactly on a boundary goes to the higher group.
  function ClassifyCorrelation(r) {
    if (r === null) return { strength: 'undefined', direction: 'none', label: 'undefined' };
    const magnitude = Math.abs(r);
    const strength = magnitude >= 0.9 ? 'very high'
      : magnitude >= 0.7 ? 'high'
      : magnitude >= 0.5 ? 'moderate'
      : magnitude >= 0.3 ? 'low'
      : 'negligible';
    const direction = r > 1e-12 ? 'positive' : r < -1e-12 ? 'negative' : 'none';
    const label = strength === 'negligible' ? 'negligible' : `${strength} ${direction}`;
    return { strength, direction, label };
  }

  // Correlate every service quantity with total cost; strongest first.
  function RankServiceCorrelations(transactions) {
    const totals = GetValues(transactions, 'total');
    return serviceKeys.map(field => {
      const result = PearsonCorrelation(GetValues(transactions, field), totals);
      return { field, r: result.r };
    }).sort((first, second) => Math.abs(second.r ?? -1) - Math.abs(first.r ?? -1));
  }

  // Lesson pp. 56 and 72: quartiles are medians of the lower and upper halves.
  // With an odd count, exclude the overall median before taking the half medians.
  function IqrFences(values) {
    if (!Array.isArray(values) || values.length < 2 || values.some(value => !Number.isFinite(value))) {
      throw new Error('IQR checks require at least two finite numeric values.');
    }
    const sorted = [...values].sort((first, second) => first - second);
    const middle = Math.floor(sorted.length / 2);
    const q1 = Median(sorted.slice(0, middle));
    const q3 = Median(sorted.slice(middle + sorted.length % 2));
    const iqr = q3 - q1;
    return { q1, q3, iqr, lower: q1 - 1.5 * iqr, upper: q3 + 1.5 * iqr };
  }

  // Flag a potential outlier when x OR total paid is strictly outside its IQR fences.
  // Equality with a fence is not flagged. All observations stay in the main analysis.
  function FlagUnusualObservations(xValues, yValues) {
    if (!Array.isArray(xValues) || !Array.isArray(yValues) || xValues.length !== yValues.length) {
      throw new Error('IQR checks require equally sized numeric series.');
    }
    const xBounds = IqrFences(xValues);
    const yBounds = IqrFences(yValues);
    const flagged = [];
    xValues.forEach((value, index) => {
      const xOutside = value < xBounds.lower || value > xBounds.upper;
      const yOutside = yValues[index] < yBounds.lower || yValues[index] > yBounds.upper;
      if (xOutside || yOutside) flagged.push({ index, xOutside, yOutside });
    });
    let rWithout = null;
    if (flagged.length > 0 && xValues.length - flagged.length >= 3) {
      const skip = new Set(flagged.map(item => item.index));
      const keptX = xValues.filter((_, index) => !skip.has(index));
      const keptY = yValues.filter((_, index) => !skip.has(index));
      rWithout = PearsonCorrelation(keptX, keptY).r;
    }
    return { method: 'iqr', factor: 1.5, xBounds, yBounds, flagged, rWithout };
  }

  // Data check: the validator has already guaranteed formats and ranges, so these look for
  // patterns that are legal but suspicious. They are warnings; nothing is removed or changed.
  function CheckDataQuality(rows) {
    const list = indexes => {
      const shown = indexes.slice(0, 8).map(index => index + 1).join(', ');
      return indexes.length > 8 ? `${shown} and ${indexes.length - 8} more` : shown;
    };
    const checks = [
      { status: 'pass', text: `${rows.length} complete transactions (the project minimum is ${minimumTransactions}).` },
      { status: 'pass', text: 'Every quantity is a non-negative whole number and every total is a non-negative peso amount with at most 2 decimals.' }
    ];

    const noService = [];
    const freeService = [];
    const seen = new Map();
    const duplicates = [];
    rows.forEach((row, index) => {
      const used = serviceKeys.some(field => row[field] > 0);
      if (!used && row.total > 0) noService.push(index);
      if (used && row.total === 0) freeService.push(index);
      const key = variableKeys.map(field => row[field]).join('|');
      if (seen.has(key)) duplicates.push(index); else seen.set(key, index);
    });
    checks.push(noService.length
      ? { status: 'warn', text: `Transaction${noService.length === 1 ? '' : 's'} ${list(noService)}: a total was paid but no service was used. Check for a missing quantity.` }
      : { status: 'pass', text: 'Every transaction with a total used at least one service.' });
    checks.push(freeService.length
      ? { status: 'warn', text: `Transaction${freeService.length === 1 ? '' : 's'} ${list(freeService)}: services were used but the total is ₱0. This can be a free or promo transaction; confirm it is intended.` }
      : { status: 'pass', text: 'No transaction used a service while paying ₱0.' });
    checks.push(duplicates.length
      ? { status: 'warn', text: `${duplicates.length} transaction${duplicates.length === 1 ? ' repeats' : 's repeat'} an earlier row exactly (${list(duplicates)}). That can be coincidence, or an accidental double entry.` }
      : { status: 'pass', text: 'No transaction repeats an earlier row exactly.' });

    const flat = variableKeys.filter(field => new Set(GetValues(rows, field)).size === 1);
    checks.push(flat.length
      ? { status: 'warn', text: `${flat.map(field => variableNames[field]).join(', ')} never change${flat.length === 1 ? 's' : ''}, so Pearson r is undefined for ${flat.length === 1 ? 'it' : 'them'}.` }
      : { status: 'pass', text: 'Every variable changes across transactions, so correlations can be computed.' });

    // Price per unit for transactions that used only one service: they should be close to each other.
    const pricePerUnit = {};
    for (const field of serviceKeys) {
      const prices = rows
        .filter(row => row[field] > 0 && serviceKeys.every(other => other === field || row[other] === 0))
        .map(row => row.total / row[field]);
      if (prices.length >= 3 && Math.max(...prices) > 1.5 * Math.min(...prices)) {
        pricePerUnit[field] = [Math.min(...prices), Math.max(...prices)];
      }
    }
    const priceIssues = Object.keys(pricePerUnit);
    if (priceIssues.length) {
      checks.push({
        status: 'warn',
        text: priceIssues.map(field => `${Capitalize(variableNames[field])}: single-service transactions work out to ₱${FormatNumber(pricePerUnit[field][0])} to ₱${FormatNumber(pricePerUnit[field][1])} per unit`).join('; ') + '. Large differences can mean data-entry mistakes or mixed price lists.'
      });
    }
    return checks;
  }

  // 4. ADDITIONAL TRANSACTION INSIGHTS -----------------------------------
  function CountServiceUsage(transactions) {
    return serviceKeys.map(field => ({
      field,
      label: variableNames[field],
      count: transactions.filter(transaction => transaction[field] > 0).length
    })).sort((first, second) => second.count - first.count);
  }

  // Each variable gets its OWN 0–100 scale (min → 0, max → 100). A variable that
  // never changes has no range to scale, so it is placed at 50 instead of dividing by zero.
  function NormalizeSeries(values) {
    const minimum = Math.min(...values);
    const maximum = Math.max(...values);
    if (minimum === maximum) return values.map(() => 50);
    // Divide first, then scale: (max − min) / (max − min) is exactly 1, so the top value is exactly 100.
    const range = maximum - minimum;
    return values.map(value => 100 * ((value - minimum) / range));
  }

  // 5. FORMATTING --------------------------------------------------------
  function FormatNumber(value, digits = 2) {
    return Number(value).toLocaleString('en-PH', {
      minimumFractionDigits: digits, maximumFractionDigits: digits
    });
  }

  // Shows only the decimals a number needs (up to 4): 1,912 or 79.6667.
  function FormatPlain(value, maxDigits = 4) {
    const rounded = Number(Number(value).toFixed(maxDigits));
    return (Object.is(rounded, -0) ? 0 : rounded).toLocaleString('en-PH', {
      minimumFractionDigits: 0, maximumFractionDigits: maxDigits
    });
  }

  function SquaredUnit(field) {
    return field === 'total' ? '₱²' : `${variableUnits[field]}²`;
  }

  // Number only (₱ prefix for money), for big display boxes that show the unit separately.
  function FormatQuantity(value, field) {
    if (field === 'total') return `₱${FormatNumber(value)}`;
    return FormatNumber(value, Number.isInteger(value) ? 0 : 2);
  }

  function FormatValue(value, field) {
    return field === 'total' ? FormatQuantity(value, field) : `${FormatQuantity(value, field)} ${variableUnits[field]}`;
  }

  function Capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  // 6. CONTEXT-AWARE INTERPRETATIONS -------------------------------------
  // Every statistic gets four short parts:
  //   meaning   — what the statistic is
  //   finding   — what it says about THIS dataset
  //   relevance — why a shop owner might care
  //   caution   — what it cannot tell us
  function InterpretStatistics(summary, field) {
    if (!variableKeys.includes(field)) throw new Error('Unknown interpretation variable.');
    const name = variableNames[field];
    const use = businessUse[field];
    const money = field === 'total';
    const value = n => FormatValue(n, field);
    const mode = summary.formulaMode === 'sample' ? 'sample' : 'population';
    const unit = money ? 'pesos' : variableUnits[field];
    const zero = !money && summary.zeroCount ? ` ${summary.zeroCount} of ${summary.n} transactions did not use this service.` : '';
    return {
      mean: {
        meaning: 'The mean is the average across all transactions.',
        finding: `The average ${name} is ${value(summary.mean)}.${zero}`,
        relevance: `An owner can use it to ${use.meanUse}.`,
        caution: 'Large transactions can pull the average up; compare it with the median.'
      },
      median: {
        meaning: 'The median is the middle value after sorting.',
        finding: `The middle ${name} is ${value(summary.median)}.`,
        relevance: `It helps to ${use.medianUse}.`,
        caution: 'Read it with the standard deviation to understand how much transactions differ.'
      },
      variance: {
        meaning: `Variance averages squared differences from the mean using the ${mode} formula.`,
        finding: `Variance is ${FormatNumber(summary.variance)} ${SquaredUnit(field)}.`,
        relevance: `It measures spread; use the standard deviation of ${value(summary.standardDeviation)} for an easier comparison in ${unit}.`,
        caution: `Its calculation unit is ${SquaredUnit(field)} because differences are squared; it is not ${money ? 'a bill or an amount to charge' : 'an actual service quantity'}.`
      },
      standardDeviation: {
        meaning: 'Standard deviation measures how spread out the values are around the average.',
        finding: `The standard deviation is ${value(summary.standardDeviation)} around an average of ${value(summary.mean)}.`,
        relevance: `For the shop, ${use.spreadUse}.`,
        caution: 'It describes variation, not a guaranteed range for every transaction.'
      },
      minimum: {
        meaning: 'The minimum is the lowest value recorded.',
        finding: `The lowest ${name} is ${value(summary.min)}.${zero}`,
        relevance: `It shows ${use.lowUse}.`,
        caution: 'It is an observed low, not a minimum charge for future customers.'
      },
      maximum: {
        meaning: 'The maximum is the highest value recorded.',
        finding: `The highest ${name} is ${value(summary.max)}; the range is ${value(summary.range)}.`,
        relevance: `It shows ${use.highUse}.`,
        caution: 'A large order can be unusual; do not assume every customer orders this much.'
      },
      overview: `${Capitalize(name)}: mean ${value(summary.mean)}, median ${value(summary.median)}, ${mode} standard deviation ${value(summary.standardDeviation)}, range ${value(summary.min)} to ${value(summary.max)}.`
    };
  }

  // What the declared data type means for how far the findings can be trusted.
  // context = { dataType: 'simulated' | 'actual' | 'public' | '', builtIn: true only for the unedited built-in sample }
  function OriginSentence(context = {}) {
    if (context.dataType === 'simulated' && context.builtIn) {
      return 'The built-in records are simulated from list prices (₱5 print, ₱3 scan, ₱10 rental) with a few discounts and fees, so patterns here illustrate the method and partly reflect how the data were built; they are not evidence about real customers.';
    }
    if (context.dataType === 'simulated') {
      return 'These records are labeled as simulated, so patterns here partly reflect how they were generated and illustrate the method; they are not evidence about real customers.';
    }
    if (context.dataType === 'actual') {
      return 'These records are labeled as actual transactions, so the findings describe those customers and that period; they may not hold for other shops or other times, and totals are built from service charges, so part of each relationship comes from how bills are computed.';
    }
    if (context.dataType === 'public') {
      return 'These records are labeled as publicly sourced, so the findings are only as reliable as the original source and how it was collected; check that the source matches a computer-shop scenario.';
    }
    return 'The data type has not been declared.';
  }

  // Pearson interpretation (shorter form, used on the solution page).
  function InterpretCorrelation(result, field, context = {}) {
    const name = variableNames[field];
    if (result.r === null) {
      return {
        headline: 'Pearson r is undefined',
        meaning: `Either ${name} or total cost is the same in every transaction. A variable that never changes cannot move together with another variable, so no coefficient is shown instead of a misleading 0.`,
        practical: 'Add transactions that differ in this quantity before looking for a relationship.',
        caution: 'No conclusion about the relationship is possible from this dataset.'
      };
    }
    const cls = ClassifyCorrelation(result.r);
    const rSquared = result.r ** 2;
    const percent = FormatNumber(rSquared * 100, 1);
    let meaning;
    if (cls.strength === 'negligible') {
      meaning = `There is only a negligible straight-line association between ${name} and the total bill. The slight ${cls.direction === 'negative' ? 'downward' : 'upward'} tilt (r = ${FormatNumber(result.r, 4)}) is too small to treat as a pattern.`;
    } else if (cls.direction === 'positive') {
      meaning = `Transactions with more ${name} tend to have higher total bills. A positive r means the two variables tend to increase together.`;
    } else {
      meaning = `Transactions with more ${name} tend to have lower total bills. A negative r means the variables tend to move in opposite directions.`;
    }
    meaning += ` Here r² = ${FormatNumber(rSquared, 4)}, so about ${percent}% of the variation in total paid is linearly associated with ${name} in these records.`;

    const strengthNote = cls.strength === 'very high' || cls.strength === 'high'
      ? `${Capitalize(name)} is a useful rough guide to how large a bill may be.`
      : cls.strength === 'moderate'
        ? `${Capitalize(name)} is partly informative about bill size, but other factors matter too.`
        : `${Capitalize(name)} alone is not a reliable guide to bill size in these records.`;

    const origin = ` ${OriginSentence(context)}`;

    return {
      headline: `r = ${FormatNumber(result.r, 4)} · ${cls.label} linear association`,
      meaning,
      practical: strengthNote + origin,
      caution: `Correlation does not prove causation. A bill combines printing, scanning, and rental charges, so r for ${name} alone does not isolate that service's own contribution. Pearson r also detects only straight-line patterns and can be affected by unusual points.`
    };
  }

  // Shop-specific wording for each service: what it uses up, and how a transaction "uses" it.
  const shopContext = Object.freeze({
    print: { label: 'printing', resource: 'paper, ink or toner, and printer time' },
    scan: { label: 'scanning', resource: 'scanner time' },
    rent: { label: 'computer rental', resource: 'computer seats and rental time' }
  });

  // The class strength table (Module 7), as it is written in the lesson.
  const strengthRows = Object.freeze({
    'very high': '.90 to 1.00 (−.90 to −1.00)',
    high: '.70 to .90 (−.70 to −.90)',
    moderate: '.50 to .70 (−.50 to −.70)',
    low: '.30 to .50 (−.30 to −.50)',
    negligible: '.00 to .30 (.00 to −.30)'
  });

  function ListTransactions(flagged) {
    return flagged.map(item => item.index + 1).join(', ');
  }

  // Short description of how the dots are spread, plus a note on unusual observations.
  function InterpretScatter(result, field, rows, unusual = null) {
    const name = variableNames[field];
    if (result.r === null) {
      return {
        distribution: `Not enough variation to describe a pattern: ${name} or total paid is the same in every transaction.`,
        unusual: unusual && unusual.flagged.length ? `Potential outlier${unusual.flagged.length === 1 ? '' : 's'}, circled: transaction${unusual.flagged.length === 1 ? '' : 's'} ${ListTransactions(unusual.flagged)} under the 1.5 × IQR rule. All transactions are retained.` : 'No potential outliers by the 1.5 × IQR rule.'
      };
    }
    const cls = ClassifyCorrelation(result.r);
    const rising = cls.direction === 'positive';
    const quantities = GetValues(rows, field);
    const noneCount = quantities.filter(value => value === 0).length;
    let shape;
    if (cls.strength === 'negligible') {
      shape = 'The dots form a scattered cloud with no clear upward or downward tilt';
    } else {
      const tilt = rising ? 'rise from lower left to upper right' : 'fall from upper left to lower right';
      shape = cls.strength === 'very high' ? `The dots ${tilt} in a narrow band close to a straight line`
        : cls.strength === 'high' ? `The dots ${tilt} with some scatter around the trend`
        : cls.strength === 'moderate' ? `The dots ${tilt} only loosely, in a wide cloud`
        : `The dots show a faint tilt (${tilt}) buried in a lot of scatter`;
    }
    const spread = `${Capitalize(name)} range from ${Math.min(...quantities)} to ${Math.max(...quantities)}${noneCount > 0 ? `; ${noneCount} transaction${noneCount === 1 ? '' : 's'} used none` : ''}.`;
    let unusualText = 'No potential outliers by the 1.5 × IQR rule.';
    if (unusual && unusual.flagged.length > 0) {
      const count = unusual.flagged.length;
      const without = unusual.rWithout === null ? '' : ` Without ${count === 1 ? 'it' : 'them'}, r would be ${FormatNumber(unusual.rWithout, 4)} instead of ${FormatNumber(result.r, 4)}.`;
      unusualText = `Potential outlier${count === 1 ? '' : 's'}, circled: transaction${count === 1 ? '' : 's'} ${ListTransactions(unusual.flagged)} (outside the 1.5 × IQR fences for ${name} or total paid). ${count === 1 ? 'It is' : 'They are'} kept in the analysis.${without}`;
    }
    return { distribution: `${shape}. ${spread}`, unusual: unusualText };
  }

  // Six short cards that explain one service's r in shop terms, using the lesson's strength table.
  function InterpretCorrelationCards(result, field, context = {}, unusual = null) {
    const name = variableNames[field];
    const shop = shopContext[field];
    if (result.r === null) {
      const text = `${Capitalize(name)} or total paid is the same in every transaction, so r is undefined. Add transactions that differ in ${name} before looking for a relationship.`;
      return {
        direction: { title: 'Direction', text },
        strength: { title: 'Strength (class table)', text: 'No strength can be assigned to an undefined coefficient. A shown 0 would wrongly suggest "no relationship".' },
        variation: { title: 'How much of the variation (r²)', text: 'Not available while r is undefined.' },
        business: { title: 'What it means for the shop', text: `Until ${name} varies across customers, these records cannot say whether it goes together with bill size.` },
        limits: { title: 'What it does not tell us', text: 'No conclusion about the relationship is possible from this dataset.' },
        estimate: { title: 'Sample and point estimate', text: 'No estimate can be given without variation in both variables.' }
      };
    }
    const cls = ClassifyCorrelation(result.r);
    const rSquared = result.r ** 2;
    const percent = FormatNumber(rSquared * 100, 1);
    const rest = FormatNumber(100 - rSquared * 100, 1);
    const strong = cls.strength === 'very high' || cls.strength === 'high';
    const rounded = FormatNumber(result.r, 4);

    const direction = cls.strength === 'negligible'
      ? `There is little straight-line pattern between ${name} and bill size in these records. This quantity alone is not a useful guide to a larger or smaller bill.`
      : `The relationship is ${cls.direction}: more ${name} goes with ${cls.direction === 'positive' ? 'higher' : 'lower'} bills in these records. This describes a pattern, not the reason for it.`;
    const business = cls.strength === 'negligible'
      ? `Bills do not closely follow ${name} alone. The service still adds charges and uses ${shop.resource}; low correlation does not remove its business value.`
      : `Larger ${shop.label} quantities ${cls.direction === 'positive' ? 'tend to appear in larger bills' : 'appear alongside smaller bills in this dataset'}. Review these transactions when checking service mix and ${shop.resource}; the Rate Analyzer, not r, determines service rates.`;
    const flag = unusual && unusual.flagged.length
      ? ` Circled transaction${unusual.flagged.length > 1 ? 's' : ''} ${ListTransactions(unusual.flagged)} ${unusual.flagged.length > 1 ? 'are' : 'is'} unusual but kept.` : '';
    return {
      direction: { title: 'Direction', text: direction },
      strength: { title: 'Strength (class table)', text: `r = ${rounded} is a ${cls.label} relationship under the categories of the lesson's table. This tells how closely the dots follow a straight line, not whether the service is profitable.` },
      variation: { title: 'How much of the variation (r²)', text: `r² = ${FormatNumber(rSquared, 4)}: about ${percent}% of bill variation is accounted for by a simple straight-line fit with ${name}. This is not the service’s share of sales or a causal effect; the remaining ${rest}% is not explained by that fit.` },
      business: { title: 'What it means for the shop', text: business },
      limits: { title: 'What it does not tell us', text: `It does not prove causation or predict future sales; bills combine several charges.${flag} ${context.dataType === 'simulated' ? 'These are simulated records, so findings illustrate the method rather than actual customer behavior.' : 'These findings describe the supplied records; other customers may differ.'}` },
      estimate: { title: 'Scope of the finding', text: `This result describes ${result.n} transactions, not every future customer. Sample or population variance settings do not change r; no significance test is performed.` }
    };
  }

  // Summary sentence(s) for the dashboard that compares the three coefficients.
  function InterpretComparison(ranking) {
    const defined = ranking.filter(item => item.r !== null);
    if (defined.length === 0) {
      return { headline: 'No coefficient can be computed.', text: 'None of the three service quantities varies enough to compare with total paid.' };
    }
    const best = defined[0];
    const bestClass = ClassifyCorrelation(best.r);
    const describe = item => `${Capitalize(variableNames[item.field])} (r = ${FormatNumber(item.r, 2)}, ${ClassifyCorrelation(item.r).label})`;
    const others = defined.slice(1).map(describe).join(' and ');
    const undefinedItems = ranking.filter(item => item.r === null).map(item => variableNames[item.field]);
    const undefinedNote = undefinedItems.length ? ` ${Capitalize(undefinedItems.join(' and '))} never vary, so r is undefined there.` : '';
    let meaning;
    if (bestClass.strength === 'negligible') {
      meaning = 'No single service closely tracks the total bill in these records, so bills differ for several reasons at once.';
    } else {
      meaning = `To understand why one customer's bill is bigger than another's, look first at ${variableNames[best.field]}.`;
    }
    const rest = others ? ` ${others}${defined.length > 2 ? ' follow' : ' follows'}. A low or negligible bar does not make a service unimportant: it still uses scanner time or computer seats and adds its own charge.` : '';
    return {
      headline: `${Capitalize(variableNames[best.field])} has the strongest relationship with total paid (r = ${FormatNumber(best.r, 2)}, ${bestClass.label}).`,
      text: `${meaning}${rest}${undefinedNote} The bars compare how closely each quantity moves with the total; they are not prices per unit, which come from the Rate Analyzer.`
    };
  }

  function InterpretChart(transactions, field) {
    if (field === 'all') {
      const totals = GetValues(transactions, 'total');
      const highestIndex = totals.indexOf(Math.max(...totals));
      const lowestIndex = totals.indexOf(Math.min(...totals));
      const positionOf = key => FormatNumber(NormalizeSeries(GetValues(transactions, key))[highestIndex], 0);
      const constants = variableKeys.filter(key => new Set(GetValues(transactions, key)).size === 1);
      const constantNote = constants.length
        ? ` ${constants.map(key => variableNames[key]).join(', ')} never change${constants.length === 1 ? 's' : ''}, so ${constants.length === 1 ? 'it is' : 'they are'} drawn flat at 50.`
        : '';
      return `Each line is scaled separately so its lowest value is 0 and its highest is 100. These are relative positions, not pages, hours, or pesos, so two lines meeting does not mean equal amounts. Transaction ${highestIndex + 1} has the highest bill (100 on the total line); on the other lines it sits at ${positionOf('print')} for printing, ${positionOf('scan')} for scanning, and ${positionOf('rent')} for rental. Transaction ${lowestIndex + 1} has the lowest bill. Lines that rise and fall together suggest a shared pattern; they do not show cause.${constantNote}`;
    }
    if (!variableKeys.includes(field)) throw new Error('Unknown chart variable.');
    const values = GetValues(transactions, field);
    const mean = Mean(values);
    const aboveMean = values.filter(value => value > mean).length;
    const highestIndex = values.indexOf(Math.max(...values));
    const lowestIndex = values.indexOf(Math.min(...values));
    return `Each bar is one transaction, shown in actual ${variableUnits[field]}. Transaction ${highestIndex + 1} is the highest (${FormatValue(values[highestIndex], field)}) and transaction ${lowestIndex + 1} is the lowest (${FormatValue(values[lowestIndex], field)}). The dashed line marks the mean, ${FormatValue(mean, field)}; ${aboveMean} of ${values.length} transactions are above it. The horizontal axis is a record number, not a date.`;
  }

  // Overall reading of the dataset for the interpretation section.
  function InterpretDataset(transactions, formulaMode, context = {}) {
    const totals = Describe(GetValues(transactions, 'total'), formulaMode);
    const usage = CountServiceUsage(transactions);
    const ranking = RankServiceCorrelations(transactions);
    const count = transactions.length;
    const ratio = totals.mean > 0 ? totals.standardDeviation / totals.mean : 0;
    const spread = ratio < 0.2 ? 'fairly consistent'
      : ratio < 0.5 ? 'moderately varied' : 'widely varied';

    const spending = `Across ${count} transactions, the typical (median) bill is ${FormatValue(totals.median, 'total')} and the average is ${FormatValue(totals.mean, 'total')}. Bills range from ${FormatValue(totals.min, 'total')} to ${FormatValue(totals.max, 'total')} with a standard deviation of ${FormatValue(totals.standardDeviation, 'total')}. The median offers a typical-bill reference for reviewing small versus large transactions; the spread shows why one average cannot describe every bill. These are transaction totals only; expenses are not recorded, so they do not show profit.`;

    const usageText = `${usage.map(item => `${Capitalize(item.label)} appeared in ${item.count} of ${count} transactions`).join('; ')}. This helps identify frequently used services when reviewing paper, scanner time, and computer-seat needs. Frequency does not measure revenue or profit.`;

    const defined = ranking.filter(item => item.r !== null);
    let relationship;
    if (defined.length === 0) {
      relationship = 'No service quantity varies enough to compute a correlation with total cost.';
    } else {
      const best = defined[0];
      const bestClass = ClassifyCorrelation(best.r);
      relationship = `${Capitalize(variableNames[best.field])} has the strongest linear association with total cost (r = ${FormatNumber(best.r, 4)}, ${bestClass.label}). ${defined.slice(1).map(item => `${Capitalize(variableNames[item.field])}: r = ${FormatNumber(item.r, 4)}`).join('; ')}${defined.length > 1 ? '.' : ''} Use these patterns to decide which transactions and service combinations to examine more closely. A negligible correlation does not make a service unimportant: it still contributes charges and uses resources. Because bills combine services and adjustments, none of these coefficients isolates one service's effect or validates a forecast.`;
    }

    const origin = OriginSentence(context);
    const mode = `Sample or population formulas change only the variance and standard deviation; the mean, median, minimum, maximum, and Pearson r stay the same.`;

    return { spending, usage: usageText, relationship, origin, mode };
  }


  // 7. BUILT-IN VERIFICATION ---------------------------------------------
  // Each check recomputes a result by a DIFFERENT route than the main code,
  // so a mistake in one route would show up as a mismatch.
  function IsClose(first, second) {
    return Math.abs(first - second) <= 1e-9 * Math.max(1, Math.abs(first));
  }

  // Welford's running method: updates the mean and Σ(x − mean)² one value at a time.
  function RunningMeanAndSpread(values) {
    let count = 0;
    let mean = 0;
    let sumSquares = 0;
    for (const value of values) {
      count++;
      const delta = value - mean;
      mean += delta / count;
      sumSquares += delta * (value - mean);
    }
    return { mean, sumSquares };
  }

  function VerifyDescriptive(values) {
    const count = values.length;
    const running = RunningMeanAndSpread(values);
    const descending = [...values].sort((a, b) => b - a);
    const middle = Math.floor(count / 2);
    const medianCheck = count % 2 === 1 ? descending[middle] : (descending[middle - 1] + descending[middle]) / 2;
    let lowest = values[0];
    let highest = values[0];
    for (const value of values) {
      if (value < lowest) lowest = value;
      if (value > highest) highest = value;
    }
    const checks = [
      { name: 'Mean', main: Mean(values), check: running.mean, method: 'Running (Welford) average' },
      { name: 'Median', main: Median(values), check: medianCheck, method: 'Sort largest to smallest, take the middle' },
      { name: 'Minimum', main: Math.min(...values), check: lowest, method: 'Scan the list for the smallest' },
      { name: 'Maximum', main: Math.max(...values), check: highest, method: 'Scan the list for the largest' },
      { name: 'Sample variance (n − 1)', main: Variance(values, 'sample'), check: running.sumSquares / (count - 1), method: 'Running sum of squares ÷ (n − 1)' },
      { name: 'Population variance (N)', main: Variance(values, 'population'), check: running.sumSquares / count, method: 'Running sum of squares ÷ N' },
      { name: 'Sample standard deviation', main: StandardDeviation(values, 'sample'), check: Math.sqrt(VarianceByRawSums(values, 'sample')), method: '√ of the raw-sums variance [Σx² − (Σx)²/n] ÷ (n − 1)' },
      { name: 'Population standard deviation', main: StandardDeviation(values, 'population'), check: Math.sqrt(VarianceByRawSums(values, 'population')), method: '√ of the raw-sums variance [Σx² − (Σx)²/n] ÷ N' }
    ];
    return checks.map(item => ({ ...item, ok: IsClose(item.main, item.check) }));
  }

  function VerifyPearson(transactions) {
    const totals = GetValues(transactions, 'total');
    return serviceKeys.map(field => {
      const main = PearsonCorrelation(GetValues(transactions, field), totals).r;
      const check = PearsonByDeviations(GetValues(transactions, field), totals).r;
      const bothUndefined = main === null && check === null;
      return { field, main, check, ok: bothUndefined || (main !== null && check !== null && IsClose(main, check)) };
    });
  }


  // Helper data for the unusual-observation known-answer test.
  function UnusualSample() {
    const x = Array.from({ length: 20 }, (_, index) => index + 1);
    const y = x.map((value, index) => (index === 19 ? 200 : 2 * value));
    return FlagUnusualObservations(x, y);
  }
  function UnusualCheck() {
    const result = UnusualSample();
    return result.flagged.length === 1 ? `flag ${result.flagged[0].index + 1}` : `${result.flagged.length} flagged`;
  }
  function UnusualCheckWithout() {
    return UnusualSample().rWithout;
  }

  // Known-answer tests: results that can be checked by hand.
  function RunKnownAnswerTests() {
    const oneToTwenty = Array.from({ length: 20 }, (_, index) => index + 1);
    const textbook = [2, 4, 4, 4, 5, 5, 7, 9];       // classic example: mean 5, population SD 2
    const constant = Array.from({ length: 20 }, () => 7);
    const cases = [
      { name: 'Values 1 to 20: mean', expected: 10.5, observed: Mean(oneToTwenty) },
      { name: 'Values 1 to 20: median (average of 10 and 11)', expected: 10.5, observed: Median(oneToTwenty) },
      { name: 'Values 1 to 20: sample variance = 20·21/12 = 35', expected: 35, observed: Variance(oneToTwenty, 'sample') },
      { name: 'Values 1 to 20: population variance = (20² − 1)/12 = 33.25', expected: 33.25, observed: Variance(oneToTwenty, 'population') },
      { name: 'Values 2, 4, 4, 4, 5, 5, 7, 9: mean', expected: 5, observed: Mean(textbook) },
      { name: 'Values 2, 4, 4, 4, 5, 5, 7, 9: population standard deviation', expected: 2, observed: StandardDeviation(textbook, 'population') },
      { name: 'Values 2, 4, 4, 4, 5, 5, 7, 9: sample variance = 32/7', expected: 32 / 7, observed: Variance(textbook, 'sample') },
      { name: 'Perfect rising line y = 3x + 5: r', expected: 1, observed: PearsonCorrelation(oneToTwenty, oneToTwenty.map(value => 3 * value + 5)).r },
      { name: 'Perfect falling line y = 100 − 2x: r', expected: -1, observed: PearsonCorrelation(oneToTwenty, oneToTwenty.map(value => 100 - 2 * value)).r },
      { name: 'Lesson example, Teacher Roi (late count vs. final grade): r', expected: -0.9501192922374602, observed: PearsonCorrelation([5, 10, 4, 0, 7], [78, 70, 89, 94, 76]).r },
      { name: 'Lesson Sample #1 (hours studied vs. exam score): r', expected: 0.996976663981028, observed: PearsonCorrelation([2, 3, 4, 5, 6, 7, 8, 9, 10, 11], [65, 75, 82, 88, 92, 98, 105, 112, 118, 122]).r },
      { name: 'Lesson Sample #2 (car age vs. price): r', expected: -0.9261883899547664, observed: PearsonCorrelation([1, 2, 2, 3, 4, 5], [29, 25, 21, 18, 15, 15]).r },
      { name: 'Potential outlier flagged by 1.5 × IQR and kept: x = 1…19 on y = 2x plus one far-off point (transaction 20)', expected: 'flag 20', observed: UnusualCheck() },
      { name: 'r without that unusual point is exactly 1', expected: 1, observed: UnusualCheckWithout() },
      { name: 'Constant x: r is undefined (not 0)', expected: 'undefined', observed: PearsonCorrelation(constant, oneToTwenty).r === null ? 'undefined' : 'a number' },
      { name: 'Constant series on the 0–100 graph scale sits at 50', expected: 50, observed: NormalizeSeries(constant)[0] }
    ];
    return cases.map(item => ({
      ...item,
      ok: typeof item.expected === 'number' ? IsClose(item.expected, item.observed) : item.expected === item.observed
    }));
  }

  return Object.freeze({
    variableKeys, serviceKeys, variableNames, variableTitles, variableUnits,
    minimumTransactions,
    ValidateTransactions, GetValues, Sum, Mean, Median,
    SumSquaredDeviations, Variance, StandardDeviation, VarianceByRawSums,
    DeviationRows, Describe,
    PearsonCorrelation, PearsonByDeviations, ClassifyCorrelation, RankServiceCorrelations, IqrFences,
    CountServiceUsage, NormalizeSeries,
    FormatNumber, FormatPlain, FormatQuantity, FormatValue, SquaredUnit,
    FlagUnusualObservations, CheckDataQuality, OriginSentence,
    InterpretStatistics, InterpretCorrelation, InterpretCorrelationCards, InterpretComparison, InterpretScatter,
    InterpretChart, InterpretDataset,
    VerifyDescriptive, VerifyPearson, RunKnownAnswerTests
  });
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ShopRateStats;
}
