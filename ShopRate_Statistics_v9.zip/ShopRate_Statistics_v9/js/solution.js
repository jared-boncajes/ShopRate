'use strict';

const ShopRateSolution = (() => {
  const keys = ['print', 'scan', 'rent'];
  const symbols = ['P', 'S', 'R'];
  const sections = {};

  function Id(id) { return document.getElementById(id); }

  // ---------- number / text helpers ----------
  function Num(value) {
    const rounded = Number(Number(value).toFixed(6));
    return String(Object.is(rounded, -0) ? 0 : rounded);
  }

  // "5", "- 5" style joiner for sums: [50, 70, -100] -> "50 + 70 - 100"
  function JoinTerms(terms) {
    return terms.map((term, index) => {
      if (index === 0) return Num(term);
      return (term < 0 ? '- ' : '+ ') + Num(Math.abs(term));
    }).join(' ');
  }

  // ---------- builders ----------
  function MatrixHTML(rows, options = {}) {
    const cols = rows[0].length;
    const cells = rows.map(row => row.map((value, col) => {
      const classes = [];
      if (options.augmented && col === cols - 1) classes.push('aug');
      if (options.shadeColumn === col) classes.push('shade');
      return `<span${classes.length ? ` class="${classes.join(' ')}"` : ''}>${Num(value)}</span>`;
    }).join('')).join('');
    return `<div class="matrix"><div class="matrix_grid" style="--cols:${cols}">${cells}</div></div>`;
  }

  function Notice(message) {
    const notice = sections.notice;
    notice.textContent = message;
    notice.hidden = !message;
  }

  // Escapes an operation label from math.js, e.g. "R2 → R2 - 0.5R1" (math.js already formats the numbers)
  function FormatOperation(operation) {
    return operation.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // "P = 6.6 - 0.2S - 0.1R" from math.js's parameterizedSolution expression objects
  function ExpressionText(expression) {
    if (expression.free) return `${expression.symbol} = ${expression.symbol} (free)`;
    const parts = [];
    if (expression.constant !== 0 || expression.terms.every(term => term.coefficient === 0)) {
      parts.push(Num(expression.constant));
    }
    expression.terms.forEach(term => {
      if (term.coefficient === 0) return;
      const size = Math.abs(term.coefficient) === 1 ? '' : Num(Math.abs(term.coefficient));
      const sign = term.coefficient < 0 ? '- ' : '+ ';
      parts.push(parts.length ? `${sign}${size}${term.parameter}` : `${term.coefficient < 0 ? '-' : ''}${size}${term.parameter}`);
    });
    return `${expression.symbol} = ${parts.join(' ')}`;
  }

  // Shows plain keyboard signs: "−" becomes "-" and "×" becomes "x".
  // Needed for text written elsewhere (math.js expressions, static HTML), so it runs over the whole section.
  function PlainSigns(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (/[−×]/.test(node.nodeValue)) {
        node.nodeValue = node.nodeValue.replace(/−/g, '-').replace(/×/g, 'x');
      }
    }
  }

  // ---------- rendering ----------
  function RenderSection(result) {
    if (!sections.root) Init();
    if (!result || !result.matrix) {
      // invalid input: math.js returns no matrices
      sections.steps.hidden = true;
      Notice(result && result.message ? result.message : 'Enter three valid transactions and calculate the rates first.');
      return;
    }

    sections.steps.hidden = false;
    const hasUnique = !!(result.determinants && result.rates);
    Notice(result.interpretation || result.message);

    // Step 1 - equations
    Id('equationList').innerHTML = result.equations
      .map(eq => `<div>${eq.coefficients.map((c, i) => `${Num(c)}${symbols[i]}`).join(' + ')} = ${Num(eq.total)}</div>`)
      .join('');

    // Step 2 - matrix form
    Id('matrixA').innerHTML = MatrixHTML(result.matrix);
    Id('vectorB').innerHTML = MatrixHTML(result.vector.map(v => [v]));
    Id('matrixAug').innerHTML = MatrixHTML(result.augmentedMatrix, { augmented: true });

    // Step 3 - determinant of A
    const expansion = result.determinantExpansion;
    Id('matrixADet').innerHTML = MatrixHTML(result.matrix);
    Id('detSubstitute').textContent = `D = ${expansion.expression}`;
    Id('detTerms').textContent = `D = ${JoinTerms(expansion.terms)}`;
    Id('detResult').innerHTML = `<strong>D = ${Num(result.determinant)}</strong>` +
      `<span>${result.determinant !== 0 && hasUnique
        ? 'Because D ≠ 0, the system has a unique solution.'
        : 'Because D = 0, the system does not have a unique solution' +
          (result.rowReduction ? ', so Cramer’s Rule cannot be used. Step 4 uses row reduction instead.'
                               : '.')}</span>`;

    // Steps 4 & 5 (Cramer's Rule) only exist when math.js found a unique solution
    sections.solve.hidden = !hasUnique;
    sections.verify.hidden = !hasUnique;

    // When D = 0, math.js row-reduces instead: show those steps (Samples 3-5)
    RenderRowReduction(hasUnique ? null : result);
    if (!hasUnique) return;

    RenderSolveCards(result);
    RenderVerification(result);
  }

  function Render(result) {
    RenderSection(result);
    if (sections.root) PlainSigns(sections.root);
  }

  // ---------- Row reduction (D = 0): displays math.js's result.rowReduction ----------
  function EnsureRowReduceStep() {
    let step = Id('stepRowReduce');
    if (step) return step;
    step = document.createElement('div');
    step.className = 'step';
    step.id = 'stepRowReduce';
    step.hidden = true;
    step.innerHTML = `
      <div class="step_head">
        <span class="step_num">04</span>
        <div>
          <p class="step_label">STEP 04</p>
          <h2>Row Reduction (Gauss-Jordan)</h2>
        </div>
      </div>
      <p class="body_text step_intro">Since D = 0, Cramer’s Rule cannot give a unique answer. Instead, row operations are applied to the augmented matrix [A | b] until it is in reduced form.</p>
      <div class="rr_grid" id="rowReduceSteps"></div>
      <div class="rr_outcome" id="rowReduceOutcome"></div>`;
    sections.determinant.insertAdjacentElement('afterend', step);
    return step;
  }

  function RenderRowReduction(result) {
    const step = EnsureRowReduceStep();
    const reduction = result && result.rowReduction;
    step.hidden = !reduction;
    if (!reduction) return;

    const last = reduction.steps.length - 1;
    Id('rowReduceSteps').innerHTML = reduction.steps.map((item, index) => `
      <div class="panel rr_card${index === last ? ' mint' : ''}">
        <p class="panel_label">${index === 0 ? 'START' : index === last ? `OPERATION ${index} · REDUCED FORM` : `OPERATION ${index}`}</p>
        <p class="rr_operation">${FormatOperation(item.operation)}</p>
        ${MatrixHTML(item.matrix, { augmented: true })}
      </div>`).join('');

    // Outcome: all values and expressions come from math.js; this only formats them
    const lines = [];
    lines.push(`<p class="rr_rank">rank(A) = ${reduction.rankA} &nbsp;·&nbsp; rank([A | b]) = ${reduction.rankAugmented} &nbsp;·&nbsp; unknowns = ${symbols.length}</p>`);
    if (reduction.classification === 'inconsistent') {
      reduction.inconsistentRows.forEach(row => {
        lines.push(`<p>Row ${row + 1} of the reduced matrix reads <span class="rr_math">0 = ${Num(reduction.reducedMatrix[row][symbols.length])}</span>, which is impossible.</p>`);
      });
      lines.push('<p>The transactions contradict each other, so the system has <strong>no solution</strong>.</p>');
    } else if (reduction.parameterizedSolution) {
      lines.push(`<p>Free variable${reduction.freeVariables.length > 1 ? 's' : ''}: <strong>${reduction.freeColumns.map(column => symbols[column]).join(', ')}</strong>. The system has <strong>infinitely many solutions</strong>:</p>`);
      lines.push(`<div class="rr_solution">${reduction.parameterizedSolution.expressions.map(item => `<p>${ExpressionText(item)}</p>`).join('')}</div>`);
    }
    Id('rowReduceOutcome').innerHTML = `<h3>${reduction.classification === 'inconsistent' ? 'INCONSISTENT SYSTEM : NO SOLUTION' : 'DEPENDENT SYSTEM : INFINITELY MANY SOLUTIONS'}</h3>${lines.join('')}`;
  }

  function RenderSolveCards(result) {
    const D = result.determinant;
    Id('solveCards').innerHTML = keys.map((key, col) => {
      const symbol = symbols[col];
      const sub = symbol.toUpperCase();
      const matrix = result.replacementMatrices[key];
      return `
        <div class="panel solve_card">
          <div class="solve_top">
            <header><span>${symbol}</span><small>Replace column ${col + 1}</small></header>
            <div class="matrix_row"><span class="math_text">A<sub>${sub}</sub> =</span>${MatrixHTML(matrix, { shadeColumn: col })}</div>
          </div>
          <div class="solve_calc">
            <p class="panel_label">DETERMINANT D<sub>${sub}</sub></p>
            <p class="big">D<sub>${sub}</sub> = ${Num(result.determinants[key])}</p>
          </div>
          <div class="solve_divide">
            <p class="panel_label">DIVIDE BY D = ${Num(D)}</p>
            <p>${symbol} = D<sub>${sub}</sub> / D = ${Num(result.determinants[key])} / ${Num(D)}</p>
            <p class="big">${symbol} = ${Num(result.rates[key])}</p>
          </div>
        </div>`;
    }).join('');
  }

  function RenderVerification(result) {
    Id('verifyBody').innerHTML = result.verification.map((check, row) => {
      const coefficients = result.matrix[row];
      const parts = coefficients.map((c, i) => `${Num(c)}(${Num(result.rates[keys[i]])})`).join(' + ');
      return `
        <tr>
          <td>Equation ${check.transaction}</td>
          <td class="eval"><p>${parts}</p><p>= ${Num(check.calculated)}</p></td>
          <td class="total">${Num(check.expected)}</td>
          <td class="check${check.passed ? '' : ' failed'}">${check.passed ? '✓ Verified' : '✗ Not verified'}</td>
        </tr>`;
    }).join('');

    Id('finalPrint').textContent = '₱ ' + result.formattedRates.print;
    Id('finalScan').textContent  = '₱ ' + result.formattedRates.scan;
    Id('finalRent').textContent  = '₱ ' + result.formattedRates.rent;
  }

  // ---------- result retrieval ----------
  function ReadInputs() {
    const rows = document.querySelectorAll('.transactions tbody tr');
    return Array.from(rows).map(row => {
      const entry = {};
      ['print', 'scan', 'rent', 'total'].forEach(name => {
        entry[name] = row.querySelector(`input[name="${name}"]`).value;
      });
      return entry;
    });
  }

    function GetResult() {
    return ShopRateMath.SolveRates(ReadInputs());
  }

  // ---------- show / hide ----------
  function Show(result) {
    Render(result || GetResult());
    if (Id('analyzerView')) Id('analyzerView').hidden = true;
    sections.root.hidden = false;
    window.scrollTo(0, 0);
  }

  function Hide() {
    sections.root.hidden = true;
    if (Id('analyzerView')) Id('analyzerView').hidden = false;
    window.scrollTo(0, 0);
  }

  function OnViewClick() {
    const empty = Array.from(document.querySelectorAll('.transactions input'))
      .some(input => input.value.trim() === '');
    if (empty) {
      const message = Id('rateMessage');
      message.textContent = 'Fill in all transactions first.';
      message.classList.add('error');
      return;
    }
    Id('calculateBtn').click(); // refresh so the solution is never stale
    Show();
  }

  function Init() {
    if (sections.root) return;
    sections.root = Id('matrixSolution');
    if (!sections.root) return;
    sections.notice = Id('solutionNotice');
    sections.determinant = Id('stepDeterminant');
    PlainSigns(sections.root);
    sections.steps = Id('solutionSteps');
    sections.solve = Id('stepSolve');
    sections.verify = Id('stepVerify');
    // The buttons only exist on RateAnalyzer.html (not on temporary_solution.html)
    if (Id('viewSolutionBtn')) Id('viewSolutionBtn').addEventListener('click', OnViewClick);
    if (Id('backBtn')) Id('backBtn').addEventListener('click', Hide);
  }

  document.addEventListener('DOMContentLoaded', Init);
  return { Render, Show, Hide };
})();