// Load Sample
const samples = {
  unique1: sampleUnique,
  unique2: sampleUnique2,
  inconsistent: sampleInconsistent,
  dependent: sampleDependent,
  rowswap: sampleRowSwap
};

const sampleMenu = document.getElementById('sampleMenu');
const loadSampleBtn = document.getElementById('loadSampleBtn');

loadSampleBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  sampleMenu.classList.toggle('open');
});

sampleMenu.addEventListener('click', (e) => {
  const choice = e.target.closest('button[data-sample]');
  if (!choice) return;
  const rows = document.querySelectorAll('.transactions tbody tr');
  samples[choice.dataset.sample].forEach((data, i) => {
    rows[i].querySelector('[name="print"]').value = data.print;
    rows[i].querySelector('[name="scan"]').value  = data.scan;
    rows[i].querySelector('[name="rent"]').value  = data.rent;
    rows[i].querySelector('[name="total"]').value = data.total;
  });
  sampleMenu.classList.remove('open');

  ShowRates(null);
  rateMessage.textContent = '';
  rateMessage.classList.remove('error');
});

document.addEventListener('click', () => sampleMenu.classList.remove('open'));


// Calculation
const calculateBtn = document.getElementById('calculateBtn');
const RATES_STORAGE_KEY = 'shoprate_solved_rates';
const rateMessage = document.getElementById('rateMessage');
const rateOutputs = {
  print: document.getElementById('printRate'),
  scan: document.getElementById('scanRate'),
  rent: document.getElementById('rentRate')
};

function ReadTransactions() {
  const rows = document.querySelectorAll('.transactions tbody tr');
  return Array.from(rows).map(row => ({
    print: row.querySelector('[name="print"]').value,
    scan: row.querySelector('[name="scan"]').value,
    rent: row.querySelector('[name="rent"]').value,
    total: row.querySelector('[name="total"]').value
  }));
}

function ShowRates(rates) {
  for (const key of ['print', 'scan', 'rent']) {
    rateOutputs[key].textContent = '₱ ' + (rates ? rates[key] : '00.00');
  }
}

calculateBtn.addEventListener('click', () => {
  const result = ShopRateMath.SolveRates(ReadTransactions());

  // Each calculation replaces the previous saved result, even if it fails.
  try {
    localStorage.setItem(RATES_STORAGE_KEY, JSON.stringify({
      status: result.status,
      rates: result.status === 'success' ? result.rates : null,
      message: result.message
    }));
  } catch (error) {
    console.warn('Unable to save the latest rate analysis.', error);
  }

  if (result.status === 'success') {
    ShowRates(result.formattedRates);
    rateMessage.textContent = result.message;
    rateMessage.classList.remove('error');
  } else {
    ShowRates(null);
    rateMessage.textContent = result.message;
    rateMessage.classList.add('error');
  }
});


// Clear Button
document.getElementById('clearBtn').addEventListener('click', () => {
  document.querySelectorAll('.transactions input').forEach(input => {
    input.value = '';
  });
  ShowRates(null);
  rateMessage.textContent = '';
  rateMessage.classList.remove('error');
  sampleMenu.classList.remove('open');
});