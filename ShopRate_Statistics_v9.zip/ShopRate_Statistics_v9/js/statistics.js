'use strict';

/**
 * ShopRate Statistics — page behavior only.
 *
 * Responsibilities: the editable table, dataset source labels, CSV import,
 * showing results, drawing the two SVG charts, and switching between the
 * analyzer and the "View Solution" pages.
 *
 * All calculations and statistical wording live in stats-math.js.
 * Solution-page HTML lives in stats-solution.js.
 * Naming matches the original ShopRate JavaScript: PascalCase functions,
 * camelCase variables and object properties.
 */
(() => {
  const stats = ShopRateStats;
  const variableKeys = stats.variableKeys;
  const svgNamespace = 'http://www.w3.org/2000/svg';
  const maximumImportRows = 2000;

  // Colors come from the ShopRate palette; dashes keep series distinguishable without color.
  const seriesStyles = {
    print: { color: '#2e8b5c', dash: '' },
    scan: { color: '#d29045', dash: '7 4' },
    rent: { color: '#5f78c0', dash: '2 3' },
    total: { color: '#173f34', dash: '' }
  };
  const axisColor = '#6D7782';
  const gridColor = '#E6E9E6';
  const chartFont = 'Inter, system-ui, sans-serif';

  // Simulated dataset. List prices are ₱5 per printed page, ₱3 per scanned page and ₱10 per rental hour,
  // but not every bill equals the list-price subtotal. The rules below were applied once when the data
  // were created (see tests/make_reference.py), so the totals are stored as plain data:
  //   - volume price: printed pages beyond 20 cost ₱4 each (transactions 10 and 17)
  //   - student discount: 10 percent off, rounded to the nearest peso (transactions 7, 15, 17, 18, 19)
  //   - add-on fee: ₱5 for lamination, rush or similar (transactions 6, 16, 17, 21)
  const sampleTransactions = [
    [10, 2, 1, 66],
    [5, 5, 2, 60],
    [20, 0, 1, 110],
    [4, 2, 3, 56],
    [8, 3, 1, 59],
    [2, 1, 0, 18],
    [16, 0, 2, 90],
    [12, 6, 1, 88],
    [0, 7, 4, 61],
    [22, 4, 2, 140],
    [7, 2, 3, 71],
    [18, 3, 0, 99],
    [3, 1, 2, 38],
    [14, 5, 1, 95],
    [6, 0, 3, 54],
    [9, 8, 0, 74],
    [25, 2, 1, 127],
    [11, 3, 4, 94],
    [1, 4, 2, 33],
    [13, 1, 0, 68],
    [15, 6, 2, 118],
    [5, 2, 3, 61],
    [19, 7, 1, 126],
    [8, 5, 2, 75]
  ].map(([print, scan, rent, total]) => ({ print, scan, rent, total }));

  // Statistical test case II: 30 different simulated transactions (list prices ₱4.50 / ₱2.75 / ₱12.50 plus a
  // small random extra of ₱0 to ₱9, seed 2026, see tests/make_reference.py). Totals have centavos.
  const secondTransactions = [
    [7, 10, 4, 114.24],
    [6, 7, 4, 102.61],
    [35, 13, 6, 274.11],
    [35, 15, 6, 281.66],
    [37, 14, 1, 217.52],
    [39, 2, 0, 183.94],
    [6, 14, 0, 73.84],
    [31, 10, 1, 183.56],
    [16, 11, 2, 135.49],
    [24, 2, 5, 179.48],
    [5, 9, 2, 76.93],
    [9, 9, 0, 73.93],
    [23, 11, 3, 175.57],
    [5, 12, 4, 111.17],
    [31, 3, 3, 190.43],
    [38, 15, 3, 255.12],
    [16, 13, 4, 162.65],
    [32, 0, 4, 196.29],
    [8, 1, 5, 106.60],
    [6, 13, 3, 101.70],
    [30, 7, 6, 230.49],
    [40, 14, 5, 285.80],
    [34, 8, 4, 229.11],
    [19, 15, 6, 205.86],
    [27, 6, 2, 171.51],
    [17, 0, 0, 78.03],
    [38, 14, 6, 289.85],
    [31, 11, 1, 184.91],
    [31, 14, 4, 235.85],
    [31, 13, 4, 232.04]
  ].map(([print, scan, rent, total]) => ({ print, scan, rent, total }));

  // Statistical test case III: only 15 transactions (the minimum is 20) and three bad cells:
  // a blank (transaction 3), a negative (transaction 6) and a fractional quantity (transaction 9).
  const invalidTransactions = sampleTransactions.slice(0, 15).map(transaction => ({ ...transaction }));
  invalidTransactions[2].print = '';
  invalidTransactions[5].rent = -1;
  invalidTransactions[8].scan = 2.5;

  // The three test cases offered by the Load Sample menu.
  const testCases = {
    valid: {
      label: 'I. Valid dataset',
      rows: sampleTransactions,
      description: 'Built-in sample dataset (24 transactions). List prices are ₱5 per printed page, ₱3 per scanned page and ₱10 per rental hour, with volume-price, student-discount and add-on adjustments applied to some transactions. Checked independently with Python (statistics, NumPy, SciPy).'
    },
    second: {
      label: 'II. Second verified dataset',
      rows: secondTransactions,
      description: 'Second simulated dataset (30 transactions). List prices ₱4.50 per printed page, ₱2.75 per scanned page and ₱12.50 per rental hour plus a random extra of ₱0 to ₱9 (seed 2026, tests/make_reference.py). Checked independently with Python (statistics, NumPy, SciPy).'
    },
    invalid: {
      label: 'III. Invalid / insufficient dataset',
      rows: invalidTransactions,
      description: 'Deliberately invalid test data: 15 transactions (20 are required) containing a blank, a negative and a fractional value. ShopRate should reject it with a clear message.'
    }
  };

  const dataTypeBadges = {
    simulated: 'SIMULATED DATA',
    actual: 'ACTUAL DATA',
    public: 'PUBLIC DATA',
    '': 'DATA TYPE NOT SET'
  };
  // Page state ------------------------------------------------------------
  let transactions = [];        // editable rows; values may still be text
  let analyzedRows = null;      // validated rows, or null when results are out of date
  // Provenance of the records now in the table. dataType is declared by the user; ShopRate cannot prove it.
  let source = { origin: 'manual', fileName: '', edited: false, dataType: '', description: '', sampleKey: '' };

  function Id(id) {
    return document.getElementById(id);
  }

  function SetStatus(message, isError = false) {
    const status = Id('statusMessage');
    status.textContent = message;
    status.classList.toggle('error', isError);
  }

  // 1. DATA TYPE AND SOURCE ------------------------------------------------
  // The guidelines ask us to identify the source and to distinguish actual, publicly
  // sourced, and simulated data. The user declares the type; the label always describes
  // the records currently in the table.
  const typeNotes = {
    simulated: 'Simulated (artificial) records. They illustrate the method and are not evidence about real customers.',
    actual: 'Actual transactions recorded by the group or a shop. Say who collected them, where, and when.',
    public: 'Records from a public source. Give the publisher, title, and link or date.',
    '': 'Choose what these records are (simulated, actual, or publicly sourced) before analyzing.'
  };
  // The only editable provenance control is the data-type dropdown. The description
  // is always generated from that declaration and the actual loaded file or test case.
  function DescriptionRequired() { return false; }
  function AutomaticDescription() {
    if (source.origin === 'builtin' && source.sampleKey && !source.edited) {
      return `${testCases[source.sampleKey].description} Built-in records are simulated regardless of any manual data-type selection.`;
    }
    const origin = source.origin === 'imported'
      ? `Imported CSV: ${source.fileName || 'unnamed file'}.`
      : source.origin === 'builtin'
        ? `Edited records originally based on ${testCases[source.sampleKey].label}.`
        : 'Manually entered transaction records.';
    const type = source.dataType === 'simulated' ? 'Declared simulated records; not real customer evidence.'
      : source.dataType === 'actual' ? 'Declared actual transaction records; origin and authenticity must be independently confirmed.'
      : source.dataType === 'public' ? 'Declared publicly sourced records; publisher and publication details must be verified outside this tool.'
      : 'Data type not yet selected.';
    return `${origin} ${type}`;
  }

  function SourceBadgeText() {
    return `${dataTypeBadges[source.dataType]}${source.edited ? ' · EDITED' : ''}`;
  }

  function OriginLine() {
    if (source.origin === 'builtin') {
      return source.edited
        ? `Started from the built-in test case “${testCases[source.sampleKey].label}” and then edited; confirm the data type and source are still correct.`
        : `Built-in test case: ${testCases[source.sampleKey].label}.`;
    }
    if (source.origin === 'imported') {
      return `Imported from ${source.fileName}${source.edited ? ' and then edited' : ''}.`;
    }
    return 'Entered manually.';
  }

  function ShowSource() {
    Id('sourceBadge').textContent = SourceBadgeText();
    Id('sourceNote').textContent = `${OriginLine()} ${typeNotes[source.dataType]}`;
    if (Id('dataType').value !== source.dataType) Id('dataType').value = source.dataType;
    source.description = AutomaticDescription();
    Id('sourceDescription').value = source.description;
    Id('sourceDescription').readOnly = true;
    Id('sourceLabel').textContent = 'SOURCE DESCRIPTION (AUTOMATIC · READ ONLY)';
  }

  function SetSource(origin, fileName = '', dataType = '', description = '', sampleKey = '') {
    source = { origin, fileName, edited: false, dataType, description, sampleKey };
    ShowSource();
  }

  // Editing keeps honest provenance: a changed built-in or imported dataset is marked as edited.
  function RecordEdit() {
    if ((source.origin === 'builtin' || source.origin === 'imported') && !source.edited) {
      source.edited = true;
      ShowSource();
    }
  }

  // Returns a message when the declaration is incomplete, otherwise null.
  function SourceProblem() {
    if (source.dataType === '') {
      return 'Choose the data type (simulated, actual, or publicly sourced) before analyzing.';
    }
    return null;
  }

  function MarkSourceFields(problem) {
    Id('dataType').classList.toggle('needs_choice', problem !== null && source.dataType === '');
  }

  // 2. SHOWING AND HIDING RESULTS ----------------------------------------
  const resultPanels = [
    ['descriptiveResults', 'descriptiveEmpty'],
    ['pearsonResults', 'pearsonEmpty'],
    ['scatterResults', 'scatterEmpty'],
    ['barResults', 'barEmpty'],
    ['conclusionResults', 'conclusionEmpty']
  ];

  function ShowResults(visible) {
    for (const [resultsId, emptyId] of resultPanels) {
      Id(resultsId).hidden = !visible;
      Id(emptyId).hidden = visible;
    }
    Id('viewDescriptiveBtn').disabled = !visible;
    Id('viewPearsonBtn').disabled = !visible;
  }

  // Called whenever the data change, so stale numbers never stay on screen.
  function InvalidateResults() {
    analyzedRows = null;
    ShowResults(false);
    ClearRowErrors();
  }

  function MarkDirty() {
    RecordEdit();
    InvalidateResults();
    SetStatus('Dataset changed. Click “Analyze dataset” to update the results.');
  }

  // 3. EDITABLE TRANSACTION TABLE ----------------------------------------
  function ClearRowErrors() {
    document.querySelectorAll('#datasetBody tr.row_error').forEach(row => row.classList.remove('row_error'));
  }

  function HighlightRow(rowIndex) {
    const row = Id('datasetBody').children[rowIndex];
    if (!row) return;
    row.classList.add('row_error');
    row.scrollIntoView({ block: 'nearest' });
  }

  function UpdateCount() {
    const count = transactions.length;
    Id('tableCount').textContent = `${count} ${count === 1 ? 'transaction' : 'transactions'}`;
    Id('emptyTable').hidden = count > 0;
  }

  function CreateNumberInput(transaction, field, index) {
    const input = document.createElement('input');
    input.type = 'number';
    input.min = '0';
    input.step = field === 'total' ? '0.01' : '1';
    input.value = transaction[field] ?? '';
    input.setAttribute('aria-label', `${stats.variableTitles[field]}, transaction ${index + 1}`);
    input.addEventListener('input', () => {
      transaction[field] = input.value;
      MarkDirty();
    });
    return input;
  }

  function CreateDeleteButton(index) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'delete_row';
    button.textContent = '×';
    button.title = 'Delete transaction';
    button.setAttribute('aria-label', `Delete transaction ${index + 1}`);
    button.addEventListener('click', () => {
      transactions.splice(index, 1);
      MarkDirty();
      RenderTransactionTable();
    });
    return button;
  }

  function RenderTransactionTable() {
    const body = Id('datasetBody');
    body.replaceChildren();
    transactions.forEach((transaction, index) => {
      const row = document.createElement('tr');
      const label = document.createElement('td');
      label.textContent = `Transaction ${index + 1}`;
      row.appendChild(label);
      for (const field of variableKeys) {
        const cell = document.createElement('td');
        cell.appendChild(CreateNumberInput(transaction, field, index));
        row.appendChild(cell);
      }
      const actionCell = document.createElement('td');
      actionCell.appendChild(CreateDeleteButton(index));
      row.appendChild(actionCell);
      body.appendChild(row);
    });
    UpdateCount();
  }

  // 4. CHART HELPERS ------------------------------------------------------
  function CreateSvgElement(name, attributes = {}) {
    const element = document.createElementNS(svgNamespace, name);
    for (const [key, value] of Object.entries(attributes)) {
      element.setAttribute(key, String(value));
    }
    return element;
  }

  function AddText(svg, x, y, content, anchor = 'middle', size = 10.5) {
    const text = CreateSvgElement('text', {
      x, y, fill: axisColor, 'font-size': size,
      'font-family': chartFont, 'text-anchor': anchor
    });
    text.textContent = content;
    svg.appendChild(text);
    return text;
  }

  function AddTooltip(element, content) {
    const tooltip = CreateSvgElement('title');
    tooltip.textContent = content;
    element.appendChild(tooltip);
  }

  // Picks tidy axis steps (1, 2, 5, 10 × a power of ten) so tick labels are exact.
  function NiceAxis(maximumValue, minimumStep = 0) {
    const safeMaximum = Math.max(maximumValue, 1);
    const roughStep = safeMaximum / 5;
    const magnitude = 10 ** Math.floor(Math.log10(roughStep));
    const ratio = roughStep / magnitude;
    const multiplier = ratio <= 1 ? 1 : ratio <= 2 ? 2 : ratio <= 5 ? 5 : 10;
    const step = Math.max(multiplier * magnitude, minimumStep);
    return { step, max: Math.ceil(safeMaximum / step) * step };
  }

  function TickValues(axis) {
    const ticks = [];
    for (let value = 0; value <= axis.max + axis.step / 1000; value += axis.step) {
      ticks.push(value);
    }
    return ticks;
  }

  function FormatAxisValue(value, field) {
    return field === 'total' ? `₱${stats.FormatNumber(value, 0)}` : stats.FormatNumber(value, Number.isInteger(value) ? 0 : 1);
  }

  // Draws gridlines, both axes, and the y-axis title. Returns scale helpers.
  function DrawYAxis(svg, layout, axis, yTitle, field) {
    const { width, height, margins } = layout;
    const plotHeight = height - margins.top - margins.bottom;
    const bottom = height - margins.bottom;
    const YPosition = value => bottom - value / axis.max * plotHeight;
    for (const value of TickValues(axis)) {
      const y = YPosition(value);
      svg.appendChild(CreateSvgElement('line', {
        x1: margins.left, y1: y, x2: width - margins.right, y2: y, stroke: gridColor
      }));
      AddText(svg, margins.left - 8, y + 3.5, FormatAxisValue(value, field), 'end');
    }
    svg.appendChild(CreateSvgElement('line', {
      x1: margins.left, y1: margins.top, x2: margins.left, y2: bottom, stroke: axisColor
    }));
    svg.appendChild(CreateSvgElement('line', {
      x1: margins.left, y1: bottom, x2: width - margins.right, y2: bottom, stroke: axisColor
    }));
    const title = AddText(svg, 0, 0, yTitle);
    title.setAttribute('transform', `translate(14 ${margins.top + plotHeight / 2}) rotate(-90)`);
    return { YPosition, bottom, plotWidth: width - margins.left - margins.right };
  }

  // Transaction-number labels under the comparison chart (about 8 evenly spaced).
  function DrawTransactionAxis(svg, layout, count, bottom) {
    const { width, height, margins } = layout;
    const plotWidth = width - margins.left - margins.right;
    const labelCount = Math.min(8, count);
    for (let tick = 0; tick < labelCount; tick++) {
      const index = Math.round(tick * (count - 1) / Math.max(1, labelCount - 1));
      const x = margins.left + (index + 0.5) * plotWidth / count;
      AddText(svg, x, bottom + 16, String(index + 1));
    }
    AddText(svg, margins.left + plotWidth / 2, height - 8, 'Transaction number (record order, not time)');
  }

  function ChartLayout(svg) {
    const viewBox = svg.viewBox.baseVal;
    return {
      width: viewBox.width,
      height: viewBox.height,
      margins: { left: 62, right: 18, top: 14, bottom: 50 }
    };
  }

  // 5. GRAPH 1: SELECTABLE SCATTER PLOT -------------------------------
  const axisTitles = { print: 'Printed pages', scan: 'Scanned pages', rent: 'Rental hours' };
  const serviceIdNames = { print: 'Print', scan: 'Scan', rent: 'Rent' };

  function DrawScatterChart(rows, xField) {
    const svg = Id('scatterChart');
    svg.replaceChildren();
    const layout = ChartLayout(svg);
    const { width, height, margins } = layout;
    const xValues = stats.GetValues(rows, xField);
    const yValues = stats.GetValues(rows, 'total');
    const flagged = new Set(stats.FlagUnusualObservations(xValues, yValues).flagged.map(item => item.index));
    const yAxis = NiceAxis(Math.max(...yValues));
    const xAxis = NiceAxis(Math.max(...xValues), 1);
    const axes = DrawYAxis(svg, layout, yAxis, 'Total paid (₱)', 'total');
    const XPosition = value => margins.left + value / xAxis.max * axes.plotWidth;

    for (const value of TickValues(xAxis)) {
      AddText(svg, XPosition(value), axes.bottom + 16, FormatAxisValue(value, xField));
    }
    const xTitle = `${stats.variableTitles[xField]} (${stats.variableUnits[xField]})`;
    AddText(svg, margins.left + axes.plotWidth / 2, height - 8, xTitle);

    rows.forEach((row, index) => {
      const point = CreateSvgElement('circle', {
        cx: XPosition(row[xField]), cy: axes.YPosition(row.total), r: 5,
        class: flagged.has(index) ? 'dot unusual' : 'dot',
        fill: '#285943', 'fill-opacity': 0.7, stroke: '#fff', 'stroke-width': 1.2
      });
      AddTooltip(point, `Transaction ${index + 1}: ${stats.FormatValue(row[xField], xField)}, total ${stats.FormatValue(row.total, 'total')}`);
      svg.appendChild(point);
      if (flagged.has(index)) {
        const ring = CreateSvgElement('circle', { cx: XPosition(row[xField]), cy: axes.YPosition(row.total), r: 9, fill: 'none', stroke: '#ad501c', 'stroke-width': 2, class: 'unusual-ring' });
        AddTooltip(ring, `Potential outlier (1.5 × IQR): transaction ${index + 1}; retained in analysis`);
        svg.appendChild(ring);
      }
    });
  }


  // The single, selectable scatter plot and all-four-variables chart are the two
  // visualization panels. The removed small plots/dashboard are intentionally absent.

  function DrawSingleVariableChart(rows, field) {
    const svg = Id('barChart');
    svg.replaceChildren();
    const layout = ChartLayout(svg);
    const { margins } = layout;
    const values = stats.GetValues(rows, field);
    const minimumStep = field === 'total' ? 0 : 1;
    const axis = NiceAxis(Math.max(...values), minimumStep);
    const title = field === 'total' ? 'Total paid (₱)' : `${stats.variableTitles[field]} (${stats.variableUnits[field]})`;
    const axes = DrawYAxis(svg, layout, axis, title, field);
    const slotWidth = axes.plotWidth / rows.length;
    const barWidth = Math.max(3, slotWidth * 0.66);

    values.forEach((value, index) => {
      const x = margins.left + index * slotWidth + (slotWidth - barWidth) / 2;
      const y = axes.YPosition(value);
      const bar = CreateSvgElement('rect', {
        x, y, width: barWidth, height: Math.max(0, axes.bottom - y), rx: 2,
        fill: seriesStyles[field].color, 'fill-opacity': 0.88
      });
      AddTooltip(bar, `Transaction ${index + 1}: ${stats.FormatValue(value, field)}`);
      svg.appendChild(bar);
    });

    // Dashed line at the mean gives each bar something to be compared with.
    const mean = stats.Mean(values);
    const meanY = axes.YPosition(mean);
    svg.appendChild(CreateSvgElement('line', {
      x1: margins.left, y1: meanY, x2: layout.width - margins.right, y2: meanY,
      stroke: '#B3261E', 'stroke-width': 1.5, 'stroke-dasharray': '6 4'
    }));
    AddText(svg, layout.width - margins.right - 2, meanY - 5, `Mean ${stats.FormatQuantity(mean, field)}`, 'end');
    DrawTransactionAxis(svg, layout, rows.length, axes.bottom);
  }

  function DrawAllVariablesChart(rows) {
    const svg = Id('barChart');
    svg.replaceChildren();
    const layout = ChartLayout(svg);
    const { margins } = layout;
    const axes = DrawYAxis(svg, layout, { max: 100, step: 25 }, 'Relative position (0–100)', 'scale');
    const slotWidth = axes.plotWidth / rows.length;

    for (const field of variableKeys) {
      const style = seriesStyles[field];
      const rawValues = stats.GetValues(rows, field);
      const positions = stats.NormalizeSeries(rawValues);
      const points = positions.map((position, index) => ({
        x: margins.left + (index + 0.5) * slotWidth,
        y: axes.YPosition(position),
        position, index
      }));
      svg.appendChild(CreateSvgElement('polyline', {
        points: points.map(point => `${point.x},${point.y}`).join(' '),
        stroke: style.color, fill: 'none', 'stroke-width': field === 'total' ? 3 : 2,
        'stroke-dasharray': style.dash, 'stroke-linejoin': 'round', 'stroke-linecap': 'round'
      }));
      for (const point of points) {
        const dot = CreateSvgElement('circle', {
          cx: point.x, cy: point.y, r: field === 'total' ? 3.2 : 2.4,
          fill: style.color, stroke: '#fff', 'stroke-width': 0.8
        });
        AddTooltip(dot, `Transaction ${point.index + 1}: ${stats.FormatValue(rawValues[point.index], field)} · relative position ${stats.FormatNumber(point.position, 0)} of 100`);
        svg.appendChild(dot);
      }
    }
    DrawTransactionAxis(svg, layout, rows.length, axes.bottom);
  }

  function RenderChartLegend(field) {
    const legend = Id('chartLegend');
    legend.replaceChildren();
    const fields = field === 'all' ? variableKeys : [field];
    for (const key of fields) {
      const item = document.createElement('span');
      item.className = 'legend_item';
      const swatch = CreateSvgElement('svg', { width: 26, height: 10, viewBox: '0 0 26 10', 'aria-hidden': 'true' });
      swatch.appendChild(CreateSvgElement('line', {
        x1: 1, y1: 5, x2: 25, y2: 5, stroke: seriesStyles[key].color,
        'stroke-width': 3, 'stroke-dasharray': seriesStyles[key].dash, 'stroke-linecap': 'round'
      }));
      const label = document.createElement('span');
      label.textContent = key === 'total' ? 'Total paid (₱)' : `${stats.variableTitles[key]} (${stats.variableUnits[key]})`;
      item.append(swatch, label);
      legend.appendChild(item);
    }
    if (field !== 'all') {
      const mean = document.createElement('span');
      mean.className = 'legend_item';
      const swatch = CreateSvgElement('svg', { width: 26, height: 10, viewBox: '0 0 26 10', 'aria-hidden': 'true' });
      swatch.appendChild(CreateSvgElement('line', {
        x1: 1, y1: 5, x2: 25, y2: 5, stroke: '#B3261E', 'stroke-width': 2, 'stroke-dasharray': '6 4'
      }));
      const label = document.createElement('span');
      label.textContent = 'Mean';
      mean.append(swatch, label);
      legend.appendChild(mean);
    }
  }

  function RefreshTransactionChart() {
    if (!analyzedRows) return;
    const field = Id('chartVariable').value;
    if (field === 'all') {
      Id('transactionChartTitle').textContent = 'All four variables · relative patterns';
      Id('transactionChartSubtitle').textContent = 'Graph 2 · each line scaled separately from 0 to 100 (not pages, hours, or pesos)';
      Id('barChart').setAttribute('aria-label', 'Line chart of four variables, each scaled from 0 to 100 within its own range');
      DrawAllVariablesChart(analyzedRows);
    } else {
      const title = field === 'total' ? 'Total paid (₱)' : stats.variableTitles[field];
      Id('transactionChartTitle').textContent = `${title} by transaction`;
      Id('transactionChartSubtitle').textContent = `Graph 2 · bar chart in actual ${stats.variableUnits[field]}`;
      Id('barChart').setAttribute('aria-label', `Bar chart of ${stats.variableNames[field]} for each transaction`);
      DrawSingleVariableChart(analyzedRows, field);
    }
    RenderChartLegend(field);
    Id('barText').textContent = stats.InterpretChart(analyzedRows, field);
  }

  // 7. DESCRIPTIVE STATISTICS --------------------------------------------
  function FillStatBox(prefix, valueText, unitText, explanation) {
    Id(`${prefix}Value`).textContent = valueText;
    Id(`${prefix}Unit`).textContent = unitText;
    Id(`${prefix}Unit`).hidden = !unitText;
    Id(`${prefix}Text`).textContent = explanation;
  }

  function ModeExplanation(formulaMode) {
    const common = ' The choice changes only the variance and standard deviation; the records, mean, median, minimum, maximum, and Pearson r stay the same. It is separate from whether the data are simulated or real.';
    return formulaMode === 'sample'
      ? `Sample variance and standard deviation use n − 1. These simulated records illustrate a sample of possible transactions; they do not establish actual customer behavior.${common}`
      : `Population variance and standard deviation use N when the selected records are the complete group you want to describe.${common}`;
  }

  function RefreshDescriptiveStatistics() {
    if (!analyzedRows) return;
    const field = Id('summaryVariable').value;
    const mode = Id('formulaMode').value;
    const summary = stats.Describe(stats.GetValues(analyzedRows, field), mode);
    const explain = stats.InterpretStatistics(summary, field);
    const unit = field === 'total' ? 'pesos' : stats.variableUnits[field];
    const cardNumber = (value, selectedField) => selectedField === 'total' ? stats.FormatNumber(value) : stats.FormatQuantity(value, selectedField);
    const isSample = mode === 'sample';

    FillStatBox('mean', cardNumber(summary.mean, field), unit, `${explain.mean.finding} ${explain.mean.relevance}`);
    FillStatBox('median', cardNumber(summary.median, field), unit, `${explain.median.finding} ${explain.median.relevance}`);
    FillStatBox('variance', stats.FormatNumber(summary.variance), field === 'total' ? 'pesos²' : stats.SquaredUnit(field), `${explain.variance.finding} ${explain.variance.relevance}`);
    FillStatBox('std', cardNumber(summary.standardDeviation, field), unit, `${explain.standardDeviation.finding} ${explain.standardDeviation.relevance}`);
    FillStatBox('min', cardNumber(summary.min, field), unit, `${explain.minimum.finding} ${explain.minimum.relevance}`);
    FillStatBox('max', cardNumber(summary.max, field), unit, `${explain.maximum.finding} ${explain.maximum.relevance}`);

    Id('varianceLabel').textContent = `VARIANCE (${isSample ? 's²' : 'σ²'})`;
    Id('stdLabel').textContent = `STD. DEVIATION (${isSample ? 's' : 'σ'})`;
    Id('modeNote').textContent = ModeExplanation(mode);
    RefreshSummaryTable();
    Id('descriptiveSubtitle').textContent = `${stats.variableTitles[field]} · ${summary.n} transactions · ${isSample ? 'sample (n − 1)' : 'population (N)'} formulas`;
  }

  // Summary table: every variable at once (the statistical summary table), using the chosen formula type.
  function RefreshSummaryTable() {
    const mode = Id('formulaMode').value;
    const selected = Id('summaryVariable').value;
    const isSample = mode === 'sample';
    Id('summaryCaption').textContent = `ALL VARIABLES · ${isSample ? 'SAMPLE (n − 1)' : 'POPULATION (N)'} FORMULAS`;
    Id('summaryVarianceHead').textContent = `Variance (${isSample ? 's²' : 'σ²'})`;
    Id('summaryStdHead').textContent = `Std. deviation (${isSample ? 's' : 'σ'})`;
    const body = Id('summaryBody');
    body.replaceChildren();
    for (const field of variableKeys) {
      const summary = stats.Describe(stats.GetValues(analyzedRows, field), mode);
      const cells = [
        `${stats.variableTitles[field].replace(' (₱)', '')} (${field === 'total' ? '₱' : stats.variableUnits[field]})`,
        String(summary.n),
        stats.FormatQuantity(summary.mean, field),
        stats.FormatQuantity(summary.median, field),
        `${stats.FormatNumber(summary.variance)} ${stats.SquaredUnit(field)}`,
        stats.FormatQuantity(summary.standardDeviation, field),
        stats.FormatQuantity(summary.min, field),
        stats.FormatQuantity(summary.max, field)
      ];
      const row = document.createElement('tr');
      row.className = field === selected ? 'selected_row' : '';
      for (const text of cells) {
        const cell = document.createElement('td');
        cell.textContent = text;
        row.appendChild(cell);
      }
      body.appendChild(row);
    }
  }

  // 8. PEARSON CORRELATION -----------------------------------------------
  function ResultContext() {
    return { dataType: source.dataType, builtIn: source.origin === 'builtin' && source.sampleKey === 'valid' && !source.edited };
  }

  // Computes r and the unusual observations for the three services once, then fills
  // the three r boxes, the five explanation cards and selected scatter plot.
  function RefreshCorrelation() {
    if (!analyzedRows) return;
    const selected = Id('xVariable').value;
    const totals = stats.GetValues(analyzedRows, 'total');
    const context = ResultContext();
    const analyses = {};
    for (const field of stats.serviceKeys) {
      const xValues = stats.GetValues(analyzedRows, field);
      analyses[field] = {
        result: stats.PearsonCorrelation(xValues, totals),
        unusual: stats.FlagUnusualObservations(xValues, totals)
      };
    }

    for (const field of stats.serviceKeys) {
      const { result } = analyses[field];
      const cls = stats.ClassifyCorrelation(result.r);
      const tile = Id(`tile${serviceIdNames[field]}`);
      tile.querySelector('.tile_value').textContent = result.r === null ? 'Undefined' : stats.FormatNumber(result.r, 4);
      tile.querySelector('.tile_strength').textContent = result.r === null ? 'no variation' : `${cls.label} correlation`;
      tile.classList.toggle('selected', field === selected);
      tile.setAttribute('aria-pressed', String(field === selected));
    }
    Id('scatterVariable').value = selected;
    Id('scatterTitle').textContent = `${stats.variableTitles[selected]} vs. total paid`;
    DrawScatterChart(analyzedRows, selected);
    const scatterDescription = stats.InterpretScatter(analyses[selected].result, selected, analyzedRows, analyses[selected].unusual);
    Id('scatterText').textContent = `${scatterDescription.distribution} ${scatterDescription.unusual} Correlation does not establish causation.`;

    const cards = stats.InterpretCorrelationCards(analyses[selected].result, selected, context, analyses[selected].unusual);
    const cardIds = { direction: 'cardDirection', strength: 'cardStrength', variation: 'cardVariation', business: 'cardBusiness', limits: 'cardLimits' };
    for (const [key, id] of Object.entries(cardIds)) {
      Id(id).textContent = cards[key].text;
      Id(`${id}Title`).textContent = cards[key].title;
    }
    Id('tileHint').textContent = `Explaining ${stats.variableTitles[selected].toLowerCase()} vs. total paid. Click another coefficient box or use the Compare selector to switch.`;


  }

  function SelectService(field) {
    Id('xVariable').value = field;
    RefreshCorrelation();
  }

  // 9. OVERALL INTERPRETATION --------------------------------------------
  function RefreshConclusion() {
    if (!analyzedRows) return;
    const text = stats.InterpretDataset(analyzedRows, Id('formulaMode').value, ResultContext());
    Id('conclusionSpending').textContent = text.spending;
    Id('conclusionUsage').textContent = text.usage;
    Id('conclusionRelationship').textContent = text.relationship;
    Id('originLimit').textContent = text.origin;
  }

  function RefreshResults() {
    RefreshDescriptiveStatistics();
    RefreshCorrelation();
    RefreshTransactionChart();
    RefreshConclusion();
  }

  function AnalyzeTransactions() {
    ClearRowErrors();
    try {
      analyzedRows = stats.ValidateTransactions(transactions, stats.minimumTransactions);
    } catch (error) {
      analyzedRows = null;
      ShowResults(false);
      SetStatus(error.message, true);
      if (error.rowIndex !== undefined) HighlightRow(error.rowIndex);
      return;
    }
    const problem = SourceProblem();
    MarkSourceFields(problem);
    if (problem) {
      analyzedRows = null;
      ShowResults(false);
      SetStatus(problem, true);
      return;
    }
    ShowResults(true);
    RefreshResults();
    SetStatus(`${analyzedRows.length} valid transactions analyzed.`);
  }

  // 10. SOLUTION VIEWS ----------------------------------------------------
  const viewIds = ['analyzerView', 'descriptiveSolution', 'pearsonSolution', 'verificationSolution'];

  function ShowView(viewId) {
    for (const id of viewIds) Id(id).hidden = id !== viewId;
    window.scrollTo(0, 0);
  }

  function OpenDescriptiveSolution() {
    if (!analyzedRows) return;
    const field = Id('summaryVariable').value;
    const mode = Id('formulaMode').value;
    Id('descriptiveSolutionSubtitle').textContent =
      `${stats.variableTitles[field]} · ${analyzedRows.length} transactions · ${mode === 'sample' ? 'sample (n − 1)' : 'population (N)'} formulas · ${SourceBadgeText().toLowerCase()}.`;
    Id('descriptiveSteps').innerHTML = ShopRateStatsSolution.DescriptiveHTML(analyzedRows, field, mode);
    ShowView('descriptiveSolution');
  }

  function OpenPearsonSolution() {
    if (!analyzedRows) return;
    const field = Id('xVariable').value;
    Id('pearsonSolutionSubtitle').textContent =
      `${stats.variableTitles[field]} (x) vs. total paid (y) · ${analyzedRows.length} transactions.`;
    Id('pearsonSteps').innerHTML = ShopRateStatsSolution.PearsonHTML(analyzedRows, field, ResultContext());
    ShowView('pearsonSolution');
  }

  function ReturnToAnalyzer(cardId) {
    ShowView('analyzerView');
    Id(cardId).scrollIntoView({ block: 'start' });
  }

  // 11. CSV IMPORT AND DOWNLOAD ------------------------------------------
  // Splits CSV text into rows of cells, supporting quoted cells.
  function ParseCsvText(csvText) {
    const text = csvText.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
    const records = [];
    let cell = '';
    let record = [];
    let quoted = false;
    for (let index = 0; index < text.length; index++) {
      const character = text[index];
      if (quoted) {
        if (character === '"' && text[index + 1] === '"') { cell += '"'; index++; }
        else if (character === '"') quoted = false;
        else cell += character;
      } else if (character === '"') {
        quoted = true;
      } else if (character === ',') {
        record.push(cell.trim());
        cell = '';
      } else if (character === '\n') {
        record.push(cell.trim());
        if (record.some(Boolean)) records.push(record);
        record = [];
        cell = '';
      } else {
        cell += character;
      }
    }
    if (quoted) throw new Error('CSV file contains an unclosed quoted field.');
    record.push(cell.trim());
    if (record.some(Boolean)) records.push(record);
    return records;
  }

  // Reads the header, finds the four columns, and returns rows of text values.
  // Cell values are checked later by ValidateTransactions, so a file with a few
  // bad cells can still be loaded and corrected in the table.
  function ParseCsv(csvText) {
    const records = ParseCsvText(csvText);
    if (records.length === 0) throw new Error('CSV file is empty.');
    const header = records.shift().map(name => name.toLowerCase().replace(/[\s_-]/g, ''));
    const aliases = {
      print: ['print', 'printing', 'printedpages', 'pagesprinted'],
      scan: ['scan', 'scanning', 'scannedpages', 'pagesscanned'],
      rent: ['rent', 'rental', 'hoursrented'],
      total: ['total', 'totalpaid', 'totalcost', 'amount']
    };
    const columns = {};
    for (const [field, options] of Object.entries(aliases)) {
      const position = header.findIndex(name => options.includes(name));
      if (position < 0) {
        throw new Error(`CSV is missing the “${field}” column. Use the header: print,scan,rent,total.`);
      }
      columns[field] = position;
    }
    if (records.length === 0) throw new Error('CSV file has a header but no records.');
    if (records.length > maximumImportRows) {
      throw new Error(`CSV has ${records.length} records; the limit is ${maximumImportRows}.`);
    }
    return records.map(record => {
      const row = {};
      for (const field of variableKeys) row[field] = record[columns[field]] ?? '';
      return row;
    });
  }

  function DownloadSampleCsv() {
    const lines = sampleTransactions.map(row => variableKeys.map(field => row[field]).join(','));
    const csv = `print,scan,rent,total\n${lines.join('\n')}\n`;
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'shoprate_simulated_transactions.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  // 12. DATASET ACTIONS ---------------------------------------------------
  function LoadSampleDataset(key = 'valid') {
    const testCase = testCases[key];
    transactions = testCase.rows.map(transaction => ({ ...transaction }));
    SetSource('builtin', '', 'simulated', testCase.description, key);
    RenderTransactionTable();
    Id('chartVariable').value = 'print';
    Id('xVariable').value = 'print';
    AnalyzeTransactions();
  }

  function ClearRecords() {
    transactions = [];
    SetSource('manual');
    InvalidateResults();
    RenderTransactionTable();
    SetStatus('All records cleared. Add rows, import a CSV file, or load the sample dataset.');
  }

  function AddRow() {
    transactions.push({ print: '', scan: '', rent: '', total: '' });
    MarkDirty();
    RenderTransactionTable();
    const lastRow = Id('datasetBody').lastElementChild;
    lastRow.scrollIntoView({ block: 'nearest' });
    lastRow.querySelector('input').focus();
  }

  async function ImportCsvFile(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      transactions = ParseCsv(await file.text());
      SetSource('imported', file.name);
      RenderTransactionTable();
      InvalidateResults();
      SetStatus(`Imported ${transactions.length} records from ${file.name}. Choose the data type, document the precise source in your report, then click “Analyze dataset”.`);
    } catch (error) {
      SetStatus(`Import failed: ${error.message}`, true);
    } finally {
      event.target.value = '';
    }
  }

  // 13. EVENT HANDLERS ----------------------------------------------------
  // Load Sample menu: opens and closes like the one in the Rate Analyzer.
  const sampleMenu = Id('sampleMenu');
  function CloseSampleMenu() {
    sampleMenu.classList.remove('open');
    Id('loadSampleBtn').setAttribute('aria-expanded', 'false');
  }
  Id('loadSampleBtn').addEventListener('click', event => {
    event.stopPropagation();
    const open = sampleMenu.classList.toggle('open');
    Id('loadSampleBtn').setAttribute('aria-expanded', String(open));
  });
  sampleMenu.addEventListener('click', event => {
    const choice = event.target.closest('button[data-sample]');
    if (!choice) return;
    CloseSampleMenu();
    LoadSampleDataset(choice.dataset.sample);
  });
  document.addEventListener('click', CloseSampleMenu);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') CloseSampleMenu();
  });
  Id('clearRecords').addEventListener('click', ClearRecords);
  Id('addRow').addEventListener('click', AddRow);
  Id('analyze').addEventListener('click', AnalyzeTransactions);
  Id('dataType').addEventListener('change', () => {
    source.dataType = Id('dataType').value;
    MarkSourceFields(null);
    ShowSource();
    if (!analyzedRows) return;
    const problem = SourceProblem();
    if (problem) {
      InvalidateResults();
      SetStatus(problem, true);
    } else {
      RefreshResults();
      SetStatus('Data type updated; the interpretations were refreshed.');
    }
  });
  Id('downloadCSV').addEventListener('click', DownloadSampleCsv);
  Id('csvInput').addEventListener('change', ImportCsvFile);

  Id('summaryVariable').addEventListener('change', RefreshDescriptiveStatistics);
  Id('formulaMode').addEventListener('change', () => {
    RefreshDescriptiveStatistics();
    RefreshConclusion();
  });
  Id('xVariable').addEventListener('change', RefreshCorrelation);
  document.querySelectorAll('.r_tile').forEach(element => {
    element.addEventListener('click', () => SelectService(element.dataset.field));
  });
  Id('scatterVariable').addEventListener('change', () => SelectService(Id('scatterVariable').value));
  Id('chartVariable').addEventListener('change', RefreshTransactionChart);

  Id('viewVerificationBtn').addEventListener('click', () => {
    Id('verificationSteps').innerHTML = ShopRateStatsSolution.VerificationHTML(analyzedRows, Id('formulaMode').value);
    ShowView('verificationSolution');
  });
  Id('backFromVerification').addEventListener('click', () => ReturnToAnalyzer('verificationCard'));

  Id('viewDescriptiveBtn').addEventListener('click', OpenDescriptiveSolution);
  Id('viewPearsonBtn').addEventListener('click', OpenPearsonSolution);
  Id('backFromDescriptive').addEventListener('click', () => ReturnToAnalyzer('descriptiveCard'));
  Id('backFromPearson').addEventListener('click', () => ReturnToAnalyzer('pearsonCard'));

  LoadSampleDataset('valid');
})();
