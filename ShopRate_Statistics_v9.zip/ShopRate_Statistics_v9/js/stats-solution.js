'use strict';

/**
 * ShopRate Statistics — "View Solution" content.
 *
 * Mirrors the Rate Analyzer's solution page: numbered steps that show the
 * formula, the substituted numbers, and the result. This file only builds
 * HTML text from numbers; every calculation is done by ShopRateStats
 * (stats-math.js). statistics.js decides when to show the result.
 */
const ShopRateStatsSolution = (() => {
  const stats = ShopRateStats;
  const format = stats.FormatPlain;

  // Results recorded from the independent Python check (tests/make_reference.py: statistics, NumPy, SciPy).
  // They document the two test datasets. `fingerprint` = [Σx, Σx²] per column, used only to recognise
  // whether the table currently holds one of those datasets so a LIVE comparison can be shown.
  const recordedChecks = Object.freeze({
    "dataset1": {
      "n": 24,
      "mean": 78.375,
      "median": 72.5,
      "sampleVariance": 968.070652173913,
      "populationVariance": 927.734375,
      "sampleStd": 31.113833774929006,
      "populationStd": 30.45873232752801,
      "min": 18,
      "max": 140,
      "rPrint": 0.9138505781721885,
      "rScan": 0.25145063666047796,
      "rRent": -0.10316428218963145,
      "fingerprint": {
        "print": [
          253.0,
          3779.0
        ],
        "scan": [
          79.0,
          391.0
        ],
        "rent": [
          41.0,
          103.0
        ],
        "total": [
          1881.0,
          169689.0
        ]
      }
    },
    "dataset2": {
      "n": 30,
      "mean": 178.00966666666667,
      "median": 183.75,
      "sampleVariance": 4612.18914816092,
      "populationVariance": 4458.449509888889,
      "sampleStd": 67.91309997460667,
      "populationStd": 66.77162204027164,
      "min": 73.84,
      "max": 289.85,
      "rPrint": 0.894145978575473,
      "rScan": 0.35501172301281425,
      "rRent": 0.5546144952314195,
      "fingerprint": {
        "print": [
          707.0,
          21061.0
        ],
        "scan": [
          286.0,
          3416.0
        ],
        "rent": [
          98.0,
          434.0
        ],
        "total": [
          5340.29,
          1084376.7281
        ]
      }
    }
  });

  // 1. SMALL BUILDERS ----------------------------------------------------
  function StepHTML(number, title, bodyHtml) {
    const label = String(number).padStart(2, '0');
    return `
      <div class="step">
        <div class="step_head">
          <span class="step_num">${label}</span>
          <div><p class="step_label">STEP ${label}</p><h2>${title}</h2></div>
        </div>
        ${bodyHtml}
      </div>`;
  }

  function MathLine(text) {
    return `<p class="math_line">${text}</p>`;
  }

  function Chips(values) {
    return `<div class="chips">${values.map(value => `<span>${format(value, 2)}</span>`).join('')}</div>`;
  }

  // Four labelled parts: meaning, finding, relevance, caution.
  function InterpretationHTML(part) {
    return `<div class="interpret_block">
      <p><b>In simple terms.</b> ${part.meaning} ${part.finding}</p>
      <p><b>For the shop.</b> ${part.relevance}</p>
    </div>`;
  }

  function CheckRow(label, firstValue, secondValue, tolerance = 1e-9) {
    const matches = Math.abs(firstValue - secondValue) <= tolerance * Math.max(1, Math.abs(firstValue));
    return `
      <div class="check_row ${matches ? '' : 'failed'}">
        <span><b>Independent check.</b> ${label}</span>
        <strong>${matches ? '✓ Matches' : '✗ Differs'}</strong>
      </div>`;
  }

  function SummaryCards(items) {
    return `<div class="final_grid">${items.map(item => `
      <div class="final_card">
        <span class="pill">${item.label}</span>
        <strong>${item.value}</strong>
        <small>${item.unit}</small>
      </div>`).join('')}</div>`;
  }

  // 2. DESCRIPTIVE STATISTICS SOLUTION -----------------------------------
  function DescriptiveHTML(rows, field, formulaMode) {
    const values = stats.GetValues(rows, field);
    const summary = stats.Describe(values, formulaMode);
    const explain = stats.InterpretStatistics(summary, field);
    const name = stats.variableNames[field];
    const unit = field === 'total' ? 'pesos' : stats.variableUnits[field];
    const captionUnit = unit;
    const cardNumber = value => field === 'total' ? stats.FormatNumber(value) : stats.FormatQuantity(value, field);
    const squared = stats.SquaredUnit(field);
    const money = value => stats.FormatValue(value, field);
    const isSample = formulaMode === 'sample';
    const symbols = isSample
      ? { variance: 's²', deviation: 's', mean: 'x̄', divisor: 'n − 1', title: 'Sample' }
      : { variance: 'σ²', deviation: 'σ', mean: 'μ', divisor: 'N', title: 'Population' };

    const countSymbol = isSample ? 'n' : 'N';

    // Step 1 — the raw observations
    const stepData = StepHTML(1, 'List the observations', `
      <div class="panel">
        <p class="panel_label">${name.toUpperCase()} · TRANSACTIONS 1 TO ${summary.n}</p>
        ${Chips(values)}
        <p class="body_text">There are <b>${countSymbol} = ${summary.n}</b> transactions. Amounts are in ${unit}.</p>
      </div>`);

    // Step 2 — mean
    const stepMean = StepHTML(2, 'Mean', `
      <div class="panel">
        <p class="panel_label">FORMULA</p>
        ${MathLine(`${symbols.mean} = Σx / ${countSymbol}`)}
        <p class="panel_label">SUBSTITUTE</p>
        ${MathLine(`${symbols.mean} = ${format(summary.sum)} / ${summary.n}`)}
        ${MathLine(`<span class="result">${symbols.mean} = ${money(summary.mean)}</span>`)}
      </div>
      ${InterpretationHTML(explain.mean)}`);

    // Step 3 — median
    const sorted = [...values].sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    const medianWork = sorted.length % 2 === 1
      ? MathLine(`${countSymbol} = ${summary.n} is odd, so the median is value number (${countSymbol} + 1) / 2 = ${middle + 1} in the sorted list.`)
        + MathLine(`<span class="result">Median = ${money(summary.median)}</span>`)
      : MathLine(`${countSymbol} = ${summary.n} is even, so average value number ${countSymbol} / 2 = ${middle} and value number ${countSymbol} / 2 + 1 = ${middle + 1}.`)
        + MathLine(`Median = (${format(sorted[middle - 1])} + ${format(sorted[middle])}) / 2`)
        + MathLine(`<span class="result">Median = ${money(summary.median)}</span>`);
    const stepMedian = StepHTML(3, 'Median', `
      <div class="panel">
        <p class="panel_label">SORT FROM SMALLEST TO LARGEST</p>
        ${Chips(sorted)}
        <p class="panel_label">MIDDLE POSITION</p>
        ${medianWork}
      </div>
      ${InterpretationHTML(explain.median)}`);

    // Step 4 — variance, with a deviation table
    const deviationRows = stats.DeviationRows(values);
    const tableRows = deviationRows.map((row, index) => `
      <tr>
        <td>${index + 1}</td><td>${format(row.value)}</td>
        <td>${format(row.deviation)}</td><td>${format(row.squared)}</td>
      </tr>`).join('');
    const rawSumsVariance = stats.VarianceByRawSums(values, formulaMode);
    const stepVariance = StepHTML(4, `${symbols.title} variance`, `
      <div class="panel">
        <p class="panel_label">FORMULA (${symbols.title.toUpperCase()} · DIVIDE BY ${symbols.divisor})</p>
        ${MathLine(`${symbols.variance} = Σ(x − ${symbols.mean})² / (${symbols.divisor})`)}
        <p class="body_text">${isSample
          ? 'The sample formula divides by n − 1 because the mean was estimated from the same data.'
          : 'The population formula divides by N because these records are treated as the complete group of interest.'} Changing this choice does not change the observations.</p>
        <p class="body_text">Variance measures spread, not an amount to charge. Its calculation uses squared units (${squared}) because each difference is multiplied by itself; standard deviation converts it back to ${unit}.</p>
        <p class="panel_label">DEVIATION TABLE (MEAN ${symbols.mean} = ${format(summary.mean)})</p>
        <div class="table_box">
          <table class="work_table">
            <thead><tr><th>#</th><th>x</th><th>x − ${symbols.mean}</th><th>(x − ${symbols.mean})²</th></tr></thead>
            <tbody>${tableRows}</tbody>
            <tfoot><tr><td colspan="3">Σ(x − ${symbols.mean})²</td><td>${format(summary.sumSquaredDeviations)}</td></tr></tfoot>
          </table>
        </div>
        <p class="panel_label">SUBSTITUTE</p>
        ${MathLine(`${symbols.variance} = ${format(summary.sumSquaredDeviations)} / ${summary.divisor}`)}
        ${MathLine(`<span class="result">${symbols.variance} = ${format(summary.variance)} ${squared}</span>`)}
        ${CheckRow(`[Σx² − (Σx)²/n] / ${summary.divisor} = ${format(rawSumsVariance)} ${squared}`, summary.variance, rawSumsVariance)}
      </div>
      ${InterpretationHTML(explain.variance)}`);

    // Step 5 — standard deviation
    const stepDeviation = StepHTML(5, `${symbols.title} standard deviation`, `
      <div class="panel">
        <p class="panel_label">FORMULA</p>
        ${MathLine(`${symbols.deviation} = √${symbols.variance}`)}
        <p class="panel_label">SUBSTITUTE</p>
        ${MathLine(`${symbols.deviation} = √${format(summary.variance)}`)}
        ${MathLine(`<span class="result">${symbols.deviation} = ${money(summary.standardDeviation)}</span>`)}
      </div>
      ${InterpretationHTML(explain.standardDeviation)}`);

    // Step 6 — minimum, maximum, range
    const stepExtremes = StepHTML(6, 'Minimum, maximum, and range', `
      <div class="panel">
        <p class="panel_label">SORTED LIST (STEP 03)</p>
        ${MathLine(`Minimum = first sorted value = ${money(summary.min)}`)}
        ${MathLine(`Maximum = last sorted value = ${money(summary.max)}`)}
        ${MathLine(`<span class="result">Range = ${money(summary.max)} − ${money(summary.min)} = ${money(summary.range)}</span>`)}
      </div>
      <div class="two_blocks">
        ${InterpretationHTML(explain.minimum)}
        ${InterpretationHTML(explain.maximum)}
      </div>`);

    const finalCards = `
      <div class="final_answers">
        <h3>FINAL ANSWERS · ${name.toUpperCase()}</h3>
        ${SummaryCards([
          { label: 'MEAN', value: cardNumber(summary.mean), unit: captionUnit },
          { label: 'MEDIAN', value: cardNumber(summary.median), unit: captionUnit },
          { label: `VARIANCE (${symbols.variance})`, value: format(summary.variance), unit: field === 'total' ? 'pesos²' : squared },
          { label: `STD. DEVIATION (${symbols.deviation})`, value: cardNumber(summary.standardDeviation), unit: captionUnit },
          { label: 'MINIMUM', value: cardNumber(summary.min), unit: captionUnit },
          { label: 'MAXIMUM', value: cardNumber(summary.max), unit: captionUnit }
        ])}
      </div>`;

    return stepData + stepMean + stepMedian + stepVariance + stepDeviation + stepExtremes + finalCards;
  }

  // 3. PEARSON CORRELATION SOLUTION --------------------------------------
  function PearsonHTML(rows, field, context = {}) {
    const xValues = stats.GetValues(rows, field);
    const yValues = stats.GetValues(rows, 'total');
    const result = stats.PearsonCorrelation(xValues, yValues);
    const check = stats.PearsonByDeviations(xValues, yValues);
    const explain = stats.InterpretCorrelation(result, field, context);
    const xName = stats.variableNames[field];
    const n = result.n;

    // Step 1 — paired data and the products Pearson's formula needs
    const tableRows = xValues.map((x, index) => `
      <tr>
        <td>${index + 1}</td><td>${format(x)}</td><td>${format(yValues[index])}</td>
        <td>${format(x * yValues[index])}</td><td>${format(x ** 2)}</td><td>${format(yValues[index] ** 2)}</td>
      </tr>`).join('');
    const stepData = StepHTML(1, 'Pair the observations', `
      <div class="panel">
        <p class="panel_label">x = ${xName.toUpperCase()} · y = TOTAL PAID (₱) · n = ${n} PAIRS</p>
        <div class="table_box">
          <table class="work_table">
            <thead><tr><th>#</th><th>x</th><th>y</th><th>xy</th><th>x²</th><th>y²</th></tr></thead>
            <tbody>${tableRows}</tbody>
            <tfoot><tr><td>Σ</td><td>${format(result.sumX)}</td><td>${format(result.sumY)}</td><td>${format(result.sumXY)}</td><td>${format(result.sumX2)}</td><td>${format(result.sumY2)}</td></tr></tfoot>
          </table>
        </div>
      </div>`);

    // Step 2 — the formula and the five sums
    const stepFormula = StepHTML(2, 'Write the formula and collect the sums', `
      <div class="panel">
        <p class="panel_label">PEARSON CORRELATION COEFFICIENT</p>
        ${MathLine('r = [nΣxy − (Σx)(Σy)] / √{[nΣx² − (Σx)²] [nΣy² − (Σy)²]}')}
        <p class="body_text">The numerator measures whether x and y move together. The denominator scales the result so that r always falls between −1 and +1.</p>
      </div>
      ${SummaryCards([
        { label: 'n', value: n, unit: 'pairs' },
        { label: 'Σx', value: format(result.sumX), unit: stats.variableUnits[field] },
        { label: 'Σy', value: format(result.sumY), unit: 'pesos' },
        { label: 'Σxy', value: format(result.sumXY), unit: 'products' },
        { label: 'Σx²', value: format(result.sumX2), unit: 'squares' },
        { label: 'Σy²', value: format(result.sumY2), unit: 'squares' }
      ])}`);

    // Step 3 — substitute the sums
    let substitution;
    if (result.r === null) {
      substitution = `
        <div class="solution_notice">Pearson r is undefined here: ${stats.variableNames[field]} or total paid has no variation, so a factor under the square root is 0. No coefficient is reported because 0 would wrongly suggest "no relationship."</div>
        <div class="panel">
          ${MathLine(`nΣx² − (Σx)² = ${n}(${format(result.sumX2)}) − (${format(result.sumX)})² = ${format(result.spreadX)}`)}
          ${MathLine(`nΣy² − (Σy)² = ${n}(${format(result.sumY2)}) − (${format(result.sumY)})² = ${format(result.spreadY)}`)}
        </div>`;
    } else {
      substitution = `
        <div class="panel">
          <p class="panel_label">NUMERATOR</p>
          ${MathLine(`nΣxy − (Σx)(Σy) = ${n}(${format(result.sumXY)}) − (${format(result.sumX)})(${format(result.sumY)})`)}
          ${MathLine(`= ${format(n * result.sumXY)} − ${format(result.sumX * result.sumY)} = <span class="result">${format(result.numerator)}</span>`)}
          <p class="panel_label">SPREAD OF x</p>
          ${MathLine(`nΣx² − (Σx)² = ${n}(${format(result.sumX2)}) − (${format(result.sumX)})² = <span class="result">${format(result.spreadX)}</span>`)}
          <p class="panel_label">SPREAD OF y</p>
          ${MathLine(`nΣy² − (Σy)² = ${n}(${format(result.sumY2)}) − (${format(result.sumY)})² = <span class="result">${format(result.spreadY)}</span>`)}
          <p class="panel_label">DENOMINATOR</p>
          ${MathLine(`√(${format(result.spreadX)} × ${format(result.spreadY)}) = <span class="result">${format(result.denominator)}</span>`)}
          <p class="panel_label">COEFFICIENT</p>
          ${MathLine(`r = ${format(result.numerator)} / ${format(result.denominator)}`)}
          ${MathLine(`<span class="result">r = ${format(result.r, 4)}</span>`)}
        </div>`;
    }
    const stepSubstitute = StepHTML(3, 'Substitute the values', substitution);

    // Step 4 — independent check with the deviation form
    const stepCheck = StepHTML(4, 'Verify with the deviation form', `
      <div class="panel">
        <p class="panel_label">DEFINITIONAL FORMULA</p>
        ${MathLine('r = Σ(x − x̄)(y − ȳ) / √[Σ(x − x̄)² · Σ(y − ȳ)²]')}
        ${MathLine(`x̄ = ${format(check.meanX)}, ȳ = ${format(check.meanY)}`)}
        ${MathLine(`Σ(x − x̄)(y − ȳ) = ${format(check.sumProducts)}`)}
        ${MathLine(`Σ(x − x̄)² = ${format(check.sumSquaresX)}, Σ(y − ȳ)² = ${format(check.sumSquaresY)}`)}
        ${check.r === null
          ? MathLine('r is undefined (a sum of squared deviations is 0).')
          : MathLine(`<span class="result">r = ${format(check.r, 4)}</span>`)}
        ${result.r === null || check.r === null
          ? ''
          : CheckRow(`Both forms give r = ${format(result.r, 4)}.`, result.r, check.r)}
      </div>`);

    // Step 5 — interpretation
    // The same six cards shown on the analyzer page, so the explanation matches the screen.
    const unusual = stats.FlagUnusualObservations(xValues, yValues);
    const cards = stats.InterpretCorrelationCards(result, field, context, unusual);
    const fenceRows = [[stats.variableTitles[field], unusual.xBounds], ['Total paid (pesos)', unusual.yBounds]]
      .map(([label, bounds]) => `<tr><td>${label}</td><td>${format(bounds.q1, 4)}</td><td>${format(bounds.q3, 4)}</td><td>${format(bounds.iqr, 4)}</td><td>${format(bounds.lower, 4)}</td><td>${format(bounds.upper, 4)}</td></tr>`).join('');
    const stepInterpret = StepHTML(5, 'Interpret the result', `
      <div class="panel">
        <p class="panel_label">POTENTIAL OUTLIERS · LESSON'S 1.5 × IQR RULE</p>
        <p class="body_text">Q1 and Q3 are the medians of the lower and upper halves, excluding the overall median when the count is odd. IQR = Q3 − Q1. Flag values below Q1 − 1.5 × IQR or above Q3 + 1.5 × IQR; keep every transaction in the reported results.</p>
        <div class="table_box"><table class="work_table iqr_table"><thead><tr><th>Variable</th><th>Q1</th><th>Q3</th><th>IQR</th><th>Lower fence</th><th>Upper fence</th></tr></thead><tbody>${fenceRows}</tbody></table></div>
      </div>
      <div class="interpret_block">
        <p><b>Result.</b> ${explain.headline}</p>
        ${Object.values(cards).map(card => `<p><b>${card.title}.</b> ${card.text}</p>`).join('')}
      </div>`);

    const finalCards = `
      <div class="final_answers">
        <h3>FINAL ANSWER · ${xName.toUpperCase()} VS. TOTAL PAID</h3>
        ${SummaryCards([
          { label: 'PEARSON r', value: result.r === null ? 'Undefined' : format(result.r, 4), unit: stats.ClassifyCorrelation(result.r).label },
          { label: 'r²', value: result.r === null ? '—' : format(result.r ** 2, 4), unit: 'share of variation, linear sense' },
          { label: 'n', value: n, unit: 'transactions' }
        ])}
      </div>`;

    return stepData + stepFormula + stepSubstitute + stepCheck + stepInterpret + finalCards;
  }


  // 4. VERIFICATION ------------------------------------------------------
  // Decides whether the table holds one of the two recorded test datasets (same count and same Σx, Σx² per column).
  function RecognizeDataset(rows) {
    const candidates = [['dataset1', 'Dataset 1 (built-in simulated rows)'], ['dataset2', 'Dataset 2 (second simulated set)']];
    for (const [key, label] of candidates) {
      const reference = recordedChecks[key];
      const sameSize = rows.length === reference.n;
      const sameSums = stats.variableKeys.every(field => {
        const values = stats.GetValues(rows, field);
        const [sum, sumSquares] = reference.fingerprint[field];
        return Math.abs(stats.Sum(values) - sum) < 0.005 && Math.abs(stats.Sum(values.map(value => value ** 2)) - sumSquares) < 0.005;
      });
      if (sameSize && sameSums) return { key, label };
    }
    return null;
  }

  function StatusCell(ok) {
    return `<td class="${ok ? 'status_ok' : 'status_fail'}">${ok ? '✓ Match' : '✗ Differs'}</td>`;
  }

  function VerificationHTML(rows, formulaMode) {
    const fieldList = stats.variableKeys;
    const lastRow = rows ? rows.length + 1 : 0;
    let checkCount = 0;
    let passedCount = 0;
    const allPassed = () => passedCount === checkCount;
    const Tally = ok => { checkCount++; if (ok) passedCount++; };

    // Step 1 — live second-route recomputation of the CURRENT dataset
    let stepLive;
    if (!rows) {
      stepLive = StepHTML(1, 'Recompute the current dataset a second way', `
        <div class="solution_notice">No analyzed dataset yet. Analyze a valid dataset (20 or more transactions) and open this page again to see the live cross-check. Steps 3–4 below do not need data.</div>`);
    } else {
      const tableRows = fieldList.map(field => {
        const values = stats.GetValues(rows, field);
        const body = stats.VerifyDescriptive(values).map(item => {
          Tally(item.ok);
          return `<tr><td>${item.name}</td><td>${format(item.main, 4)}</td><td>${format(item.check, 4)}</td><td class="method">${item.method}</td>${StatusCell(item.ok)}</tr>`;
        }).join('');
        return `<tr class="group_row"><td colspan="5">${stats.variableTitles[field]}</td></tr>${body}`;
      }).join('');
      const pearsonRows = stats.VerifyPearson(rows).map(item => {
        Tally(item.ok);
        const show = value => (value === null ? 'undefined' : format(value, 6));
        return `<tr><td>${stats.variableTitles[item.field]} vs. total paid</td><td>${show(item.main)}</td><td>${show(item.check)}</td><td class="method">Deviation form Σ(x − x̄)(y − ȳ) / √[Σ(x − x̄)²Σ(y − ȳ)²]</td>${StatusCell(item.ok)}</tr>`;
      }).join('');
      stepLive = StepHTML(1, 'Recompute the current dataset a second way', `
        <div class="panel">
          <p class="panel_label">${rows.length} TRANSACTIONS · EACH VALUE IS RECOMPUTED BY A DIFFERENT ROUTE</p>
          <p class="body_text">The website's main calculation is compared with an independent route. Both variance versions are shown here regardless of which formula you selected (you selected <b>${formulaMode}</b>). Matching means agreement within 1 part in 10⁹.</p>
          <div class="table_box tall">
            <table class="work_table verify_grid">
              <thead><tr><th>Statistic</th><th>ShopRate</th><th>Second route</th><th class="method">Second route used</th><th>Result</th></tr></thead>
              <tbody>${tableRows}<tr class="group_row"><td colspan="5">Pearson correlation</td></tr>${pearsonRows}</tbody>
            </table>
          </div>
          <div class="check_row ${allPassed() ? '' : 'failed'}"><span><b>Overall.</b> ${allPassed() ? 'Every statistic agrees with its independent recomputation.' : 'At least one statistic differs; do not rely on these results.'}</span><strong>${allPassed() ? '✓ All match' : '✗ Check failed'}</strong></div>
        </div>`);
    }

    // Step 2 — independent tool (Python). Live comparison when the table holds one of the two test datasets.
    const matched = rows ? RecognizeDataset(rows) : null;
    const recordRow = (label, key, digits) => `<tr><td>${label}</td><td>${format(recordedChecks.dataset1[key], digits)}</td><td>${format(recordedChecks.dataset2[key], digits)}</td></tr>`;
    let livePython;
    if (matched) {
      const reference = recordedChecks[matched.key];
      const total = stats.GetValues(rows, 'total');
      const sample = stats.Describe(total, 'sample');
      const population = stats.Describe(total, 'population');
      const correlation = field => stats.PearsonCorrelation(stats.GetValues(rows, field), total).r;
      const comparisons = [
        ['Mean', reference.mean, sample.mean, 4], ['Median', reference.median, sample.median, 4],
        ['Sample variance (n − 1)', reference.sampleVariance, sample.variance, 4], ['Population variance (N)', reference.populationVariance, population.variance, 4],
        ['Sample standard deviation', reference.sampleStd, sample.standardDeviation, 4], ['Population standard deviation', reference.populationStd, population.standardDeviation, 4],
        ['Minimum', reference.min, sample.min, 2], ['Maximum', reference.max, sample.max, 2],
        ['Pearson r, printing vs. total', reference.rPrint, correlation('print'), 6], ['Pearson r, scanning vs. total', reference.rScan, correlation('scan'), 6],
        ['Pearson r, rental vs. total', reference.rRent, correlation('rent'), 6]
      ];
      const liveRows = comparisons.map(([label, python, shoprate, digits]) => {
        const ok = Math.abs(python - shoprate) <= 1e-9 * Math.max(1, Math.abs(python));
        Tally(ok);
        return `<tr><td>${label}</td><td>${format(python, digits)}</td><td>${format(shoprate, digits)}</td>${StatusCell(ok)}</tr>`;
      }).join('');
      livePython = `
        <p class="panel_label">LIVE COMPARISON · THE TABLE NOW HOLDS ${matched.label.toUpperCase()}</p>
        <div class="table_box tall">
          <table class="work_table verify_grid">
            <thead><tr><th>Total paid (₱)</th><th>Python (recorded)</th><th>ShopRate (now)</th><th>Result</th></tr></thead>
            <tbody>${liveRows}</tbody>
          </table>
        </div>`;
    } else {
      livePython = `<div class="solution_notice">${rows ? 'The table does not match either test dataset (or has been edited), so no live comparison is shown.' : 'No analyzed dataset.'} Use “Load sample dataset” (Dataset 1) or import <code>tests/data/dataset2.csv</code> (Dataset 2) to see ShopRate compared with Python live.</div>`;
    }
    const stepPython = StepHTML(2, 'Compare with an independent tool (Python)', `
      <div class="panel">
        <p class="body_text">This page does not run Python, so the Python results were produced in advance by <code>tests/make_reference.py</code> (Python <code>statistics</code>, NumPy, SciPy) for two datasets: <b>Dataset 1</b> = the 24 built-in simulated rows, <b>Dataset 2</b> = 30 different simulated rows (<code>tests/data/dataset2.csv</code>). The values below are recorded; the “ShopRate (now)” column is recalculated every time you open this page.</p>
        ${livePython}
        <p class="panel_label">RECORDED PYTHON RESULTS · TOTAL PAID (₱)</p>
        <div class="table_box tall">
          <table class="work_table">
            <thead><tr><th>Statistic</th><th>Dataset 1 (n = ${recordedChecks.dataset1.n})</th><th>Dataset 2 (n = ${recordedChecks.dataset2.n})</th></tr></thead>
            <tbody>
              ${recordRow('Mean', 'mean', 4)}${recordRow('Median', 'median', 4)}
              ${recordRow('Sample variance (n − 1)', 'sampleVariance', 4)}${recordRow('Population variance (N)', 'populationVariance', 4)}
              ${recordRow('Sample standard deviation', 'sampleStd', 4)}${recordRow('Population standard deviation', 'populationStd', 4)}
              ${recordRow('Minimum', 'min', 2)}${recordRow('Maximum', 'max', 2)}
              ${recordRow('Pearson r, printing vs. total', 'rPrint', 6)}${recordRow('Pearson r, scanning vs. total', 'rScan', 6)}${recordRow('Pearson r, rental vs. total', 'rRent', 6)}
            </tbody>
          </table>
        </div>
      </div>`);

    // Step 3 — spreadsheet check (the manual / independent tool the guidelines mention)
    let stepSheet;
    if (!rows) {
      stepSheet = StepHTML(3, 'Check it yourself in a spreadsheet', `
        <div class="solution_notice">Analyze a dataset first; the formulas below are written for your number of rows.</div>`);
    } else {
      const total = stats.Describe(stats.GetValues(rows, 'total'), 'sample');
      const population = stats.Describe(stats.GetValues(rows, 'total'), 'population');
      const range = `D2:D${lastRow}`;
      const sheetRows = [
        ['Mean', `=AVERAGE(${range})`, stats.FormatNumber(total.mean)],
        ['Median', `=MEDIAN(${range})`, stats.FormatNumber(total.median)],
        ['Sample variance (n − 1)', `=VAR.S(${range})`, stats.FormatNumber(total.variance)],
        ['Population variance (N)', `=VAR.P(${range})`, stats.FormatNumber(population.variance)],
        ['Sample standard deviation', `=STDEV.S(${range})`, stats.FormatNumber(total.standardDeviation)],
        ['Population standard deviation', `=STDEV.P(${range})`, stats.FormatNumber(population.standardDeviation)],
        ['Minimum', `=MIN(${range})`, stats.FormatNumber(total.min)],
        ['Maximum', `=MAX(${range})`, stats.FormatNumber(total.max)]
      ];
      const correlations = [['print', 'A'], ['scan', 'B'], ['rent', 'C']].map(([field, column]) => {
        const result = stats.PearsonCorrelation(stats.GetValues(rows, field), stats.GetValues(rows, 'total'));
        return [`Pearson r, ${stats.variableNames[field]} vs. total paid`, `=CORREL(${column}2:${column}${lastRow}, ${range})`, result.r === null ? '#DIV/0! (undefined)' : format(result.r, 6)];
      });
      const body = [...sheetRows, ...correlations].map(([name, formula, value]) =>
        `<tr><td>${name}</td><td class="code">${formula}</td><td>${value}</td></tr>`).join('');
      stepSheet = StepHTML(3, 'Check it yourself in a spreadsheet', `
        <div class="panel">
          <p class="panel_label">EXCEL / GOOGLE SHEETS</p>
          <p class="body_text">Use the exact CSV you analyzed, or copy the current transaction table into a spreadsheet (the “Download CSV template” control downloads the primary sample, not your edited dataset), and make sure the columns are <b>A = print, B = scan, C = rent, D = total</b> with headers in row 1 and ${rows.length} records in rows 2–${lastRow}. Then type each formula and compare it with the ShopRate value (shown for total paid; use column A, B, or C for the other variables).</p>
          <div class="table_box">
            <table class="work_table">
              <thead><tr><th>Statistic</th><th>Spreadsheet formula</th><th>ShopRate value</th></tr></thead>
              <tbody>${body}</tbody>
            </table>
          </div>
        </div>`);
    }

    // Step 4 — known-answer tests, run live
    const known = stats.RunKnownAnswerTests();
    const knownRows = known.map(item => {
      Tally(item.ok);
      const show = value => (typeof value === 'number' ? format(value, 6) : value);
      return `<tr><td>${item.name}</td><td>${show(item.expected)}</td><td>${show(item.observed)}</td>${StatusCell(item.ok)}</tr>`;
    }).join('');
    const stepKnown = StepHTML(4, 'Known-answer tests (run now)', `
      <div class="panel">
        <p class="panel_label">DATA WHOSE ANSWERS ARE KNOWN (HAND-CHECKABLE DATA AND YOUR LESSON'S EXAMPLES)</p>
        <p class="body_text">These tests run when you open this page, using the same functions the analyzer uses.</p>
        <div class="table_box">
          <table class="work_table verify_grid">
            <thead><tr><th>Test</th><th>Expected</th><th>ShopRate</th><th>Result</th></tr></thead>
            <tbody>${knownRows}</tbody>
          </table>
        </div>
      </div>`);

    const summary = `
      <div class="final_answers">
        <h3>VERIFICATION SUMMARY</h3>
        ${SummaryCards([
          { label: 'CHECKS PASSED', value: `${passedCount} / ${checkCount}`, unit: rows ? 'current dataset, Python comparison, known answers' : 'known answers only (no dataset analyzed)' },
          { label: 'RESULT', value: allPassed() ? '✓ All pass' : '✗ Failure', unit: allPassed() ? 'no mismatches found' : 'do not rely on the results' },
          { label: 'INDEPENDENT TOOL', value: 'Python', unit: 'statistics · NumPy · SciPy' }
        ])}
      </div>`;
    return stepLive + stepPython + stepSheet + stepKnown + summary;
  }

  return Object.freeze({ DescriptiveHTML, PearsonHTML, VerificationHTML });
})();
