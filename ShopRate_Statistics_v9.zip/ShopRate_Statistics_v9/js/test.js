'use strict';

// Load math.js BEFORE test.js in the browser.
// Open DevTools (F12) -> Console to see results.

// I. Unique Solution 1
const sampleUnique = [
  { print: 10, scan: 2, rent: 1, total: 66 },
  { print: 5, scan: 5, rent: 2, total: 60 },
  { print: 20, scan: 0, rent: 1, total: 110 }
];

// II. Unique Solution 2
const sampleUnique2 = [
  { print: 10, scan: 2, rent: 1, total: 59 },
  { print: 5, scan: 5, rent: 2, total: 60 },
  { print: 20, scan: 0, rent: 1, total: 95 }
];

// III. Inconsistent System - No Solution
const sampleInconsistent = [
  { print: 10, scan: 2, rent: 1, total: 66 },
  { print: 20, scan: 4, rent: 2, total: 140 },
  { print: 5, scan: 5, rent: 2, total: 60 }
];

// IV. Dependent System - Infinitely Many Solutions
const sampleDependent = [
  { print: 10, scan: 2, rent: 1, total: 66 },
  { print: 20, scan: 4, rent: 2, total: 132 },
  { print: 30, scan: 6, rent: 3, total: 198 }
];

// V. Zero Initial Pivot System - Row Swap Required
const sampleRowSwap = [
  { print: 0, scan: 2, rent: 1, total: 38 },
  { print: 1, scan: 1, rent: 1, total: 39 },
  { print: 1, scan: 3, rent: 2, total: 80 }
];

// Additional input-validation test
const sampleInvalid = [
  { print: '10 5', scan: 2, rent: 1, total: 66 },
  { print: 5, scan: 5, rent: 2, total: 60 },
  { print: 20, scan: 0, rent: 1, total: 110 }
];

// Additional test: a unique solution with a negative service rate
const sampleUnsuitable = [
  { print: 1, scan: 1, rent: 0, total: 0 },
  { print: 0, scan: 1, rent: 0, total: 1 },
  { print: 0, scan: 0, rent: 1, total: 1 }
];

function ShowTest(label, transactions, expectedStatus) {
  const result = ShopRateMath.SolveRates(transactions);

  console.group(label);
  console.log('Status:', result.status);
  console.log('Classification:', result.classification);
  console.log('Message:', result.message);
  console.log('Determinant:', result.determinant);
  console.log('Rates:', result.rates);
  console.log('Formatted rates:', result.formattedRates);
  console.log('Free variables:', result.freeVariables);
  console.log('Parameterized solution:', result.parameterizedSolution);
  console.log('Complete result (expand this):', result);

  console.assert(
    result.status === expectedStatus,
    `Expected ${expectedStatus}, got ${result.status}`
  );

  console.groupEnd();
  return result;
}

// Run the five cases in the same order as the Week 2 progress report.
const uniqueResult = ShowTest(
  'I. UNIQUE SOLUTION 1',
  sampleUnique,
  'success'
);

const uniqueResult2 = ShowTest(
  'II. UNIQUE SOLUTION 2',
  sampleUnique2,
  'success'
);

const inconsistentResult = ShowTest(
  'III. INCONSISTENT SYSTEM - NO SOLUTION',
  sampleInconsistent,
  'inconsistent'
);

const dependentResult = ShowTest(
  'IV. DEPENDENT SYSTEM - INFINITELY MANY SOLUTIONS',
  sampleDependent,
  'dependent'
);

const rowSwapResult = ShowTest(
  'V. ZERO INITIAL PIVOT SYSTEM - ROW SWAP REQUIRED',
  sampleRowSwap,
  'inconsistent'
);

// Check determinants against the manual solutions.
console.assert(
  uniqueResult.determinant === 20,
  'Case I determinant should be 20'
);

console.assert(
  uniqueResult2.determinant === 20,
  'Case II determinant should be 20'
);

console.assert(
  inconsistentResult.determinant === 0,
  'Case III determinant should be 0'
);

console.assert(
  dependentResult.determinant === 0,
  'Case IV determinant should be 0'
);

console.assert(
  rowSwapResult.determinant === 0,
  'Case V determinant should be 0'
);

console.assert(
  rowSwapResult.rowReduction.steps.some(
    step => step.operation.includes('↔')
  ),
  'Case V should perform a row swap'
);

console.assert(
  dependentResult.freeVariables.join(',') === 'scan,rent',
  'Expected S and R as free variables'
);

function CheckUniqueResult(label, result, expectedRates, expectedBill) {
  // Allow for minor floating-point rounding in computed rates.
  for (const service of ['print', 'scan', 'rent']) {
    console.assert(
      Math.abs(result.rates[service] - expectedRates[service]) < 1e-8,
      `${label}: expected ${service} rate ${expectedRates[service]}, got ${result.rates[service]}`
    );
  }

  console.assert(
    result.verification.every(item => item.passed),
    `${label}: all transactions must verify`
  );

  // Both manual unique-solution cases use this sample transaction:
  // 12 print pages, 4 scan pages, and 2 rental hours.
  const billResult = ShopRateMath.CalculateBill(
    { print: 12, scan: 4, rent: 2 },
    result.rates
  );

  console.group(`${label} - SAMPLE BILL`);
  console.log('Bill breakdown:', billResult);
  console.log('Expected total: ₱' + expectedBill);
  console.log('Actual total: ₱' + billResult.formattedTotal);

  console.assert(
    billResult.formattedTotal === expectedBill,
    `${label}: bill total should be ₱${expectedBill}`
  );

  console.groupEnd();
}

CheckUniqueResult(
  'I. UNIQUE SOLUTION 1',
  uniqueResult,
  { print: 5, scan: 3, rent: 10 },
  '92.00'
);

CheckUniqueResult(
  'II. UNIQUE SOLUTION 2',
  uniqueResult2,
  { print: 4, scan: 2, rent: 15 },
  '86.00'
);

// Additional checks retained from the original test.js.
const invalidResult = ShowTest(
  'VI. INVALID INPUT',
  sampleInvalid,
  'invalid'
);

const unsuitableResult = ShowTest(
  'VII. UNSUITABLE NEGATIVE RATE',
  sampleUnsuitable,
  'unsuitable'
);

// Original Bill Calculator test retained at the end.
const billResult = ShopRateMath.CalculateBill(
  { print: 4, scan: 2, rent: 3 },
  uniqueResult.rates
);

console.group('VIII. BILL CALCULATOR');
console.log('Bill breakdown:', billResult);
console.log('Expected total: ₱56.00');
console.log('Actual total: ₱' + billResult.formattedTotal);

console.assert(
  billResult.formattedTotal === '56.00',
  'Bill total should be ₱56.00'
);

console.groupEnd();

console.log(
  'All sample tests finished. Expand each group above to inspect the results.'
);