# Statistical report preparation — current v9

The separate Word report can be used as the report draft. Before submission, update it to match this revised application and add accurate names/contributions.

1. Problem: summarize computer-shop transactions and service-versus-bill relationships within the existing Linear Algebra application.
2. Dataset: 24 simulated primary observations and 30 second-test observations. Include variables, units, generator source/seeds, and the CSV files. State clearly that no real customer data were collected.
3. Descriptive results: six statistics, sample/population formulas and worked examples. Explain squared variance units and standard deviation in original units. Include a typical-bill finding and what variability means for reviewing transactions/resources.
4. Pearson: display formula, sums, substitution, each coefficient and strength. Explain association and service mix without causal or forecast claims. Do not assign unexplained r² variation to particular sources.
5. Two figures: selected-service scatter (printing initially), with unusual points circled and retained; transaction bars (printing initially), in actual units. Select total paid for a bill-value figure if useful. No all-four graph or correlation dashboard is displayed.
6. Interpretation: service usage, typical spending, variability and practical uses, together with simulation, unit, source, linearity, and causal limitations. Keep interpretations short: explain the statistic in one sentence, then its practical implication.
7. Verification: final **View Verification** button opens four steps plus a summary. Distinguish internal alternative formulas, stored independent Python references, spreadsheet reproduction, and known-answer tests. Include current Node/browser results from TEST_RESULTS.md. Historical test counts must not be labeled current.
8. Test cases: primary valid set, independent second set, invalid/insufficient set. Explain observed errors and expected behavior.
9. Contributions and defense: record actual member work; prepare the required 20-minute demonstration and 10-minute Q&A. The report does not establish completion of these activities or the separate Linear Algebra rubric.

Current website defaults to Sample. Use sample values consistently in report tables/screenshots: dataset 1 total variance 968.0706522 pesos² and SD 31.1138338 pesos; dataset 2 total variance 4612.1891482 pesos² and SD 67.9131000 pesos. Pearson is unchanged. Potential outliers now use the lesson’s 1.5 × IQR rule; neither included valid set has any flags, so remove old transaction-17 ring/sensitivity claims from reports or captures.
